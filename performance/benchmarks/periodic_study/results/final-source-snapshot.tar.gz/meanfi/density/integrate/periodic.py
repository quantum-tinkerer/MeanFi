"""Nested periodic quadrature with explicit, empirical convergence checks.

Normal eigenvalues do not depend on mu and are retained across root solves.
BdG eigensystems do depend on mu, so only the most recent mu is cached. Cache
limits affect work, never the chosen quadrature or convergence criteria.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from meanfi.density.filling import _MaxRootIterations, mu_bracket, solve_mu
from meanfi.density.integrate.common import (
    effective_charge_tol,
    effective_filling_tol,
    retarget_result_keys,
    validate_integration_method,
    wrap_density_result,
)
from meanfi.density.integrate.methods import PeriodicQuadrature
from meanfi.density.integrate.workspace import workspace_complex_dtype
from meanfi.density.kpoint.matrix_functions import (
    DirectDiagonalization,
    selected_density_values_from_eigensystem,
)
from meanfi.density.kpoint.occupations import fermi_dirac
from meanfi.results import PeriodicQuadratureInfo
from meanfi.space.coordinates import DensityCoordinates, full_density_coordinates
from meanfi.tb.ops import to_dense
from meanfi.tb.transforms import tb_to_kfunc
from meanfi.tb.validate import tb_dimension, tb_orbital_count


@dataclass(eq=False)
class _Chunk:
    points: np.ndarray
    eigenvalues: np.ndarray | None = None
    eigenvectors: np.ndarray | None = None


class _PeriodicEvaluator:
    """Bounded point batches and a bounded, optional eigensystem cache."""

    def __init__(self, hamiltonian, *, integration, kT, coordinates, q_diag, weights):
        self.integration = integration
        self.kT = kT
        self.coordinates = coordinates
        self.q_diag = q_diag
        self.weights = weights
        self.normal = q_diag is None
        self.size = tb_orbital_count(hamiltonian)
        self.ndim = tb_dimension(hamiltonian)
        self.dtype = workspace_complex_dtype(integration)
        self.hkfunc = tb_to_kfunc(
            {
                key: np.asarray(to_dense(value), dtype=self.dtype)
                for key, value in hamiltonian.items()
            }
        )
        self.keys = (
            np.asarray(coordinates.keys, dtype=float).reshape(-1, self.ndim)
            if self.ndim
            else None
        )
        self.full_matrix = coordinates.value_count >= self.size * self.size
        self.chunks: list[_Chunk] = []
        self.cache_mu = None
        self.cache_bytes = 0
        self.n_diagonalizations = 0
        self.n_kernel_evals = 0
        self.n_evaluator_evals = 0
        self.unique_evals = 0
        self.charge_calls = 0
        self.density_calls = 0
        self.validation_points = 0

    def grid(self, nk, *, previous=None, shift=None):
        """Append only genuinely new nodes when doubling an unshifted grid."""
        count = nk**self.ndim
        if count > self.integration.max_points:
            raise ValueError(
                f"Periodic quadrature exceeded max_points={self.integration.max_points} "
                f"for nk={nk} in {self.ndim} dimensions"
            )
        chunks = [] if previous is None else list(previous)
        for start in range(0, count, self.integration.batch_size):
            flat = np.arange(start, min(start + self.integration.batch_size, count))
            if self.ndim:
                indices = np.asarray(np.unravel_index(flat, (nk,) * self.ndim)).T
                if previous is not None:
                    indices = indices[np.any(indices % 2, axis=1)]
                points = (
                    2 * np.pi * (indices + (0.0 if shift is None else shift)) / nk
                    - np.pi
                )
            else:
                points = np.empty((1, 0))
            if not len(points):
                continue
            chunk = _Chunk(points)
            chunks.append(chunk)
            self.chunks.append(chunk)
            self.unique_evals += len(points)
            if shift is not None:
                self.validation_points += len(points)
        return chunks

    def discard(self, chunks):
        for chunk in chunks:
            for array in (chunk.eigenvalues, chunk.eigenvectors):
                if array is not None:
                    self.cache_bytes -= array.nbytes
            self.chunks.remove(chunk)

    def _set_mu(self, mu):
        if self.normal or self.cache_mu == mu:
            return
        for chunk in self.chunks:
            chunk.eigenvalues = None
            chunk.eigenvectors = None
        self.cache_bytes = 0
        self.cache_mu = mu

    def _cache(self, chunk, name, array):
        if self.cache_bytes + array.nbytes <= self.integration.max_cache_bytes:
            setattr(chunk, name, array)
            self.cache_bytes += array.nbytes

    def eigensystem(self, chunk, mu, *, vectors):
        self._set_mu(mu)
        if chunk.eigenvalues is not None and (
            not vectors or chunk.eigenvectors is not None
        ):
            return chunk.eigenvalues, chunk.eigenvectors
        points = chunk.points
        matrices = np.asarray(self.hkfunc(points), dtype=self.dtype)
        self.n_kernel_evals += len(points)
        if not self.normal:
            diagonal = np.arange(self.size)
            matrices[:, diagonal, diagonal] -= mu * self.q_diag
        # Cache full normal eigensystems when they fit, avoiding a second solve
        # for density. Otherwise charge needs only the eigenvalues.
        vector_bytes = len(points) * self.size**2 * self.dtype.itemsize
        retain_vectors = (
            self.cache_bytes + vector_bytes + len(points) * self.size * 8
            <= self.integration.max_cache_bytes
        )
        if vectors or retain_vectors:
            values, eigenvectors = np.linalg.eigh(matrices)
        else:
            values = np.linalg.eigvalsh(matrices)
            eigenvectors = None
        self.n_diagonalizations += len(points)
        if chunk.eigenvalues is None:
            self._cache(chunk, "eigenvalues", values)
        if eigenvectors is not None and chunk.eigenvectors is None:
            self._cache(chunk, "eigenvectors", eigenvectors)
        return values, eigenvectors

    def evaluate(self, chunks, mu, *, density=False, coarse_chunks=0):
        """Integrate charge, optional density, and the embedded previous grid."""
        if density:
            self.density_calls += 1
        else:
            self.charge_calls += 1
        total = np.zeros(
            2 + (self.coordinates.value_count if density else 0), dtype=complex
        )
        coarse_total = np.zeros_like(total)
        count = coarse_count = 0
        for index, chunk in enumerate(chunks):
            values, vectors = self.eigensystem(
                chunk, mu, vectors=density or not self.normal
            )
            occupation = fermi_dirac(values, self.kT, mu if self.normal else 0.0)
            if self.normal:
                charge = np.sum(occupation, axis=1)
                derivative = np.sum(occupation * (1 - occupation), axis=1) / self.kT
            else:
                band_weights = np.einsum(
                    "pab,a,pab->pb", vectors.conj(), self.weights, vectors
                ).real
                charge = np.sum(band_weights * occupation, axis=1)
                derivative = np.zeros_like(charge)
            subtotal = np.empty_like(total)
            subtotal[:2] = np.sum(charge), np.sum(derivative)
            if density:
                phases = (
                    np.ones((len(values), len(self.coordinates.keys)))
                    if self.ndim == 0
                    else np.exp(1j * chunk.points @ self.keys.T)
                )
                if self.full_matrix:
                    matrix = (
                        vectors * occupation[:, None, :]
                    ) @ vectors.conj().swapaxes(-1, -2)
                    for key_index, (_, rows, cols, section) in enumerate(
                        self.coordinates.iter_key_coordinates()
                    ):
                        subtotal[2 + section.start : 2 + section.stop] = np.einsum(
                            "p,pv->v", phases[:, key_index], matrix[:, rows, cols]
                        )
                else:
                    selected = selected_density_values_from_eigensystem(
                        vectors, occupation, self.coordinates, phases=phases
                    )
                    subtotal[2:] = np.sum(selected, axis=0)
            total += subtotal
            count += len(values)
            self.n_evaluator_evals += len(values)
            if index < coarse_chunks:
                coarse_total += subtotal
                coarse_count += len(values)
        return total / count, None if not coarse_count else coarse_total / coarse_count

    def info(self, *, nk, refinements, charge_error):
        return PeriodicQuadratureInfo(
            nk=nk,
            n_kpoints=nk**self.ndim,
            n_diagonalizations=self.n_diagonalizations,
            n_kernel_evals=self.n_kernel_evals,
            unique_evals=self.unique_evals,
            n_evaluator_evals=self.n_evaluator_evals,
            n_cached_nodes=sum(
                len(c.points) for c in self.chunks if c.eigenvalues is not None
            ),
            cache_bytes=self.cache_bytes,
            refinements=refinements,
            validation_points=self.validation_points,
            charge_evaluations=self.charge_calls,
            charge_integration_calls=self.charge_calls,
            density_integration_calls=self.density_calls,
            charge_error=charge_error,
            error_estimate_kind=(
                "exact_zero_dimensional"
                if not self.ndim
                else "nested_and_shifted_grid_difference"
                if self.integration.validate_shift
                else "nested_grid_difference"
            ),
        )


def resolve_periodic_matrix_function(integration):
    selected = integration.matrix_function
    if selected is None or isinstance(selected, DirectDiagonalization):
        return DirectDiagonalization()
    raise ValueError("PeriodicQuadrature currently supports only DirectDiagonalization")


def solve_periodic_density(
    hamiltonian,
    *,
    integration: PeriodicQuadrature,
    kT: float,
    keys,
    density_coordinates: DensityCoordinates | None = None,
    mu: float | None = None,
    filling: float | None = None,
    filling_tol: float | None = None,
    mu_tol: float = 1e-10,
    max_charge_evaluations: int | None = None,
    mu_guess: float = 0.0,
    q_diag: np.ndarray | None = None,
    trace_weights: np.ndarray | None = None,
):
    """Evaluate normal or BdG density; precisely one of mu/filling is required.

    The public normal density functions dispatch here. BdG fixed filling passes
    its Nambu charge diagonal and electron trace weights through the same engine.
    A fixed-mu BdG caller can use this internal entrypoint with those arguments.
    ``max_charge_evaluations`` is a total root-evaluation budget across grids.
    Validation evaluations are integration work and do not consume that budget.
    """
    validate_integration_method(integration, kT=kT)
    resolve_periodic_matrix_function(integration)
    if (mu is None) == (filling is None):
        raise ValueError("exactly one of mu or filling must be supplied")
    if integration.density_matrix_tol is None:
        raise ValueError("PeriodicQuadrature requires a resolved density_matrix_tol")
    size = tb_orbital_count(hamiltonian)
    ndim = tb_dimension(hamiltonian)
    coordinates = (
        density_coordinates
        if density_coordinates is not None
        else full_density_coordinates(keys, size=size)
    )
    if coordinates.size != size:
        raise ValueError(
            "density coordinate matrix size must match the Hamiltonian shape"
        )
    if q_diag is not None:
        q_diag = np.asarray(q_diag, dtype=float)
        if q_diag.shape != (size,) or not np.all(np.isfinite(q_diag)):
            raise ValueError("q_diag must be a finite vector matching the Hamiltonian")
    if trace_weights is None:
        trace_weights = np.ones(size, dtype=float)
    trace_weights = np.asarray(trace_weights, dtype=float)
    if trace_weights.shape != (size,) or not np.all(np.isfinite(trace_weights)):
        raise ValueError(
            "trace_weights must be a finite vector matching the Hamiltonian"
        )
    if q_diag is None and not np.array_equal(trace_weights, np.ones(size)):
        raise ValueError("custom trace_weights require an explicit q_diag")
    density_tol = float(integration.density_matrix_tol)
    charge_tol = effective_charge_tol(integration)
    if filling is not None:
        filling_tol = effective_filling_tol(
            integration, hamiltonian=hamiltonian, filling_tol=filling_tol
        )
        if mu_tol <= 0 or not np.isfinite(mu_tol):
            raise ValueError("mu_tol must be positive and finite")
        if max_charge_evaluations is not None and max_charge_evaluations <= 0:
            raise ValueError("max_charge_evaluations must be positive")
    elif not np.isfinite(mu):
        raise ValueError("mu must be finite")
    evaluator = _PeriodicEvaluator(
        hamiltonian,
        integration=integration,
        kT=kT,
        coordinates=coordinates,
        q_diag=q_diag,
        weights=trace_weights,
    )
    nk = integration.nk if ndim else 1
    chunks = evaluator.grid(nk)
    previous_count = 0
    refinements = 0
    candidate_mu = float(mu_guess if mu is None else mu)
    while True:
        if filling is not None:
            remaining = (
                None
                if max_charge_evaluations is None
                else max_charge_evaluations - evaluator.charge_calls
            )
            if remaining is not None and remaining <= 0:
                raise ValueError(
                    "Periodic quadrature exhausted max_charge_evaluations across refinement grids"
                )

            def evaluate_charge(trial_mu):
                value, _ = evaluator.evaluate(chunks, trial_mu)
                return (
                    float(value[0].real),
                    0.0,
                    float(value[1].real) if q_diag is None else None,
                )

            try:
                root = solve_mu(
                    evaluate_charge=evaluate_charge,
                    initial_bracket=lambda: mu_bracket(hamiltonian, kT),
                    filling=filling,
                    mu_guess=candidate_mu,
                    filling_tol=filling_tol,
                    mu_tol=mu_tol,
                    max_charge_evaluations=remaining,
                    use_derivative=q_diag is None,
                )
            except _MaxRootIterations as exc:
                # The shared root solver can exhaust its budget before entering
                # its Newton/Brent loop; normalize that early failure too.
                raise ValueError(
                    "Periodic quadrature exhausted max_charge_evaluations"
                ) from exc
            candidate_mu = root.mu
        estimate, coarse = evaluator.evaluate(
            chunks, candidate_mu, density=True, coarse_chunks=previous_count
        )
        error = (
            np.zeros(estimate.size)
            if not ndim
            else np.full(estimate.size, np.inf)
            if coarse is None
            else np.abs(estimate - coarse)
        )

        def converged():
            return error[0] <= charge_tol and np.all(error[2:] <= density_tol)

        if converged() and ndim and integration.validate_shift:
            # Incommensurate axis offsets break the simple aliases shared by
            # nested dyadic grids. This is a safeguard, not a rigorous bound.
            primes = []
            candidate = 2
            while len(primes) < ndim:
                if all(
                    candidate % prime for prime in primes if prime * prime <= candidate
                ):
                    primes.append(candidate)
                candidate += 1
            shift = np.mod(np.sqrt(primes), 1.0)
            validation = evaluator.grid(nk, shift=shift)
            checked, _ = evaluator.evaluate(validation, candidate_mu, density=True)
            error = np.maximum(error, np.abs(estimate - checked))
            evaluator.discard(validation)
        if converged():
            rho, rho_error = coordinates.values_and_errors_to_tb(
                estimate[2:], error[2:]
            )
            return wrap_density_result(
                density_matrix=rho,
                density_matrix_error=rho_error,
                mu=candidate_mu,
                filling=float(estimate[0].real),
                target_filling=filling,
                integration=integration,
                info=evaluator.info(
                    nk=nk, refinements=refinements, charge_error=float(error[0])
                ),
                keys=keys,
                density_coordinates=coordinates,
            )
        next_nk = 2 * nk
        if next_nk > integration.max_nk or next_nk**ndim > integration.max_points:
            raise ValueError(
                f"Periodic quadrature did not converge at nk={nk}: "
                f"charge error estimate={error[0]:.3g}, "
                f"density error estimate={np.max(error[2:], initial=0.0):.3g}; "
                "increase max_nk/max_points or use another integration method"
            )
        previous_count = len(chunks)
        nk = next_nk
        chunks = evaluator.grid(nk, previous=chunks)
        refinements += 1


def periodic_at_mu(context, mu):
    if context.include_band_energy:
        raise ValueError("PeriodicQuadrature does not provide band energy integration")
    result = solve_periodic_density(
        context.hamiltonian,
        integration=context.integration,
        kT=context.kT,
        keys=context.solve_keys,
        density_coordinates=context.density_coordinates,
        mu=mu,
    )
    return retarget_result_keys(result, keys=context.requested_keys)


def periodic_fixed_filling(
    context, filling, filling_tol, mu_tol, max_charge_evaluations, mu_guess
):
    if context.include_band_energy:
        raise ValueError("PeriodicQuadrature does not provide band energy integration")
    result = solve_periodic_density(
        context.hamiltonian,
        integration=context.integration,
        kT=context.kT,
        keys=context.solve_keys,
        density_coordinates=context.density_coordinates,
        filling=filling,
        filling_tol=filling_tol,
        mu_tol=mu_tol,
        max_charge_evaluations=max_charge_evaluations,
        mu_guess=mu_guess,
    )
    return retarget_result_keys(result, keys=context.requested_keys)
