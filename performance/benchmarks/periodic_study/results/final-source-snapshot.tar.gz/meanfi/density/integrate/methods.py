from __future__ import annotations

from dataclasses import dataclass


FILLING_TOLERANCE_ESTIMATOR_FACTOR = 5.4


@dataclass(frozen=True)
class IntegrationMethod:
    """Base class for Brillouin-zone integration strategies."""


@dataclass(frozen=True)
class AdaptiveSimplex(IntegrationMethod):
    """Adaptive zero-temperature simplicial integration."""

    density_matrix_tol: float | None = None
    max_refinements: int | None = None
    num_threads: int | None = 1
    charge_tol: float | None = None

    def __post_init__(self) -> None:
        if self.density_matrix_tol is not None and self.density_matrix_tol <= 0:
            raise ValueError("density_matrix_tol must be positive when provided")
        if self.charge_tol is not None and self.charge_tol <= 0:
            raise ValueError("charge_tol must be positive when provided")
        if self.max_refinements is not None and self.max_refinements < 0:
            raise ValueError("max_refinements must be non-negative or None")
        if self.num_threads is not None and self.num_threads <= 0:
            raise ValueError("num_threads must be positive or None")


@dataclass(frozen=True)
class AdaptiveQuadrature(IntegrationMethod):
    """Adaptive finite-temperature quadrature."""

    density_matrix_tol: float | None = None
    max_refinements: int | None = None
    rule: str = "auto"
    batch_size: int | None = None
    matrix_function: object | None = None
    workspace_precision: int = 128
    charge_tol: float | None = None

    def __post_init__(self) -> None:
        if self.density_matrix_tol is not None and self.density_matrix_tol <= 0:
            raise ValueError("density_matrix_tol must be positive when provided")
        if self.charge_tol is not None and self.charge_tol <= 0:
            raise ValueError("charge_tol must be positive when provided")
        if self.max_refinements is not None and self.max_refinements < 0:
            raise ValueError("max_refinements must be non-negative or None")
        if self.batch_size is not None and self.batch_size <= 0:
            raise ValueError("batch_size must be positive when provided")
        if self.workspace_precision not in (64, 128):
            raise ValueError("workspace_precision must be 64 or 128")


@dataclass(frozen=True)
class PeriodicQuadrature(IntegrationMethod):
    """Globally refined periodic grids for positive-temperature densities.

    Each axis starts with ``nk`` points and doubles up to ``max_nk``.
    Convergence compares consecutive grids at the same chemical potential and,
    by default, an independently shifted grid. These differences are practical
    error estimates, not certified bounds. ``max_points`` bounds each grid;
    validation samples count separately. ``max_cache_bytes`` limits retained
    eigensystems, not transient arrays or total process memory. When the cache
    fills, normal eigenvalues are retained if possible and vectors recomputed.

    Only DirectDiagonalization is supported. ``matrix_function=None`` selects
    it also for sparse input, which is explicitly densified by this method.
    """

    density_matrix_tol: float | None = None
    charge_tol: float | None = None
    nk: int = 8
    max_nk: int = 512
    max_points: int = 262144
    batch_size: int = 256
    max_cache_bytes: int = 512 * 1024**2
    validate_shift: bool = True
    matrix_function: object | None = None
    workspace_precision: int = 128

    def __post_init__(self) -> None:
        import math
        from numbers import Integral

        for name in ("density_matrix_tol", "charge_tol"):
            value = getattr(self, name)
            if value is not None and (not math.isfinite(value) or value <= 0):
                raise ValueError(f"{name} must be positive and finite when provided")
        for name in ("nk", "max_nk", "max_points", "batch_size"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, Integral) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if self.max_nk < self.nk:
            raise ValueError("max_nk must be at least nk")
        if (
            isinstance(self.max_cache_bytes, bool)
            or not isinstance(self.max_cache_bytes, Integral)
            or self.max_cache_bytes < 0
        ):
            raise ValueError("max_cache_bytes must be a non-negative integer")
        if not isinstance(self.validate_shift, bool):
            raise ValueError("validate_shift must be boolean")
        if self.workspace_precision not in (64, 128):
            raise ValueError("workspace_precision must be 64 or 128")


@dataclass(frozen=True)
class UniformGrid(IntegrationMethod):
    """Uniform k-grid point sampling."""

    nk: int
    density_matrix_tol: float | None = None
    matrix_function: object | None = None
    workspace_precision: int = 128
    charge_tol: float | None = None

    def __post_init__(self) -> None:
        if self.nk <= 0:
            raise ValueError("nk must be positive")
        if self.density_matrix_tol is not None and self.density_matrix_tol <= 0:
            raise ValueError("density_matrix_tol must be positive when provided")
        if self.charge_tol is not None and self.charge_tol <= 0:
            raise ValueError("charge_tol must be positive when provided")
        if self.workspace_precision not in (64, 128):
            raise ValueError("workspace_precision must be 64 or 128")
