from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import numpy as np
from scipy.optimize import anderson

from meanfi.scf.methods import AndersonMixing, LinearMixing, SCFMethod

if TYPE_CHECKING:
    from meanfi.results import SCFResult


class SolverError(RuntimeError):
    """Base class for solver failures with an optional last valid result."""

    def __init__(self, message: str, *, result: SCFResult | None = None):
        self.result = result
        super().__init__(message)


class NoConvergence(SolverError):
    """Raised when the SCF iteration budget is exhausted."""

    def __init__(
        self,
        last_iterate: np.ndarray,
        *,
        result: SCFResult | None = None,
    ):
        self.last_iterate = np.array(last_iterate, dtype=float, copy=True)
        super().__init__(
            "self-consistent field iteration did not converge", result=result
        )


class SolverFailure(SolverError):
    """Raised when a numerical evaluation fails after a valid SCF state exists."""


def max_norm(values: np.ndarray) -> float:
    array = np.asarray(values)
    if array.size == 0:
        return 0.0
    return float(np.max(np.abs(array)))


def translate_no_convergence(exc: Exception, fallback: np.ndarray) -> None:
    if exc.__class__.__name__ != "NoConvergence":
        return

    if hasattr(exc, "last_iterate"):
        last_iterate = exc.last_iterate
    elif exc.args:
        last_iterate = exc.args[0]
    else:
        last_iterate = fallback
    raise NoConvergence(np.asarray(last_iterate, dtype=float)) from exc


def _solve_linear_mixing(
    residual_fn: Callable[[np.ndarray], np.ndarray],
    x0: np.ndarray,
    *,
    alpha: float,
    maxiter: int,
    scf_tol: float,
    on_iteration,
) -> np.ndarray:
    x = np.array(x0, copy=True)
    for iteration in range(1, maxiter + 1):
        residual = np.asarray(residual_fn(x), dtype=float)
        residual_norm = max_norm(residual)
        on_iteration(iteration, residual_norm, x, residual)
        if residual_norm <= scf_tol:
            return x
        x = x + alpha * residual
    raise NoConvergence(x)


def _solve_anderson(
    residual_fn: Callable[[np.ndarray], np.ndarray],
    x0: np.ndarray,
    *,
    scf: AndersonMixing,
    scf_tol: float,
    on_iteration,
) -> np.ndarray:
    state = {"iterations": 0, "accepted_initial": False}

    def wrapped_residual_fn(x: np.ndarray) -> np.ndarray:
        residual = np.asarray(residual_fn(x), dtype=float)
        if not state["accepted_initial"]:
            state["accepted_initial"] = True
            on_iteration(None, max_norm(residual), x, residual)
        return residual

    def optimizer_callback(x: np.ndarray, f: np.ndarray) -> None:
        state["iterations"] += 1
        residual = np.asarray(f, dtype=float)
        on_iteration(state["iterations"], max_norm(residual), x, residual)

    try:
        with np.errstate(invalid="ignore"):
            result = anderson(
                wrapped_residual_fn,
                x0,
                callback=optimizer_callback,
                alpha=None if scf.alpha is None else float(scf.alpha),
                w0=float(scf.w0),
                M=int(scf.M),
                line_search=scf.line_search,
                maxiter=int(scf.max_iterations),
                f_tol=scf_tol,
                f_rtol=None if scf.f_rtol is None else float(scf.f_rtol),
                x_tol=None if scf.x_tol is None else float(scf.x_tol),
                x_rtol=None if scf.x_rtol is None else float(scf.x_rtol),
                tol_norm=max_norm,
            )
    except Exception as exc:  # pragma: no cover - exercised through scipy
        translate_no_convergence(exc, x0)
        raise

    return np.asarray(result, dtype=float)


def solve_fixed_point(
    residual_fn: Callable[[np.ndarray], np.ndarray],
    x0: np.ndarray,
    *,
    scf: SCFMethod,
    scf_tol: float,
    on_iteration,
) -> np.ndarray:
    if isinstance(scf, LinearMixing):
        return _solve_linear_mixing(
            residual_fn,
            x0,
            alpha=float(scf.alpha),
            maxiter=int(scf.max_iterations),
            scf_tol=scf_tol,
            on_iteration=on_iteration,
        )
    if isinstance(scf, AndersonMixing):
        return _solve_anderson(
            residual_fn,
            x0,
            scf=scf,
            scf_tol=scf_tol,
            on_iteration=on_iteration,
        )
    raise TypeError("scf must be an SCFMethod instance")
