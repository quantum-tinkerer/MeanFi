"""Physical accuracy and convergence safeguards for periodic quadrature."""

from dataclasses import replace

import numpy as np
import pytest
from scipy.optimize import brentq
from scipy.sparse import csr_matrix

from meanfi import (
    DensityCoordinates,
    EnergyDIIS,
    ErrorTolerances,
    LinearMixing,
    Model,
    PeriodicQuadrature,
    RationalFOE,
    density_matrix,
    density_matrix_at_mu,
    fermi_dirac,
    meanfield,
    solver,
    tb_to_kfunc,
)
from meanfi.density.density import evaluate_density_matrix_fixed_filling
from meanfi.density.integrate.bdg import solve_bdg_density_fixed_filling
from meanfi.density.integrate.periodic import solve_periodic_density
from meanfi.tb.bdg import assemble_bdg_tb


pytestmark = pytest.mark.numerics


def _normal_chain():
    hop = np.array([[-0.8, 0.12j], [0.07, -0.2]], dtype=complex)
    return {(0,): np.array([[0.15, 0.2], [0.2, -0.23]]), (1,): hop, (-1,): hop.conj().T}


def _reference(h, mu, kT, keys, *, q_diag=None, weights=None):
    """Independent non-dyadic midpoint sum with explicit Fourier phases."""
    points = (2 * np.pi * (np.arange(1021) + 0.5) / 1021 - np.pi)[:, None]
    matrices = tb_to_kfunc(h)(points)
    if q_diag is not None:
        matrices = matrices - mu * np.diag(q_diag)
    values, vectors = np.linalg.eigh(matrices)
    occupations = fermi_dirac(values, kT, mu if q_diag is None else 0.0)
    density = (vectors * occupations[:, None, :]) @ vectors.conj().swapaxes(-1, -2)
    rho = {
        key: np.einsum("p,pab->ab", np.exp(1j * points[:, 0] * key[0]), density)
        / len(points)
        for key in keys
    }
    weights = np.ones(density.shape[1]) if weights is None else weights
    charge = float(np.mean(np.einsum("paa,a->p", density, weights).real))
    return charge, rho


def test_normal_fixed_mu_full_and_selected_match_reference_with_odd_initial_grid():
    h = _normal_chain()
    keys = [(0,), (1,), (-1,)]
    method = PeriodicQuadrature(
        nk=3, max_nk=384, density_matrix_tol=1e-8, charge_tol=1e-8, batch_size=7
    )
    expected_charge, expected = _reference(h, 0.31, 0.18, keys)
    result = density_matrix_at_mu(h, 0.31, kT=0.18, keys=keys, integration=method)
    assert abs(result.filling - expected_charge) < 1e-8
    for key in keys:
        np.testing.assert_allclose(
            result.to_matrix()[key], expected[key], atol=1e-8, rtol=0
        )
    coords = DensityCoordinates.from_entries(
        size=2, keys=keys, allow_empty=False, entries=[((0,), 0, 0), ((1,), 1, 0)]
    )
    selected = solve_periodic_density(
        h, integration=method, kT=0.18, keys=keys, density_coordinates=coords, mu=0.31
    )
    np.testing.assert_allclose(
        selected.density.values, coords.values_from_tb(expected), atol=1e-8, rtol=0
    )
    assert selected.statistics.status == "converged"
    assert selected.statistics.validation_points >= selected.statistics.n_kpoints


def test_normal_fixed_filling_checks_physical_charge_and_reuses_spectra():
    h = _normal_chain()
    keys = [(0,), (1,)]
    method = PeriodicQuadrature(density_matrix_tol=1e-7, charge_tol=1e-8, batch_size=13)
    result = solve_periodic_density(
        h, integration=method, kT=0.2, keys=keys, filling=0.73, filling_tol=1e-9
    )
    charge, expected = _reference(h, result.mu, 0.2, keys)
    assert abs(charge - 0.73) < 2e-9
    np.testing.assert_allclose(
        result.density.values,
        result.density.coordinates.values_from_tb(expected),
        atol=1e-7,
        rtol=0,
    )
    info = result.statistics
    assert info.n_diagonalizations == info.unique_evals
    assert info.charge_evaluations > info.refinements
    assert info.n_diagonalizations < info.n_evaluator_evals
    assert info.cache_bytes <= method.max_cache_bytes


def test_shift_validation_detects_a_shared_dyadic_alias():
    # Both 8- and 16-point grids see the constant energy +1, although the exact
    # charge of cos(16k) at mu=0 is 1/2 by particle-hole symmetry.
    h = {(0,): np.zeros((1, 1)), (16,): np.array([[0.5]]), (-16,): np.array([[0.5]])}
    method = PeriodicQuadrature(density_matrix_tol=1e-8, charge_tol=1e-8)
    unsafe = solve_periodic_density(
        h,
        integration=replace(method, validate_shift=False),
        kT=0.2,
        keys=[(0,)],
        mu=0.0,
    )
    assert abs(unsafe.filling - 0.5) > 0.4
    checked = solve_periodic_density(h, integration=method, kT=0.2, keys=[(0,)], mu=0.0)
    assert abs(checked.filling - 0.5) < 1e-8
    assert checked.statistics.nk > unsafe.statistics.nk
    assert checked.statistics.validation_points > checked.statistics.n_kpoints


def test_filling_roots_on_each_grid_are_not_a_convergence_certificate():
    with pytest.raises(ValueError, match="did not converge"):
        solve_periodic_density(
            _normal_chain(),
            integration=PeriodicQuadrature(
                nk=8, max_nk=16, density_matrix_tol=1e-10, charge_tol=1e-10
            ),
            kT=0.03,
            keys=[(0,)],
            filling=0.73,
            filling_tol=1e-10,
        )


def test_cache_and_batch_limits_change_work_but_not_answer():
    h = _normal_chain()
    method = PeriodicQuadrature(density_matrix_tol=1e-7, charge_tol=1e-7, batch_size=11)
    cached = solve_periodic_density(
        h, integration=method, kT=0.3, keys=[(0,), (1,)], filling=0.73, filling_tol=1e-9
    )
    streamed = solve_periodic_density(
        h,
        integration=replace(method, max_cache_bytes=0, batch_size=5),
        kT=0.3,
        keys=[(0,), (1,)],
        filling=0.73,
        filling_tol=1e-9,
    )
    np.testing.assert_allclose(
        cached.density.values, streamed.density.values, atol=1e-12, rtol=0
    )
    assert abs(cached.mu - streamed.mu) < 1e-12
    assert streamed.statistics.cache_bytes == 0
    assert streamed.statistics.n_diagonalizations > cached.statistics.n_diagonalizations
    assert streamed.statistics.n_kpoints == cached.statistics.n_kpoints
    sparse_result = density_matrix(
        {key: csr_matrix(value) for key, value in h.items()},
        0.73,
        kT=0.3,
        keys=[(0,), (1,)],
        integration=method,
        filling_tol=1e-9,
    )
    np.testing.assert_allclose(
        sparse_result.values, cached.density.values, atol=1e-12, rtol=0
    )


def test_bdg_fixed_filling_matches_independent_thermal_matrix_reference():
    h = _normal_chain()
    model = Model(
        h, {(0,): np.ones((2, 2))}, filling=0.73, kT=0.2, superconducting=True
    )
    pairing = assemble_bdg_tb(
        {(0,): np.zeros((2, 2))}, {(0,): np.array([[0.0, 0.21], [-0.21, 0.0]])}, ndof=2
    )
    bdg_h = model.bdg_hamiltonian_from_meanfield(pairing)
    q = np.array([1.0, 1.0, -1.0, -1.0])
    weights = np.array([1.0, 1.0, 0.0, 0.0])
    keys = [(0,), (1,)]
    reference_mu = brentq(
        lambda mu: _reference(bdg_h, mu, 0.2, keys, q_diag=q, weights=weights)[0]
        - 0.73,
        -3,
        3,
        xtol=1e-12,
    )
    result = solve_bdg_density_fixed_filling(
        model,
        pairing,
        keys=keys,
        integration=PeriodicQuadrature(density_matrix_tol=1e-7, charge_tol=1e-8),
        filling_tol=1e-9,
        mu_tol=1e-12,
        max_charge_evaluations=100,
        mu_guess=0.0,
    )
    charge, expected = _reference(
        bdg_h, result.mu, 0.2, keys, q_diag=q, weights=weights
    )
    assert abs(result.mu - reference_mu) < 2e-8
    assert abs(charge - 0.73) < 2e-9
    np.testing.assert_allclose(
        result.density.values,
        result.density.coordinates.values_from_tb(expected),
        atol=1e-7,
        rtol=0,
    )
    assert result.statistics.n_diagonalizations > result.statistics.unique_evals
    fixed_mu = solve_periodic_density(
        bdg_h,
        integration=PeriodicQuadrature(density_matrix_tol=1e-7, charge_tol=1e-8),
        kT=0.2,
        keys=keys,
        mu=result.mu,
        q_diag=q,
        trace_weights=weights,
    )
    np.testing.assert_allclose(
        fixed_mu.density.values, result.density.values, atol=1e-12, rtol=0
    )


def test_zero_dimensional_normal_and_custom_bdg_trace_are_exact():
    h = {(): np.array([[-0.3, 0.2j], [-0.2j, 0.4]])}
    method = PeriodicQuadrature(density_matrix_tol=1e-9)
    normal = density_matrix_at_mu(h, 0.1, kT=0.2, keys=[()], integration=method)
    values, vectors = np.linalg.eigh(h[()])
    expected = (vectors * fermi_dirac(values, 0.2, 0.1)) @ vectors.conj().T
    np.testing.assert_allclose(normal.to_matrix()[()], expected, atol=1e-14)
    result = solve_periodic_density(
        h,
        integration=method,
        kT=0.2,
        keys=[()],
        mu=0.1,
        q_diag=np.array([1.0, -1.0]),
        trace_weights=np.array([0.7, 0.0]),
    )
    values, vectors = np.linalg.eigh(h[()] - np.diag([0.1, -0.1]))
    expected = (vectors * fermi_dirac(values, 0.2, 0.0)) @ vectors.conj().T
    assert result.filling == pytest.approx(0.7 * expected[0, 0].real)
    assert result.statistics.n_kpoints == 1
    assert result.statistics.validation_points == 0
    assert result.errors.density_matrix_integration == 0


@pytest.mark.parametrize(
    "options",
    [
        {"nk": 0},
        {"nk": 1.5},
        {"max_nk": 4},
        {"batch_size": 0},
        {"max_cache_bytes": -1},
        {"charge_tol": np.nan},
        {"density_matrix_tol": np.inf},
    ],
)
def test_invalid_configuration(options):
    with pytest.raises(ValueError):
        PeriodicQuadrature(**options)


def test_unsupported_temperature_backend_and_exhausted_budgets():
    h = _normal_chain()
    with pytest.raises(ValueError, match="kT > 0"):
        density_matrix_at_mu(
            h, 0.0, kT=0.0, keys=[(0,)], integration=PeriodicQuadrature()
        )
    with pytest.raises(ValueError, match="DirectDiagonalization"):
        density_matrix_at_mu(
            h,
            0.0,
            kT=0.2,
            keys=[(0,)],
            integration=PeriodicQuadrature(matrix_function=RationalFOE()),
        )
    with pytest.raises(ValueError, match="max_points"):
        density_matrix_at_mu(
            h, 0.0, kT=0.2, keys=[(0,)], integration=PeriodicQuadrature(max_points=4)
        )
    with pytest.raises(
        ValueError,
        match="maximum charge-evaluation budget|exhausted max_charge_evaluations",
    ):
        solve_periodic_density(
            h,
            integration=PeriodicQuadrature(density_matrix_tol=1e-9),
            kT=0.2,
            keys=[(0,)],
            filling=0.73,
            max_charge_evaluations=2,
        )


@pytest.mark.parametrize("ndim", [2, 3])
def test_multidimensional_periodic_grid_matches_independent_fourier_sum(ndim):
    local = (0,) * ndim
    h = {local: np.array([[0.13]])}
    keys = [local]
    for axis in range(ndim):
        key = tuple(int(index == axis) for index in range(ndim))
        h[key] = np.array([[-0.17 / (axis + 1)]])
        h[tuple(-entry for entry in key)] = h[key]
        keys.append(key)
    axis = 2 * np.pi * (np.arange(35) + 0.37) / 35 - np.pi
    points = np.stack(np.meshgrid(*([axis] * ndim), indexing="ij"), axis=-1).reshape(
        -1, ndim
    )
    energy = tb_to_kfunc(h)(points)[:, 0, 0].real
    occupation = fermi_dirac(energy, 0.5, 0.04)
    expected = np.mean(
        occupation[:, None] * np.exp(1j * points @ np.asarray(keys).T), axis=0
    )
    result = density_matrix_at_mu(
        h,
        0.04,
        kT=0.5,
        keys=keys,
        integration=PeriodicQuadrature(
            density_matrix_tol=1e-9, charge_tol=1e-9, batch_size=17
        ),
    )
    np.testing.assert_allclose(result.values, expected, atol=1e-9, rtol=0)


def _interacting_chain(*, superconducting=False):
    hopping = np.array([[-0.35, 0.03j], [0.015, -0.22]], dtype=complex)
    h0 = {
        (0,): np.array([[0.12, 0.02], [0.02, -0.08]], dtype=complex),
        (1,): hopping,
        (-1,): hopping.conj().T,
    }
    interaction = {
        (0,): np.array(
            [
                [0.0, -0.08 if superconducting else 0.08],
                [-0.08 if superconducting else 0.08, 0.0],
            ]
        )
    }
    return Model(h0, interaction, filling=0.73, kT=0.4, superconducting=superconducting)


def _workflow_integration():
    return PeriodicQuadrature(density_matrix_tol=2e-8, charge_tol=2e-9, batch_size=11)


def test_public_normal_solver_converges_with_nonzero_interaction():
    model = _interacting_chain()
    result = solver(
        model,
        {(0,): np.zeros((2, 2), dtype=complex)},
        integration=_workflow_integration(),
        scf=LinearMixing(alpha=0.8, max_iterations=45),
        scf_tol=2e-7,
        filling_tol=2e-8,
        max_charge_evaluations=100,
    )
    assert result.converged
    assert len(result.history) > 1
    assert result.errors.scf_residual <= 2e-7
    assert abs(result.filling - model.filling) <= 2e-8
    assert np.max(np.abs(result.mean_field[(0,)])) > 1e-3
    # Finite-temperature density integration currently does not supply the
    # band-energy observable needed by the SCF energy-reporting path.
    assert result.total_energy is None
    assert all(iteration.total_energy is None for iteration in result.history)
    full = density_matrix(
        model.hamiltonian_from_meanfield(result.mean_field),
        model.filling,
        kT=model.kT,
        keys=[(0,)],
        integration=_workflow_integration(),
        filling_tol=2e-8,
    )
    assert full.is_complete
    assert full.covers(result.density.coordinates)
    np.testing.assert_allclose(
        full.values_for(result.density.coordinates),
        result.density.values,
        atol=3e-7,
        rtol=0,
    )
    rebuilt = meanfield(full.to_matrix(), model.h_int)
    np.testing.assert_allclose(
        rebuilt[(0,)], result.mean_field[(0,)], atol=3e-7, rtol=0
    )


def test_public_density_full_explicit_coordinates_and_interaction_agree():
    model = _interacting_chain()
    keys = [(0,), (1,)]
    common = dict(
        filling=model.filling,
        kT=model.kT,
        integration=_workflow_integration(),
        filling_tol=1e-9,
    )
    full = density_matrix(model.h_0, keys=keys, **common)
    coords = DensityCoordinates.from_entries(
        size=2, keys=keys, entries=[((0,), 1, 1), ((1,), 0, 1)], allow_empty=False
    )
    selected = density_matrix(model.h_0, coordinates=coords, **common)
    required = density_matrix(model.h_0, interaction=model.h_int, **common)
    assert full.is_complete
    assert not selected.is_complete
    np.testing.assert_allclose(
        selected.values, full.values_for(coords), atol=2e-8, rtol=0
    )
    np.testing.assert_allclose(
        required.values, full.values_for(required.coordinates), atol=2e-8, rtol=0
    )
    assert abs(selected.filling - model.filling) <= 1e-9
    # Charge is evaluated independently even though the custom density layout
    # omits one of the diagonal entries needed to construct its trace.
    assert abs(selected.values[0].real - selected.filling) > 0.1


def test_public_bdg_solver_converges_and_uses_electron_filling_convention():
    model = _interacting_chain(superconducting=True)
    initial = assemble_bdg_tb(
        {(0,): np.zeros((2, 2))},
        {(0,): np.array([[0.0, 0.025], [-0.025, 0.0]])},
        ndof=2,
    )
    result = solver(
        model,
        initial,
        integration=_workflow_integration(),
        scf=LinearMixing(alpha=0.8, max_iterations=55),
        scf_tol=3e-7,
        filling_tol=2e-8,
        max_charge_evaluations=150,
    )
    assert result.converged
    assert len(result.history) > 1
    assert result.errors.scf_residual <= 3e-7
    assert abs(result.filling - model.filling) <= 2e-8
    assert np.max(np.abs(result.mean_field[(0,)])) > 1e-3
    full = solve_bdg_density_fixed_filling(
        model,
        result.mean_field,
        keys=[(0,)],
        integration=_workflow_integration(),
        filling_tol=2e-8,
        mu_tol=1e-11,
        max_charge_evaluations=150,
        mu_guess=result.mu,
    )
    block = full.density.coordinates.values_to_tb(full.density.values)[(0,)]
    assert np.trace(block[:2, :2]).real == pytest.approx(model.filling, abs=2e-8)
    assert np.trace(block).real == pytest.approx(2.0, abs=2e-8)
    np.testing.assert_allclose(
        result.density.values,
        full.density.coordinates.values_from_tb(
            full.density.coordinates.values_to_tb(full.density.values)
        )[
            [
                full.density.coordinates.index(*entry)
                for entry in result.density.coordinates.entries
            ]
        ],
        atol=5e-7,
        rtol=0,
    )
    assert result.total_energy is None


def test_internal_weighted_bdg_charge_matches_independent_fixed_mu_matrix_sum():
    model = _interacting_chain(superconducting=True)
    pairing = assemble_bdg_tb(
        {(0,): np.zeros((2, 2))}, {(0,): np.array([[0.0, 0.13], [-0.13, 0.0]])}, ndof=2
    )
    h = model.bdg_hamiltonian_from_meanfield(pairing)
    q_diag = np.array([1.0, 1.0, -1.0, -1.0])
    weights = np.array([0.7, 1.3, 0.0, 0.0])
    mu = -0.19
    result = solve_periodic_density(
        h,
        integration=_workflow_integration(),
        kT=model.kT,
        keys=[(0,), (1,)],
        mu=mu,
        q_diag=q_diag,
        trace_weights=weights,
    )
    points = (2 * np.pi * (np.arange(257) + 0.37) / 257 - np.pi)[:, None]
    h_k = tb_to_kfunc(h)(points) - mu * np.diag(q_diag)
    eigenvalues, eigenvectors = np.linalg.eigh(h_k)
    occupations = fermi_dirac(eigenvalues, model.kT, 0.0)
    density = (eigenvectors * occupations[:, None, :]) @ eigenvectors.conj().swapaxes(
        -1, -2
    )
    expected_charge = float(np.einsum("paa,a->", density, weights).real / len(points))
    assert abs(result.filling - expected_charge) <= 2e-9
    expected = {
        (0,): np.mean(density, axis=0),
        (1,): np.einsum("p,pab->ab", np.exp(1j * points[:, 0]), density) / len(points),
    }
    np.testing.assert_allclose(
        result.density.values,
        result.density.coordinates.values_from_tb(expected),
        atol=2e-8,
        rtol=0,
    )


def test_periodic_finite_temperature_does_not_enable_energy_diis():
    model = _interacting_chain()
    with pytest.raises(ValueError, match="normal-state zero-temperature"):
        solver(
            model,
            {(0,): np.zeros((2, 2))},
            integration=PeriodicQuadrature(),
            scf=EnergyDIIS(),
        )


def test_explicit_periodic_band_energy_request_is_rejected():
    model = _interacting_chain()
    tolerances = ErrorTolerances(
        scf_residual=1e-6,
        density_matrix_integration=2e-8,
        filling_residual=2e-8,
        charge_integration=2e-9,
    )
    with pytest.raises(ValueError, match="does not provide band energy"):
        evaluate_density_matrix_fixed_filling(
            model.h_0,
            filling=model.filling,
            kT=model.kT,
            keys=[(0,)],
            integration=_workflow_integration(),
            tolerances=tolerances,
            mu_tol=1e-10,
            max_charge_evaluations=100,
            include_band_energy=True,
        )


def test_periodic_public_solver_applies_custom_tolerance_policy_once():
    model = _interacting_chain()
    policy_calls = []

    def policy(tol):
        policy_calls.append(tol)
        return ErrorTolerances(
            scf_residual=tol,
            density_matrix_integration=tol / 10,
            filling_residual=tol / 5,
            charge_integration=tol / 20,
        )

    result = solver(
        model,
        {(0,): np.zeros((2, 2))},
        integration=PeriodicQuadrature(),
        scf=LinearMixing(alpha=0.8, max_iterations=45),
        tol=2e-6,
        tolerance_policy=policy,
    )
    assert policy_calls == [2e-6]
    assert result.converged
    assert result.errors.density_matrix_integration <= 2e-7
    assert result.errors.filling_residual <= 4e-7
    assert result.errors.charge_integration <= 1e-7
