"""Sequential, resumable subprocess jobs with resource limits and progress output."""

from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time


def read_json(path):
    try:
        value = json.loads(Path(path).read_text())
        return value if isinstance(value, dict) else None
    except (OSError, ValueError):
        return None


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def source_hash():
    root = next(
        parent
        for parent in Path(__file__).resolve().parents
        if (parent / "meanfi" / "__init__.py").is_file()
    )
    digest = hashlib.sha256()
    paths = list((root / "meanfi").rglob("*.py")) + list(
        Path(__file__).parent.glob("*.py")
    )
    for path in sorted(paths):
        digest.update(str(path.relative_to(root)).encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def run_command(
    command,
    output,
    *,
    label,
    timeout_s=120,
    rss_gib=6,
    address_gib=8,
    retry_failures=False,
    force=False,
    metadata=None,
):
    """Run exactly one child and wait; never overlap computational jobs."""
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    existing = read_json(output)
    if (
        existing is not None
        and not force
        and (existing.get("status") == "success" or not retry_failures)
    ):
        print(
            json.dumps(dict(event="reuse", label=label, status=existing.get("status"))),
            flush=True,
        )
        return existing
    if output.exists():
        output.unlink()
    log = output.with_suffix(".log")
    environment = os.environ.copy()
    environment.update(
        OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1"
    )

    def limits():
        ceiling = int(address_gib * 1024**3)
        resource.setrlimit(resource.RLIMIT_AS, (ceiling, ceiling))

    print(json.dumps(dict(event="start", label=label, timeout_s=timeout_s)), flush=True)
    digest = source_hash()
    start = time.monotonic()
    peak = 0
    forced_status = None
    heartbeat = start
    with log.open("w") as stream:
        process = subprocess.Popen(
            list(map(str, command)),
            stdout=stream,
            stderr=subprocess.STDOUT,
            env=environment,
            start_new_session=True,
            preexec_fn=limits,
        )
        while process.poll() is None:
            elapsed = time.monotonic() - start
            try:
                for line in (
                    Path(f"/proc/{process.pid}/status").read_text().splitlines()
                ):
                    if line.startswith("VmRSS:"):
                        peak = max(peak, int(line.split()[1]) * 1024)
            except FileNotFoundError:
                pass
            if elapsed > timeout_s:
                forced_status = "timeout"
            elif peak > rss_gib * 1024**3:
                forced_status = "memory_limit"
            if forced_status:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                break
            if time.monotonic() - heartbeat > 25:
                print(
                    json.dumps(
                        dict(
                            event="running",
                            label=label,
                            elapsed_s=elapsed,
                            peak_rss_mib=peak / 1024**2,
                        )
                    ),
                    flush=True,
                )
                heartbeat = time.monotonic()
            time.sleep(0.1)
    elapsed = time.monotonic() - start
    result = read_json(output) or dict(
        status=forced_status or "process_error",
        error=f"child exit code {process.returncode}",
        wall_s=elapsed,
    )
    if forced_status:
        result["status"] = forced_status
    result.update(
        process_wall_s=elapsed,
        monitored_peak_rss_mib=peak / 1024**2,
        command=list(map(str, command)),
        source_sha256=digest,
    )
    if metadata:
        result.update(metadata)
    write_json(output, result)
    print(
        json.dumps(
            dict(
                event="done",
                label=label,
                status=result["status"],
                wall_s=result.get("wall_s", elapsed),
            )
        ),
        flush=True,
    )
    return result
