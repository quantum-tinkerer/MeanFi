"""Experimental dense comparison methods for the periodic quadrature study.

This file does not change MeanFi. ``run_variant`` consumes models.BenchmarkProblem.
All result density entries use problem.coordinates. Wall times include root finding,
all quadrature orders, density construction and method setup; imports/model creation
are excluded. Failed methods return their work so far and must not be ranked as
successful. All eigensolves are counted, including discarded adaptive parents and
repeated BdG (k, mu) evaluations.
"""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, replace
import time

import numpy as np
from scipy.special import expit, roots_legendre
from threadpoolctl import threadpool_limits

import meanfi
from meanfi.density.density import evaluate_density_matrix_fixed_filling
from meanfi.density.filling import mu_bracket, solve_mu
from meanfi.density.integrate.bdg import solve_bdg_density_fixed_filling
from meanfi.density.kpoint.matrix_functions.direct import (
    selected_density_values_from_eigensystem,
)
from stateful_quadrature import StatefulIntegrator

ADAPTIVE_VARIANTS = (
    "gm",
    "gm-derivative",
    "gm-charge-only",
    "gk21",
    "gk21-derivative",
    "gk21-charge-only",
    "gm-fresh",
    "gk21-fresh",
)


def _max_abs(value):
    return float(np.max(np.abs(value), initial=0.0))


def _full_h(problem):
    return problem.full_h if problem.kind == "bdg" else problem.h


def _tensor_gk(integrator):
    """Inject tensor GK21 into the installed, otherwise unchanged controller."""
    if integrator.ndim == 1:
        return integrator
    from stateful_quadrature._rules import NestedRule, _gauss_kronrod_21

    one = _gauss_kronrod_21(float)
    dim = integrator.ndim
    nodes = np.stack(
        [
            x.ravel()
            for x in np.meshgrid(*([one.reference_nodes[:, 0]] * dim), indexing="ij")
        ],
        axis=1,
    )
    wh = np.prod(
        np.stack(np.meshgrid(*([one.high_weights] * dim), indexing="ij")), axis=0
    ).ravel()
    wl = np.prod(
        np.stack(np.meshgrid(*([one.low_weights] * dim), indexing="ij")), axis=0
    ).ravel()
    integrator._rule = NestedRule("tensor_gk21", dim, nodes, wh, wl)
    integrator._n_rule_nodes = len(nodes)
    return integrator


@contextmanager
def instrument(
    stats,
    *,
    problem=None,
    variant="gm",
    batch_size=256,
    derivative_scale=0.01,
    optimize_bdg=True,
):
    """Temporary wrappers, restored on exceptions; no simultaneous use in threads.

    ``gm`` means auto GK21 in 1D and Genz--Malik in >=2D. ``*-derivative``
    changes only the derivative error budget, not its numerical value or the
    charge/root/density tolerances. ``*-charge-only`` uses Brent and drops the
    derivative criterion entirely. BdG density uses selected batched contractions
    for all optimized variants; charge-only also avoids Loewner derivatives.
    """
    import meanfi.density.integrate.normal as ni
    import meanfi.density.integrate.bdg as bi
    import meanfi.density.integrate.quadrature.runtime as runtime

    old_normal, old_bdg = ni.build_normal_backend, bi.build_bdg_backend
    old_build, old_runtime_build = ni.build_integrator, runtime.build_integrator
    old_run, old_runtime_run = ni.run_integrator, runtime.run_integrator
    old_eigh, old_eigvalsh = np.linalg.eigh, np.linalg.eigvalsh
    old_replace = StatefulIntegrator.replace_evaluator
    tensor = variant.startswith("gk21")
    charge_only = "charge-only" in variant
    scaled = "derivative" in variant
    fresh = variant.endswith("fresh")
    batch_size = int(batch_size or 256)

    def wrap(stage, function):
        def call(points, *args, **kwargs):
            start = time.perf_counter()
            try:
                # Stateful cubature's single tensor leaf can itself exceed its
                # batch cap. Bound the expensive kernel/evaluator temporaries too.
                if len(points) <= batch_size:
                    return function(points, *args, **kwargs)
                values = []
                for lo in range(0, len(points), batch_size):
                    tail = lo + batch_size
                    batch_args = tuple(
                        a[lo:tail]
                        if isinstance(a, np.ndarray)
                        and a.ndim > 0
                        and len(a) == len(points)
                        else a
                        for a in args
                    )
                    values.append(function(points[lo:tail], *batch_args, **kwargs))
                return np.concatenate(values, axis=0)
            finally:
                stats[stage + "_s"] = (
                    stats.get(stage + "_s", 0.0) + time.perf_counter() - start
                )
                stats[stage + "_calls"] = stats.get(stage + "_calls", 0) + 1
                stats[stage + "_points"] = stats.get(stage + "_points", 0) + len(points)

        call._study_stage = stage
        return call

    def eigensolver(original, name):
        def call(matrix, *args, **kwargs):
            start = time.perf_counter()
            try:
                return original(matrix, *args, **kwargs)
            finally:
                stats[name + "_s"] = (
                    stats.get(name + "_s", 0.0) + time.perf_counter() - start
                )
                stats[name + "_matrices"] = stats.get(name + "_matrices", 0) + int(
                    np.prod(np.shape(matrix)[:-2])
                )

        return call

    def backend_wrap(builder, is_bdg=False):
        def build(*args, **kwargs):
            backend = builder(*args, **kwargs)
            if is_bdg and optimize_bdg and problem is not None:
                coords = problem.coordinates
                dim = problem.ndim
                size = problem.matrix_size
                q = np.asarray(kwargs["q_diag"])
                particle_indices = np.asarray(kwargs["filling_indices"], dtype=int)
                particle_weights = np.asarray(kwargs["filling_weights"])
                keys = np.asarray(coords.keys)
                prefactor = (2 * np.pi) ** (-dim)
                hk = meanfi.tb_to_kfunc(problem.full_h)
                backend = replace(
                    backend, kernel=lambda points: hk(points).reshape(len(points), -1)
                )
                temp = float(problem.temperature)

                def spectral(payload, mu):
                    matrix = np.asarray(payload).reshape(-1, size, size).copy()
                    ii = np.arange(size)
                    matrix[:, ii, ii] -= float(mu) * q
                    return np.linalg.eigh(matrix)

                def density(points, payload, mu):
                    ee, vv = spectral(payload, mu)
                    phases = np.exp(1j * points @ keys.T)
                    return prefactor * selected_density_values_from_eigensystem(
                        vv, expit(-ee / temp), coords, phases=phases
                    )

                backend = replace(
                    backend,
                    density_evaluator=density,
                    split_density_result=coords.values_and_errors_to_tb,
                )
                if charge_only:

                    def charge(points, payload, mu):
                        ee, vv = spectral(payload, mu)
                        trace_weights = np.einsum(
                            "pin,i->pn",
                            np.abs(vv[:, particle_indices, :]) ** 2,
                            particle_weights,
                        )
                        result = np.sum(trace_weights * expit(-ee / temp), axis=1)
                        return prefactor * result[:, None]

                    backend = replace(
                        backend, charge_evaluator=charge, charge_has_derivative=False
                    )
            if charge_only and backend.charge_has_derivative:
                original_charge = backend.charge_evaluator

                def charge_value(*args, **kwargs):
                    return original_charge(*args, **kwargs)[:, :1]

                backend = replace(
                    backend, charge_evaluator=charge_value, charge_has_derivative=False
                )
            if scaled:
                unscaled_charge = backend.charge_evaluator
                original_split = backend.split_charge_result

                def scaled_charge(*args, **kwargs):
                    result = unscaled_charge(*args, **kwargs).copy()
                    result[:, 1] *= derivative_scale
                    return result

                def scaled_split(estimate, error):
                    estimate, error = (
                        np.asarray(estimate).copy(),
                        np.asarray(error).copy(),
                    )
                    estimate[1] /= derivative_scale
                    error[1] /= derivative_scale
                    return original_split(estimate, error)

                backend = replace(
                    backend,
                    charge_evaluator=scaled_charge,
                    split_charge_result=scaled_split,
                )
            return replace(
                backend,
                kernel=wrap("kernel", backend.kernel),
                charge_evaluator=wrap("charge", backend.charge_evaluator),
                density_evaluator=wrap("density", backend.density_evaluator),
            )

        return build

    def build(*args, **kwargs):
        integrator = old_build(*args, **kwargs)
        return _tensor_gk(integrator) if tensor else integrator

    def run(integrator, parameter, **kwargs):
        start = time.perf_counter()
        # Record failures, too, by calling the original integrator first.
        result = integrator.integrate(
            parameter,
            atol=kwargs["atol"],
            rtol=kwargs["rtol"],
            max_subdivisions=kwargs["max_subdivisions"],
        )
        stats.setdefault("integration_calls", []).append(
            dict(
                stage=getattr(integrator.evaluator, "_study_stage", "unknown"),
                parameter=float(parameter),
                wall_s=time.perf_counter() - start,
                kernel_evals=int(result.n_kernel_evals),
                evaluator_evals=int(result.n_evaluator_evals),
                leaves=int(result.n_leaves),
                leaf_nodes=int(result.n_leaf_nodes),
                subdivisions=int(result.subdivisions),
                status=result.status,
                max_error=_max_abs(result.error),
            )
        )
        if result.status not in kwargs.get("accepted_statuses", ("converged",)):
            raise ValueError(kwargs["error_message"])
        return result

    def new_density(self, evaluator):
        integrator = StatefulIntegrator(
            self.a,
            self.b,
            self.kernel,
            evaluator,
            rule=self.rule_name,
            dtype=self.dtype,
            batch_size=self.batch_size,
            payload_builder=self.payload_builder,
        )
        return _tensor_gk(integrator) if tensor else integrator

    ni.build_normal_backend = backend_wrap(old_normal)
    bi.build_bdg_backend = backend_wrap(old_bdg, True)
    ni.build_integrator = runtime.build_integrator = build
    ni.run_integrator = runtime.run_integrator = run
    np.linalg.eigh = eigensolver(old_eigh, "eigh")
    np.linalg.eigvalsh = eigensolver(old_eigvalsh, "eigvalsh")
    if fresh:
        StatefulIntegrator.replace_evaluator = new_density
    try:
        yield
    finally:
        ni.build_normal_backend, bi.build_bdg_backend = old_normal, old_bdg
        ni.build_integrator, runtime.build_integrator = old_build, old_runtime_build
        ni.run_integrator, runtime.run_integrator = old_run, old_runtime_run
        np.linalg.eigh, np.linalg.eigvalsh = old_eigh, old_eigvalsh
        StatefulIntegrator.replace_evaluator = old_replace


def run_variant(
    problem,
    tolerance,
    charge_tolerance,
    variant,
    *,
    max_refinements=2000,
    batch_size=256,
    derivative_scale=0.01,
    max_order=256,
    max_points=131072,
    initial_order=8,
    root_tolerance=None,
    mu_guess=0.0,
    **kwargs,
):
    """Run an optimized adaptive or order-increasing dense comparison method."""
    if variant in ("gauss", "clenshaw-curtis"):
        return run_increasing_order(
            problem,
            tolerance,
            charge_tolerance,
            family=variant,
            batch_size=batch_size,
            max_order=max_order,
            max_points=max_points,
            initial_order=initial_order,
            root_tolerance=root_tolerance,
            mu_guess=mu_guess,
        )
    if variant not in ADAPTIVE_VARIANTS:
        raise ValueError(f"Unknown comparison variant {variant!r}")
    root_tolerance = tolerance / 4 if root_tolerance is None else root_tolerance
    stats = {}
    with (
        threadpool_limits(limits=1),
        instrument(
            stats,
            problem=problem,
            variant=variant,
            batch_size=batch_size,
            derivative_scale=derivative_scale,
        ),
    ):
        start = time.perf_counter()
        try:
            method = meanfi.AdaptiveQuadrature(
                density_matrix_tol=tolerance,
                charge_tol=charge_tolerance,
                max_refinements=max_refinements,
                batch_size=batch_size,
                matrix_function=meanfi.DirectDiagonalization(),
            )
            if problem.kind == "bdg":
                result = solve_bdg_density_fixed_filling(
                    problem.model,
                    problem.mf,
                    keys=list(problem.coordinates.keys),
                    integration=method,
                    filling_tol=root_tolerance,
                    mu_tol=1e-12,
                    max_charge_evaluations=100,
                    mu_guess=mu_guess,
                    density_coordinates=problem.coordinates,
                )
            else:
                _, result = evaluate_density_matrix_fixed_filling(
                    problem.h,
                    filling=problem.filling,
                    kT=problem.temperature,
                    mu_guess=mu_guess,
                    keys=list(problem.coordinates.keys),
                    integration=method,
                    tolerances=meanfi.ErrorTolerances(
                        1e-3, tolerance, root_tolerance, charge_tolerance
                    ),
                    mu_tol=1e-12,
                    max_charge_evaluations=100,
                    density_coordinates=problem.coordinates,
                )
            values = result.density.values
            record = dict(
                status="success",
                mu=float(result.mu),
                filling=float(result.filling),
                density_real=values.real.tolist(),
                density_imag=values.imag.tolist(),
                errors=asdict(result.errors),
                statistics=asdict(result.statistics),
            )
        except Exception as exc:
            record = dict(status="error", error=repr(exc))
        record.update(
            wall_s=time.perf_counter() - start,
            timing=stats,
            variant=variant,
            derivative_scale=derivative_scale if "derivative" in variant else None,
            root_tolerance=root_tolerance,
            charge_tolerance=charge_tolerance,
            density_tolerance=tolerance,
        )
    return record


def _cc_rule(order):
    """Lobatto Clenshaw--Curtis, order intervals / order+1 nodes on [-1,1]."""
    n = int(order)
    if n < 1:
        raise ValueError("Clenshaw-Curtis order must be positive")
    theta = np.pi * np.arange(n + 1) / n
    x = np.cos(theta)
    w = np.zeros(n + 1)
    if n == 1:
        return x, np.ones(2)
    ii = np.arange(1, n)
    v = np.ones(n - 1)
    if n % 2 == 0:
        w[[0, -1]] = 1 / (n * n - 1)
        for k in range(1, n // 2):
            v -= 2 * np.cos(2 * k * theta[ii]) / (4 * k * k - 1)
        v -= np.cos(n * theta[ii]) / (n * n - 1)
    else:
        w[[0, -1]] = 1 / (n * n)
        for k in range(1, (n + 1) // 2):
            v -= 2 * np.cos(2 * k * theta[ii]) / (4 * k * k - 1)
    w[ii] = 2 * v / n
    return x, w


def tensor_rule(ndim, family, order, *, shift=0.0):
    """Nodes in [-pi, pi], weights normalized to Brillouin-zone average.

    ``order`` is points/axis for periodic and Gaussian rules, intervals/axis for
    Clenshaw--Curtis. Shift is a fraction of one periodic grid spacing.
    """
    orders = (int(order),) * ndim if np.ndim(order) == 0 else tuple(map(int, order))
    if len(orders) != ndim or min(orders) < 1:
        raise ValueError("One positive order is required for each dimension")
    axes, weights = [], []
    for n in orders:
        if family == "periodic":
            x, w = (np.arange(n) + shift) * (2 * np.pi / n) - np.pi, np.full(n, 1 / n)
        elif family == "gauss":
            x, w = roots_legendre(n)
            x, w = np.pi * x, w / 2
        elif family in ("clenshaw-curtis", "cc"):
            x, w = _cc_rule(n)
            x, w = np.pi * x, w / 2
        else:
            raise ValueError(f"Unknown tensor quadrature family {family!r}")
        axes.append(x)
        weights.append(w)
    points = np.stack([x.ravel() for x in np.meshgrid(*axes, indexing="ij")], axis=1)
    ww = np.prod(np.stack(np.meshgrid(*weights, indexing="ij")), axis=0).ravel()
    return points, ww


class _RuleState:
    """One quadrature order; normal spectra reused across chemical potentials.

    BdG caches only the last (mu, spectrum) for reuse by the final density pass.
    Changing mu requires fresh eigensolves, included in the counters.
    """

    def __init__(self, problem, points, weights, stats, batch_size):
        self.problem, self.points, self.weights = problem, points, weights
        self.stats, self.batch_size = stats, batch_size
        self.hk = meanfi.tb_to_kfunc(_full_h(problem))
        self.ee = self.vv = self.last_mu = None
        self.bdg = problem.kind == "bdg"
        self.keys = np.asarray(problem.coordinates.keys)
        self.q = (
            np.r_[np.ones(problem.physical_sites), -np.ones(problem.physical_sites)]
            if self.bdg
            else None
        )
        self.stats["new_spatial_points"] = self.stats.get(
            "new_spatial_points", 0
        ) + len(points)

    def spectral(self, mu):
        if self.ee is not None and (not self.bdg or mu == self.last_mu):
            return self.ee, self.vv
        n = self.problem.matrix_size
        self.ee = np.empty((len(self.points), n))
        self.vv = np.empty((len(self.points), n, n), dtype=complex)
        for lo in range(0, len(self.points), self.batch_size):
            tail = lo + self.batch_size
            t = time.perf_counter()
            matrix = self.hk(self.points[lo:tail])
            if self.bdg:
                ii = np.arange(n)
                matrix[:, ii, ii] -= mu * self.q
            self.stats["matrix_s"] = (
                self.stats.get("matrix_s", 0.0) + time.perf_counter() - t
            )
            t = time.perf_counter()
            self.ee[lo:tail], self.vv[lo:tail] = np.linalg.eigh(matrix)
            self.stats["eigh_s"] = (
                self.stats.get("eigh_s", 0.0) + time.perf_counter() - t
            )
            self.stats["eigh_matrices"] = self.stats.get("eigh_matrices", 0) + len(
                matrix
            )
        self.last_mu = mu
        return self.ee, self.vv

    def charge(self, mu):
        ee, vv = self.spectral(mu)
        t = time.perf_counter()
        occupation = (
            expit(-ee / self.problem.temperature)
            if self.bdg
            else expit((mu - ee) / self.problem.temperature)
        )
        if self.bdg:
            trace_weight = np.empty_like(ee)
            for lo in range(0, len(ee), self.batch_size):
                trace_weight[lo : lo + self.batch_size] = np.sum(
                    np.abs(
                        vv[lo : lo + self.batch_size, : self.problem.physical_sites, :]
                    )
                    ** 2,
                    axis=1,
                )
            value = float(
                np.dot(self.weights, np.sum(trace_weight * occupation, axis=1))
            )
            derivative = None
        else:
            value = float(np.dot(self.weights, occupation.sum(axis=1)))
            derivative = float(
                np.dot(self.weights, (occupation * (1 - occupation)).sum(axis=1))
                / self.problem.temperature
            )
        self.stats["charge_s"] = (
            self.stats.get("charge_s", 0.0) + time.perf_counter() - t
        )
        self.stats["charge_calls"] = self.stats.get("charge_calls", 0) + 1
        self.stats["charge_points"] = self.stats.get("charge_points", 0) + len(ee)
        return value, 0.0, derivative

    def density(self, mu):
        ee, vv = self.spectral(mu)
        t = time.perf_counter()
        value = np.zeros(self.problem.coordinates.value_count, dtype=complex)
        for lo in range(0, len(ee), self.batch_size):
            tail = lo + self.batch_size
            occupation = (
                expit(-ee[lo:tail] / self.problem.temperature)
                if self.bdg
                else expit((mu - ee[lo:tail]) / self.problem.temperature)
            )
            phases = np.exp(1j * self.points[lo:tail] @ self.keys.T)
            point_values = selected_density_values_from_eigensystem(
                vv[lo:tail], occupation, self.problem.coordinates, phases=phases
            )
            value += np.einsum("p,pv->v", self.weights[lo:tail], point_values)
        self.stats["density_s"] = (
            self.stats.get("density_s", 0.0) + time.perf_counter() - t
        )
        self.stats["density_points"] = self.stats.get("density_points", 0) + len(ee)
        return value


def fixed_mu_rule(problem, mu, family, order, *, batch_size=256, shift=0.0):
    """Single-order convergence sample. Counts include a shared charge/density pass."""
    stats = {}
    with threadpool_limits(limits=1):
        start = time.perf_counter()
        points, weights = tensor_rule(problem.ndim, family, order, shift=shift)
        state = _RuleState(problem, points, weights, stats, batch_size)
        charge, _, _ = state.charge(mu)
        values = state.density(mu)
        wall = time.perf_counter() - start
    return dict(
        status="success",
        family=family,
        order=order,
        mu=float(mu),
        filling=charge,
        wall_s=wall,
        timing=stats,
        density_real=values.real.tolist(),
        density_imag=values.imag.tolist(),
        n_points=len(points),
        weight_sum=float(weights.sum()),
    )


def run_increasing_order(
    problem,
    tolerance,
    charge_tolerance,
    *,
    family="gauss",
    batch_size=256,
    max_order=256,
    max_points=131072,
    initial_order=8,
    root_tolerance=None,
    mu_guess=0.0,
):
    """Global order-doubling; stop on charge and density differences.

    Gauss orders are not nested, so all work from previous orders is counted.
    CC is offered as a control but does NOT yet exploit its nested point reuse;
    do not present its cumulative runtime as a fully optimized CC implementation.
    Difference estimates are indicators, not rigorous error bounds. Independent
    reference checks are mandatory for all successful benchmark records.
    """
    root_tolerance = tolerance / 4 if root_tolerance is None else root_tolerance
    stats = {"levels": []}
    previous_state = previous_values = None
    order = int(initial_order)
    mu = float(mu_guess)
    record = {}
    with threadpool_limits(limits=1):
        start = time.perf_counter()
        try:
            while order <= max_order:
                count = (
                    order + 1 if family == "clenshaw-curtis" else order
                ) ** problem.ndim
                if count > max_points:
                    raise RuntimeError(f"Tensor rule exceeds max_points={max_points}")
                points, weights = tensor_rule(problem.ndim, family, order)
                state = _RuleState(problem, points, weights, stats, batch_size)
                root = solve_mu(
                    evaluate_charge=state.charge,
                    initial_bracket=lambda: mu_bracket(
                        _full_h(problem), problem.temperature
                    ),
                    filling=problem.filling,
                    mu_guess=mu,
                    filling_tol=root_tolerance,
                    mu_tol=1e-12,
                    max_charge_evaluations=100,
                    charge_error_tol=charge_tolerance,
                    use_derivative=problem.kind != "bdg",
                )
                mu = root.mu
                values = state.density(mu)
                density_change = (
                    None
                    if previous_values is None
                    else _max_abs(values - previous_values)
                )
                charge_change = (
                    None
                    if previous_state is None
                    else abs(previous_state.charge(mu)[0] - root.charge)
                )
                stats["levels"].append(
                    dict(
                        order=order,
                        points=count,
                        mu=mu,
                        filling=root.charge,
                        density_change=density_change,
                        charge_change=charge_change,
                        elapsed_s=time.perf_counter() - start,
                        cumulative_eigh=stats.get("eigh_matrices", 0),
                    )
                )
                if (
                    density_change is not None
                    and density_change <= tolerance
                    and charge_change <= charge_tolerance
                ):
                    record = dict(
                        status="success",
                        mu=mu,
                        filling=root.charge,
                        density_real=values.real.tolist(),
                        density_imag=values.imag.tolist(),
                        errors=dict(
                            density_matrix_integration=density_change,
                            charge_integration=charge_change,
                        ),
                        statistics=dict(final_points=count, final_order=order),
                    )
                    break
                previous_state, previous_values = state, values
                if problem.kind != "bdg":
                    # Subsequent normal charge checks need only eigenvalues.
                    # Avoid retaining a discarded order's large vector cache.
                    previous_state.vv = None
                order *= 2
            else:
                raise RuntimeError(
                    f"Order refinement did not converge by max_order={max_order}"
                )
        except Exception as exc:
            record = dict(status="error", error=repr(exc))
        record.update(
            wall_s=time.perf_counter() - start,
            timing=stats,
            variant=family,
            root_tolerance=root_tolerance,
            charge_tolerance=charge_tolerance,
            density_tolerance=tolerance,
            error_estimate="successive-order difference; independently validate",
        )
    return record


def run_fixed_mu_variant(
    problem,
    mu,
    tolerance,
    charge_tolerance,
    variant,
    *,
    max_refinements=2000,
    batch_size=256,
    **kwargs,
):
    """Optimized fixed-mu adaptive convergence control, for normal and BdG.

    Charge and selected densities share every eigensolve and one adaptive mesh.
    Columns are normalized by their own requested absolute errors. Unlike the
    fixed-filling solver there is no derivative or chemical-potential cache here;
    cache final integrand values, since mu is fixed. This compares convergence
    without imposing the overhead of retaining full eigenvectors unnecessarily.
    """
    if not (variant.startswith("gm") or variant.startswith("gk21")):
        raise ValueError("Fixed-mu adaptive variant must be gm or gk21")
    stats = {}
    start = time.perf_counter()
    hk = meanfi.tb_to_kfunc(_full_h(problem))
    bdg = problem.kind == "bdg"
    q = problem.q_diag
    keys = np.asarray(problem.coordinates.keys)
    size = problem.matrix_size
    prefactor = (2 * np.pi) ** (-problem.ndim)
    scales = np.r_[
        charge_tolerance, np.full(problem.coordinates.value_count, tolerance)
    ]

    def kernel(points):
        value = np.empty((len(points), len(scales)), dtype=complex)
        for lo in range(0, len(points), batch_size):
            tail = lo + batch_size
            pp = points[lo:tail]
            t = time.perf_counter()
            matrix = hk(pp)
            if bdg:
                ii = np.arange(size)
                matrix[:, ii, ii] -= mu * q
            stats["matrix_s"] = stats.get("matrix_s", 0.0) + time.perf_counter() - t
            t = time.perf_counter()
            ee, vv = np.linalg.eigh(matrix)
            stats["eigh_s"] = stats.get("eigh_s", 0.0) + time.perf_counter() - t
            stats["eigh_matrices"] = stats.get("eigh_matrices", 0) + len(pp)
            t = time.perf_counter()
            occupation = (
                expit(-ee / problem.temperature)
                if bdg
                else expit((mu - ee) / problem.temperature)
            )
            charge = (
                np.sum(
                    occupation
                    * np.sum(np.abs(vv[:, : problem.physical_sites, :]) ** 2, axis=1),
                    axis=1,
                )
                if bdg
                else occupation.sum(axis=1)
            )
            phase = np.exp(1j * pp @ keys.T)
            density = selected_density_values_from_eigensystem(
                vv, occupation, problem.coordinates, phases=phase
            )
            value[lo:tail, 0] = charge
            value[lo:tail, 1:] = density
            stats["density_s"] = stats.get("density_s", 0.0) + time.perf_counter() - t
        return prefactor * value / scales

    with threadpool_limits(limits=1):
        try:
            integrator = StatefulIntegrator(
                [-np.pi] * problem.ndim,
                [np.pi] * problem.ndim,
                kernel,
                lambda points, payload, parameter: payload,
                batch_size=batch_size,
                rule="auto",
            )
            if variant.startswith("gk21"):
                _tensor_gk(integrator)
            result = integrator.integrate(
                mu, atol=1.0, rtol=0.0, max_subdivisions=max_refinements
            )
            values = np.asarray(result.estimate) * scales
            errors = np.asarray(result.error) * scales
            record = dict(
                status="success" if result.status == "converged" else "error",
                mu=float(mu),
                filling=float(values[0].real),
                density_real=values[1:].real.tolist(),
                density_imag=values[1:].imag.tolist(),
                errors=dict(
                    charge_integration=float(abs(errors[0])),
                    density_matrix_integration=_max_abs(errors[1:]),
                ),
                statistics=dict(
                    kernel_evals=int(result.n_kernel_evals),
                    evaluator_evals=int(result.n_evaluator_evals),
                    final_points=int(result.n_leaf_nodes),
                    leaves=int(result.n_leaves),
                    subdivisions=int(result.subdivisions),
                    integrator_status=result.status,
                ),
            )
            if result.status != "converged":
                record["error"] = f"Fixed-mu cubature returned {result.status}"
        except Exception as exc:
            record = dict(status="error", error=repr(exc), mu=float(mu))
    record.update(
        wall_s=time.perf_counter() - start,
        timing=stats,
        variant=variant,
        density_tolerance=tolerance,
        charge_tolerance=charge_tolerance,
        execution="fixed mu; shared charge/density samples and value cache",
    )
    return record
