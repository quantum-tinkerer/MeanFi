"""Deterministic periodic tight-binding models for integration benchmarks.

These are trial Hamiltonians, not self-consistent SCF solutions. Unit t_x=1.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
import sys
import numpy as np

ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "meanfi" / "__init__.py").is_file()
)
sys.path.insert(0, str(ROOT))
# Import the checkout only after placing its repository root on sys.path.
import meanfi  # noqa: E402
from meanfi.tb.bdg import assemble_bdg_tb  # noqa: E402


@dataclass
class BenchmarkProblem:
    name: str
    h: dict
    coordinates: object
    filling: float
    temperature: float
    kind: str
    model: object
    mf: dict | None
    physical_sites: int
    description: str
    metadata: dict = field(default_factory=dict)

    @property
    def ndim(self):
        return len(next(iter(self.h)))

    @property
    def matrix_size(self):
        return self.physical_sites * (2 if self.kind == "bdg" else 1)

    @property
    def full_h(self):
        return (
            self.h
            if self.kind == "normal"
            else self.model.bdg_hamiltonian_from_meanfield(self.mf)
        )

    @property
    def q_diag(self):
        if self.kind == "normal":
            return np.ones(self.physical_sites)
        return np.r_[np.ones(self.physical_sites), -np.ones(self.physical_sites)]

    def summary(self):
        return dict(
            name=self.name,
            kind=self.kind,
            ndim=self.ndim,
            physical_sites=self.physical_sites,
            matrix_size=self.matrix_size,
            filling=self.filling,
            temperature=self.temperature,
            coordinate_count=self.coordinates.value_count,
            description=self.description,
            metadata=self.metadata,
        )


MODEL_NAMES = (
    "chain48",
    "square48",
    "vanhove48",
    "anisotropic48",
    "gapped48",
    "cubic48",
    "bdg_chain48",
    "bdg_nodal48",
    "bdg_gapped48",
    "chain1",
    "square1",
    "pocket1",
    "alias1",
    "wire48",
)


def _supercell(
    shape, *, hopping=None, disorder=0.35, bond_disorder=0.15, staggered=0.0, seed=None
):
    dim = len(shape)
    n = int(np.prod(shape))
    zero = (0,) * dim
    hopping = (1.0,) + (0.8,) * (dim - 1) if hopping is None else tuple(hopping)
    rng = np.random.default_rng(90210 + dim if seed is None else seed)
    onsite = rng.uniform(-disorder, disorder, n)
    for pos in np.ndindex(shape):
        onsite[np.ravel_multi_index(pos, shape)] += staggered * (-1) ** sum(pos)
    h = {zero: np.diag(onsite).astype(complex)}
    bonds = []
    for pos in np.ndindex(shape):
        i = np.ravel_multi_index(pos, shape)
        for axis in range(dim):
            other = list(pos)
            other[axis] = (other[axis] + 1) % shape[axis]
            j = np.ravel_multi_index(tuple(other), shape)
            key = tuple(
                int(d == axis and pos[axis] == shape[axis] - 1) for d in range(dim)
            )
            opposite = tuple(-x for x in key)
            amp = -hopping[axis] * rng.uniform(1 - bond_disorder, 1 + bond_disorder)
            for R, a, b in [(key, i, j), (opposite, j, i)]:
                h.setdefault(R, np.zeros((n, n), complex))[a, b] += amp
            bonds.append((axis, key, opposite, i, j))
    return h, bonds


def _normal(name, h, filling, temp, description, metadata):
    n = next(iter(h.values())).shape[0]
    zero = (0,) * len(next(iter(h)))
    interaction = {key: np.asarray(value != 0, complex) for key, value in h.items()}
    interaction[zero] = interaction.get(zero, np.zeros((n, n), complex)) + np.eye(n)
    model = meanfi.Model(h, interaction, filling=filling, kT=temp)
    return BenchmarkProblem(
        name,
        h,
        model.scf_space.required_coordinates,
        filling,
        temp,
        "normal",
        model,
        None,
        n,
        description,
        metadata,
    )


def _wire48(temperature):
    """Forty-eight transverse sites with a one-cell transport period."""
    shape = (6, 8)
    size = 48
    seed = 9021048
    rng = np.random.default_rng(seed)
    onsite = rng.uniform(-0.35, 0.35, size)
    transport = rng.uniform(0.8, 1.2, size)
    local = np.diag(onsite).astype(complex)
    transverse_hopping = (0.35, 0.28)
    for position in np.ndindex(shape):
        row = np.ravel_multi_index(position, shape)
        for axis, hopping in enumerate(transverse_hopping):
            if position[axis] + 1 == shape[axis]:
                continue
            neighbor = list(position)
            neighbor[axis] += 1
            column = np.ravel_multi_index(tuple(neighbor), shape)
            local[row, column] = local[column, row] = -hopping
    between_cells = -np.diag(transport).astype(complex)
    h = {(0,): local, (1,): between_cells, (-1,): between_cells.copy()}
    return _normal(
        "wire48",
        h,
        0.43 * size,
        temperature,
        "48-site multichannel wire: open 6 x 8 transverse section, one-cell "
        "transport period, disordered onsite and site-dependent transport hopping.",
        dict(
            transverse_shape=shape,
            transport_period=1,
            seed=seed,
            onsite_disorder=0.35,
            transverse_hopping=transverse_hopping,
            transport_hopping_interval=(0.8, 1.2),
            analytic_control=False,
            longitudinal_supercell_folding=False,
        ),
    )


def build_problem(name, temperature=0.05):
    if name == "wire48":
        return _wire48(temperature)
    if name not in MODEL_NAMES:
        raise ValueError(f"unknown model {name!r}; choose from {MODEL_NAMES}")
    if name in ("chain1", "square1", "pocket1", "alias1"):
        if name == "chain1":
            h = {
                (0,): np.array([[0.2]], complex),
                (1,): np.array([[-1.0]], complex),
                (-1,): np.array([[-1.0]], complex),
                (3,): np.array([[0.175]], complex),
                (-3,): np.array([[0.175]], complex),
            }
            filling = 0.43
            description = "One-band 1D metal with nearest and third-neighbor hopping."
        elif name == "square1":
            h = {(0, 0): np.array([[0.0]], complex)}
            for R, a in [((1, 0), -1.0), ((0, 1), -0.7), ((1, 1), -0.15)]:
                h[R] = np.array([[a]], complex)
                h[tuple(-x for x in R)] = h[R].conj().T
            filling = 0.43
            description = "One-band 2D metal with diagonal hopping."
        elif name == "pocket1":
            h = {(0, 0): np.array([[2.04]], complex)}
            for R, phi in [((1, 0), 0.371), ((0, 1), 0.219)]:
                h[R] = np.array([[-0.5 * np.exp(1j * phi)]], complex)
                h[tuple(-x for x in R)] = h[R].conj().T
            filling = 0.012
            description = (
                "One-band 2D low-density pocket shifted away from symmetry/grid points."
            )
        else:
            h = {
                (0,): np.array([[0.15]], complex),
                (16,): np.array([[0.5]], complex),
                (-16,): np.array([[0.5]], complex),
            }
            filling = 0.37
            description = "One-band finite-range cos(16k) aliasing adversary for nested 8/16 grids."
        return _normal(
            name, h, filling, temperature, description, dict(analytic_control=True)
        )

    shape = (
        (48,)
        if name in ("chain48", "bdg_chain48")
        else (3, 4, 4)
        if name == "cubic48"
        else (6, 8)
    )
    kwargs = {}
    filling = 0.43 * 48
    descriptions = {
        "chain48": "48-site disordered connected 1D supercell.",
        "square48": "6 x 8 disordered connected 2D supercell, hopping (1,0.8).",
        "vanhove48": "Clean isotropic square-lattice 6 x 8 supercell near half filling/van Hove energy.",
        "anisotropic48": "Disordered 6 x 8 quasi-1D supercell, hopping (1,0.04).",
        "gapped48": "Clean 6 x 8 checkerboard band insulator with staggered onsite +/-1.5.",
        "cubic48": "Disordered 3 x 4 x 4 cubic supercell, hopping (1,0.8,0.6).",
        "bdg_chain48": "Clean 48-site spinless p-wave chain, pairing 0.2; gapped away from band edges.",
        "bdg_nodal48": "Clean 6 x 8 spinless p_x BdG supercell, pairing 0.2, nodal Fermi crossings.",
        "bdg_gapped48": "Clean 6 x 8 spinless p_x+i p_y BdG supercell, pairing 0.2, away from gap-closing fillings.",
    }
    if name == "vanhove48":
        kwargs = dict(hopping=(1, 1), disorder=0, bond_disorder=0)
        filling = 0.495 * 48
    elif name == "anisotropic48":
        kwargs = dict(hopping=(1, 0.04), disorder=0.12, bond_disorder=0.10)
    elif name == "gapped48":
        kwargs = dict(hopping=(1, 0.8), disorder=0, bond_disorder=0, staggered=1.5)
        filling = 0.5 * 48
    elif name == "cubic48":
        kwargs = dict(hopping=(1, 0.8, 0.6))
    elif name.startswith("bdg_"):
        kwargs = dict(disorder=0, bond_disorder=0)
        if name == "bdg_nodal48":
            kwargs["hopping"] = (1, 1)
        if name == "bdg_gapped48":
            filling = 0.35 * 48
    h, bonds = _supercell(shape, **kwargs)
    metadata = dict(shape=shape, **kwargs)
    if not name.startswith("bdg_"):
        return _normal(name, h, filling, temperature, descriptions[name], metadata)
    n = 48
    zero = (0,) * len(shape)
    pair = {key: np.zeros_like(value) for key, value in h.items()}
    for axis, key, opposite, i, j in bonds:
        amplitude = (
            0.2 if axis == 0 else 0.2j if name == "bdg_gapped48" and axis == 1 else 0.0
        )
        pair[key][i, j] += amplitude
        pair[opposite][j, i] -= amplitude
    mf = assemble_bdg_tb({zero: np.zeros((n, n), complex)}, pair, ndof=n)
    interaction = {key: np.asarray(value != 0, complex) for key, value in h.items()}
    interaction[zero] += np.eye(n)
    model = meanfi.Model(
        h, interaction, filling=filling, kT=temperature, superconducting=True
    )
    return BenchmarkProblem(
        name,
        h,
        model.scf_space.required_coordinates,
        filling,
        temperature,
        "bdg",
        model,
        mf,
        n,
        descriptions[name],
        metadata,
    )
