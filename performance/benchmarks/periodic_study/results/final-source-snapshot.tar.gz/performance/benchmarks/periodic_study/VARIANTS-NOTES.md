# What these comparisons establish

`variants.py` supplies experimental comparison methods without editing MeanFi.
The adaptive GM/GK algorithms are the installed `stateful-quadrature` controller;
tensor GK21 is injected as a rule with tensor products of its 1D high and low
weights. In 1D both names use GK21; Genz–Malik is only meaningful here in 2D/3D.

## Fixed-filling accuracy contract

All optimized runs request max selected-density-entry error `eps`, charge integral
error `eps/4`, and root residual `eps/4`. This gives a physical charge residual
budget when the error estimates are reliable. Density tolerances describe the
integration error at the returned chemical potential; they do not automatically
bound density changes caused by a root residual. Independently check density at
the converged physical filling as well as charge at the returned mu.

A `success` status only means the method's internal estimator accepted. A row is
accuracy-qualified only after an independently resolved reference check. Charge
must be evaluated at the method's returned mu on that reference; comparing only
the self-reported filling is circular. Max component errors are absolute; total
charge scales with the physical site count. Do not silently switch between per
site and total filling tolerances when comparing one-band and 48-site cases.

Derivative variants multiply the integrated derivative column by 0.01 during
error control and undo that scaling before the unchanged safeguarded Newton
update. This grants 100 times more derivative integration error while keeping
charge/density/root tolerances. It is an experimental budget choice, not a proof
of an optimal universal factor. Charge-only variants remove that derivative
criterion and use the existing safeguarded Brent solver.

## Meaning of optimizations and point counts

All expensive kernels/evaluators use bounded batches, including a single tensor
GK21 leaf larger than the controller's batch size. Normal-state eigenvectors are
reused across mu. Optimized BdG uses a batched Hamiltonian builder and selected
density contractions, and charge-only BdG avoids full-matrix Loewner derivative
work. A changed BdG mu still requires fresh eigensolves; report every (k,mu)
evaluation, not only distinct k locations. Counts include discarded parent cells
and previous Gaussian orders.

`gm-fresh` and `gk21-fresh` construct a fresh density mesh after charge convergence.
Their extra eigensolves are included. They isolate whether inheriting a charge
mesh causes avoidable density reconstruction overhead; they are not an argument
that cache reuse is inherently poor.

`gauss` doubles tensor Gauss–Legendre order globally. It caches each order's normal
spectra through the root solve, then discards previous eigenvectors. Gauss nodes
are not nested, so previous-order evaluations cannot in general be reused. Its
stopping indicators compare successive-order density at the respective roots and
charge on the old rule at the new root. They are empirical, not rigorous bounds.
The Clenshaw–Curtis option currently does not exploit its nested point reuse, so
its cumulative runtime is a control, not an optimized competitor. Its single-rule
convergence curves remain valid. The Gaussian experimental cache is not globally
byte-capped; limit point counts when comparing peak memory with the production
periodic method's bounded cache. The separate `gauss-bounded` route uses a shared
byte-capped cache while preserving the same order sequence and error criteria.

## Fixed-mu convergence experiment

`gauss_bounded.fixed_mu_streamed` computes the CLI's single periodic, Gaussian, or
Clenshaw–Curtis tensor rule at a known mu without a full-grid vector cache.
The original `fixed_mu_rule` helper remains available as an implementation control. `run_fixed_mu_variant` computes charge and selected density on
one shared GM/GK mesh, with normalized tolerances for each output. The adaptive
fixed-mu implementation caches integrand values rather than full eigensystems,
because there is no mu search. This is a useful optimized baseline, not the
production fixed-filling workload. Both normal and BdG are supported.

Plot independently measured error against actual eigensolves, not requested
`tolerance`, final leaf count, or just the rule's own error estimate. For tensor
grids, exponential convergence is expected against points per axis, `N**(1/d)`,
not necessarily against total evaluations `N`. For adaptive meshes, compare both
log(error) versus log(N) and versus `N**(1/d)`. Do not infer a universal asymptotic
rate from two or three pre-asymptotic samples, or fit below the reference/roundoff
floor. Convergence plots at fixed mu separate sampling behavior from changing
root tolerances, root counts and mesh inheritance.

## Interpretive limitations

A 48-site supercell shrinks the Brillouin zone relative to a one-site primitive
cell. In a clean folded model, integrating one supercell k point already samples
many folded primitive bands. Thus an extremely small periodic grid on a large
cell can be physically reasonable, but does not imply every 48-orbital model is
similarly smooth. Keep the primitive one-band and shifted-pocket controls.

Uniform periodic cancellation may make the true global error much smaller than
sum-of-local-error estimates reported by adaptive cubature. If periodic wins,
separate fewer necessary samples from a less conservative convergence criterion.
Check shifted/nonnested independent references and deliberate aliasing models.
No finite deterministic set of checks certifies all analytic Hamiltonians.

Dense LAPACK normalization is a conditional lower-bound comparison. For normal
cached-spectra paths, use full eigensolve count times the fastest tested full
Hermitian eigensolver. If a path uses eigenvalues-only solves, measure/count those
separately. Assembly, selected-density reconstruction and adaptive control remain
real workload even when the eigensolver is optimal. For BdG always count repeated
mu evaluations. The fastest measured driver within the current BLAS/LAPACK build
is not a proof of the fastest hardware/backend implementation available.
