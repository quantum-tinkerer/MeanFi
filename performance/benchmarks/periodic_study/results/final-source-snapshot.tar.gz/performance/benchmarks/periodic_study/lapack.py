"""Sequential one-thread full-eigensystem LAPACK baselines for each study model."""

import os
import argparse
import json
from pathlib import Path
import statistics
import time


for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[variable] = "1"


# Set thread limits before importing numerical libraries and MeanFi.
import numpy as np  # noqa: E402
from scipy.linalg import lapack  # noqa: E402
from threadpoolctl import threadpool_limits  # noqa: E402
from models import build_problem  # noqa: E402
import meanfi  # noqa: E402


def options(name, size, vectors=True):
    opts = dict(compute_v=int(vectors), lower=1, overwrite_a=1)
    query = getattr(lapack, name + "_lwork")
    if name == "zheevd":
        w, iw, rw, info = query(size, compute_v=int(vectors), lower=1)
        opts.update(lwork=int(w.real), liwork=int(iw), lrwork=int(rw))
    elif name == "zheevr":
        w, rw, iw, info = query(size, lower=1)
        opts.update(lwork=int(w.real), lrwork=int(rw), liwork=int(iw))
    else:
        w, info = query(size, lower=1)
        opts.update(lwork=int(w.real))
    if info != 0:
        raise RuntimeError(f"LAPACK workspace query: {info}")
    return opts


def baseline(model, count=64, repeats=3):
    problem = build_problem(model, temperature=0.05)
    rng = np.random.default_rng(8247)
    points = rng.uniform(-np.pi, np.pi, (count, problem.ndim))
    matrices = np.asarray(meanfi.tb_to_kfunc(problem.full_h)(points), dtype=complex)
    if problem.kind == "bdg":
        mus = rng.uniform(-0.4, 0.4, count)
        matrices = matrices - mus[:, None, None] * np.diag(problem.q_diag)
    rows = []
    names = ["zheev", "zheevd", "zheevr", "zheevx", "numpy"]
    timings = {name: [] for name in names}
    residuals = {}
    opts = {
        name: options(name, problem.matrix_size) for name in names if name != "numpy"
    }
    with threadpool_limits(limits=1):
        for name in names:
            if name == "numpy":
                eigenvalues, vectors = np.linalg.eigh(matrices[0])
            else:
                result = getattr(lapack, name)(
                    np.array(matrices[0], order="F"), **opts[name]
                )
                if result[-1] != 0:
                    raise RuntimeError(f"{name}: {result[-1]}")
                eigenvalues, vectors = result[:2]
            residuals[name] = float(
                np.linalg.norm(matrices[0] @ vectors - vectors * eigenvalues)
                / max(1.0, np.linalg.norm(matrices[0]))
            )
            if residuals[name] > 1e-12:
                raise RuntimeError(f"{name} residual: {residuals[name]}")
        for _ in range(repeats):
            for name in rng.permutation(names):
                if name == "numpy":
                    work = matrices.copy()
                    start = time.perf_counter()
                    np.linalg.eigh(work)
                else:
                    work = [np.array(matrix, order="F") for matrix in matrices]
                    function = getattr(lapack, name)
                    kwargs = opts[name]
                    start = time.perf_counter()
                    for matrix in work:
                        result = function(matrix, **kwargs)
                        if result[-1] != 0:
                            raise RuntimeError(f"{name}: {result[-1]}")
                timings[name].append((time.perf_counter() - start) / count)
    value_times = {}
    with threadpool_limits(limits=1):
        for name in names:
            samples = []
            kwargs = (
                None
                if name == "numpy"
                else options(name, problem.matrix_size, vectors=False)
            )
            for _ in range(repeats):
                work = (
                    matrices.copy()
                    if name == "numpy"
                    else [np.array(a, order="F") for a in matrices]
                )
                start = time.perf_counter()
                if name == "numpy":
                    np.linalg.eigvalsh(work)
                else:
                    for matrix in work:
                        result = getattr(lapack, name)(matrix, **kwargs)
                        if result[-1] != 0:
                            raise RuntimeError((name, result[-1]))
                samples.append((time.perf_counter() - start) / count)
            value_times[name] = statistics.median(samples)
    for name in names:
        rows.append(
            dict(
                driver=name,
                median_s=statistics.median(timings[name]),
                repeats_s=timings[name],
                residual=residuals[name],
            )
        )
    rows.sort(key=lambda row: row["median_s"])
    return dict(
        model=model,
        matrix_size=problem.matrix_size,
        physical_sites=problem.physical_sites,
        sample_count=count,
        repeats=repeats,
        threads=1,
        dtype="complex128",
        all_eigenvectors=True,
        input_preparation_timed=False,
        fastest_s=rows[0]["median_s"],
        fastest_driver=rows[0]["driver"],
        drivers=rows,
        eigenvalues_only_s=min(value_times.values()),
        eigenvalues_only_drivers=value_times,
        note="Representative matrix sample, not exact replay of every adaptive (k,mu) solve.",
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", nargs="+", required=True)
    parser.add_argument("--count", type=int, default=64)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    records = []
    for name in args.models:
        record = baseline(name, args.count, args.repeats)
        records.append(record)
        Path(args.output).write_text(json.dumps(records, indent=2) + "\n")
        print(
            json.dumps(
                {
                    key: record[key]
                    for key in ("model", "matrix_size", "fastest_s", "fastest_driver")
                }
            ),
            flush=True,
        )
