"""Bounded-memory Gaussian comparator and streamed fixed-mu global rules.

The increasing-order method delegates its order sequence, root solver, acceptance
criteria and result assembly to variants.run_increasing_order. Only _RuleState's
storage/evaluation is temporarily replaced. The cache byte limit is shared across
all live orders, including the coarse order needed for the same-mu charge check.
Normal eigenvalues are retained in full when they fit. Dense eigenvectors are
retained in batches while space permits, then recomputed/streamed for density.
BdG caches only one mu per order; all repeated (k,mu) solves count as work.
"""

from __future__ import annotations

from contextlib import contextmanager
import time

import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits

import meanfi
from meanfi.density.kpoint.matrix_functions.direct import (
    selected_density_values_from_eigensystem,
)
import variants


def _point_outputs(problem, points, ee, vv, mu, *, density):
    bdg = problem.kind == "bdg"
    occupation = (
        expit(-ee / problem.temperature)
        if bdg
        else expit((mu - ee) / problem.temperature)
    )
    if bdg:
        band_weights = np.sum(np.abs(vv[:, : problem.physical_sites, :]) ** 2, axis=1)
        charge = np.sum(band_weights * occupation, axis=1)
        derivative = None
    else:
        charge = occupation.sum(axis=1)
        derivative = np.sum(occupation * (1 - occupation), axis=1) / problem.temperature
    if not density:
        return charge, derivative, None
    coords = problem.coordinates
    phases = np.exp(1j * points @ np.asarray(coords.keys).T)
    if coords.value_count >= problem.matrix_size**2:
        # Dense matrix reconstruction is substantially cheaper than selected
        # contractions once the requested entry count approaches a full matrix.
        matrix = (vv * occupation[:, None, :]) @ vv.conj().swapaxes(-1, -2)
        values = np.empty((len(points), coords.value_count), complex)
        for i, (_, rows, cols, section) in enumerate(coords.iter_key_coordinates()):
            values[:, section] = matrix[:, rows, cols] * phases[:, i, None]
    else:
        values = selected_density_values_from_eigensystem(
            vv, occupation, coords, phases=phases
        )
    return charge, derivative, values


class _Budget:
    def __init__(self, limit):
        self.limit = int(limit)
        self.used = self.peak = 0

    def reserve(self, count):
        if self.used + count > self.limit:
            return False
        self.used += count
        self.peak = max(self.peak, self.used)
        return True

    def release(self, count):
        self.used -= count


class _BoundedRuleState:
    def __init__(self, problem, points, weights, stats, batch_size, budget):
        self.problem, self.points, self.weights = problem, points, weights
        self.stats, self.batch_size, self.budget = stats, int(batch_size), budget
        self.hk = meanfi.tb_to_kfunc(problem.full_h)
        self.bdg = problem.kind == "bdg"
        self.size = problem.matrix_size
        self.last_mu = None
        self.blocks = []
        self.full_values = None
        self.full_value_bytes = 0
        self.released = False
        if not self.bdg:
            nbytes = len(points) * self.size * 8
            if budget.reserve(nbytes):
                try:
                    self.full_values = np.empty((len(points), self.size))
                    self.full_value_bytes = nbytes
                except BaseException:
                    budget.release(nbytes)
                    raise
        for lo in range(0, len(points), self.batch_size):
            tail = min(lo + self.batch_size, len(points))
            self.blocks.append(
                dict(
                    lo=lo,
                    tail=tail,
                    valid=False,
                    values=None,
                    vectors=None,
                    value_bytes=0,
                    vector_bytes=0,
                )
            )
        self.stats["new_spatial_points"] = self.stats.get(
            "new_spatial_points", 0
        ) + len(points)

    @property
    def vv(self):
        # The original controller only assigns vv=None to discard old normal
        # vectors; never materialize one array containing this entire grid.
        return None

    @vv.setter
    def vv(self, value):
        if value is not None:
            raise ValueError("Bounded Gaussian state cannot accept a full vector grid")
        for block in self.blocks:
            if block["vectors"] is not None:
                self.budget.release(block["vector_bytes"])
                block["vectors"] = None
                block["vector_bytes"] = 0

    def _clear(self):
        for block in self.blocks:
            self.budget.release(block["value_bytes"] + block["vector_bytes"])
            block.update(
                values=None, vectors=None, value_bytes=0, vector_bytes=0, valid=False
            )

    def __del__(self):
        if getattr(self, "released", True):
            return
        self._clear()
        self.budget.release(self.full_value_bytes)
        self.full_values = None
        self.full_value_bytes = 0
        self.released = True

    def _spectra(self, mu, *, vectors):
        if self.bdg and mu != self.last_mu:
            self._clear()
            self.last_mu = mu
        for block in self.blocks:
            lo, tail = block["lo"], block["tail"]
            cached_values = (
                self.full_values[lo:tail]
                if self.full_values is not None and block["valid"]
                else block["values"]
            )
            if cached_values is not None and (
                not vectors or block["vectors"] is not None
            ):
                yield lo, tail, cached_values, block["vectors"]
                continue
            t = time.perf_counter()
            matrix = self.hk(self.points[lo:tail])
            if self.bdg:
                ii = np.arange(self.size)
                matrix[:, ii, ii] -= mu * self.problem.q_diag
            self.stats["matrix_s"] = (
                self.stats.get("matrix_s", 0.0) + time.perf_counter() - t
            )
            npoint = tail - lo
            additional_values = (
                0
                if self.full_values is not None or cached_values is not None
                else npoint * self.size * 8
            )
            can_cache_vectors = (
                self.budget.used + additional_values + npoint * self.size**2 * 16
                <= self.budget.limit
            )
            t = time.perf_counter()
            if vectors or can_cache_vectors:
                ee, vv = np.linalg.eigh(matrix)
                name = "eigh"
            else:
                ee, vv = np.linalg.eigvalsh(matrix), None
                name = "eigvalsh"
            self.stats[name + "_s"] = (
                self.stats.get(name + "_s", 0.0) + time.perf_counter() - t
            )
            self.stats[name + "_matrices"] = (
                self.stats.get(name + "_matrices", 0) + npoint
            )
            if self.full_values is not None:
                self.full_values[lo:tail] = ee
                block["valid"] = True
            elif block["values"] is None and self.budget.reserve(ee.nbytes):
                block["values"] = ee
                block["value_bytes"] = ee.nbytes
            if (
                vv is not None
                and block["vectors"] is None
                and self.budget.reserve(vv.nbytes)
            ):
                block["vectors"] = vv
                block["vector_bytes"] = vv.nbytes
            yield lo, tail, ee, vv

    def charge(self, mu):
        charge = derivative = 0.0
        for lo, tail, ee, vv in self._spectra(mu, vectors=self.bdg):
            t = time.perf_counter()
            qq, dd, _ = _point_outputs(
                self.problem, self.points[lo:tail], ee, vv, mu, density=False
            )
            charge += float(np.dot(self.weights[lo:tail], qq))
            if dd is not None:
                derivative += float(np.dot(self.weights[lo:tail], dd))
            self.stats["charge_s"] = (
                self.stats.get("charge_s", 0.0) + time.perf_counter() - t
            )
        self.stats["charge_calls"] = self.stats.get("charge_calls", 0) + 1
        self.stats["charge_points"] = self.stats.get("charge_points", 0) + len(
            self.points
        )
        return charge, 0.0, None if self.bdg else derivative

    def density(self, mu):
        density = np.zeros(self.problem.coordinates.value_count, complex)
        for lo, tail, ee, vv in self._spectra(mu, vectors=True):
            t = time.perf_counter()
            _, _, values = _point_outputs(
                self.problem, self.points[lo:tail], ee, vv, mu, density=True
            )
            density += np.einsum("p,pv->v", self.weights[lo:tail], values)
            self.stats["density_s"] = (
                self.stats.get("density_s", 0.0) + time.perf_counter() - t
            )
        self.stats["density_points"] = self.stats.get("density_points", 0) + len(
            self.points
        )
        return density


@contextmanager
def _bounded_states(budget):
    original = variants._RuleState

    def factory(problem, points, weights, stats, batch_size):
        return _BoundedRuleState(problem, points, weights, stats, batch_size, budget)

    variants._RuleState = factory
    try:
        yield
    finally:
        variants._RuleState = original


def run_gauss_bounded(
    problem,
    tolerance,
    charge_tolerance,
    *,
    max_cache_bytes=512 * 1024**2,
    family="gauss",
    batch_size=256,
    max_order=256,
    max_points=131072,
    initial_order=8,
    root_tolerance=None,
    mu_guess=0.0,
    **kwargs,
):
    """Same global order-doubling experiment with one shared bounded cache."""
    if max_cache_bytes < 0:
        raise ValueError("max_cache_bytes must be nonnegative")
    budget = _Budget(max_cache_bytes)
    with _bounded_states(budget):
        record = variants.run_increasing_order(
            problem,
            tolerance,
            charge_tolerance,
            family=family,
            batch_size=batch_size,
            max_order=max_order,
            max_points=max_points,
            initial_order=initial_order,
            root_tolerance=root_tolerance,
            mu_guess=mu_guess,
        )
    record["variant"] = family + "-bounded"
    record["cache_peak_bytes"] = budget.peak
    record["max_cache_bytes"] = max_cache_bytes
    record["memory_policy"] = (
        "one shared cache across live orders; streamed density after cache fills"
    )
    return record


def fixed_mu_streamed(
    problem, mu, family, order, *, batch_size=256, shift=0.0, **kwargs
):
    """One streamed charge/density pass, no full-grid eigensystem allocation.

    Node/weight generation is included. ``order`` has the same convention as
    variants.tensor_rule: n nodes/axis for periodic/Gauss, n intervals/axis for CC.
    The returned n_points/eigh_matrices counts actual samples exactly once.
    """
    stats = dict(eigh_s=0.0, eigh_matrices=0, matrix_s=0.0, density_s=0.0, charge_s=0.0)
    with threadpool_limits(limits=1):
        start = time.perf_counter()
        points, weights = variants.tensor_rule(problem.ndim, family, order, shift=shift)
        hk = meanfi.tb_to_kfunc(problem.full_h)
        total_charge = 0.0
        total_density = np.zeros(problem.coordinates.value_count, complex)
        for lo in range(0, len(points), batch_size):
            tail = lo + batch_size
            pp = points[lo:tail]
            t = time.perf_counter()
            matrix = hk(pp)
            if problem.kind == "bdg":
                ii = np.arange(problem.matrix_size)
                matrix[:, ii, ii] -= mu * problem.q_diag
            stats["matrix_s"] += time.perf_counter() - t
            t = time.perf_counter()
            ee, vv = np.linalg.eigh(matrix)
            stats["eigh_s"] += time.perf_counter() - t
            stats["eigh_matrices"] += len(pp)
            t = time.perf_counter()
            charge, _, density = _point_outputs(problem, pp, ee, vv, mu, density=True)
            total_charge += float(np.dot(weights[lo:tail], charge))
            total_density += np.einsum("p,pv->v", weights[lo:tail], density)
            stats["density_s"] += time.perf_counter() - t
        wall = time.perf_counter() - start
    stats.update(
        new_spatial_points=len(points),
        charge_points=len(points),
        density_points=len(points),
    )
    return dict(
        status="success",
        family=family,
        order=order,
        mu=float(mu),
        filling=total_charge,
        density_real=total_density.real.tolist(),
        density_imag=total_density.imag.tolist(),
        wall_s=wall,
        timing=stats,
        n_points=len(points),
        weight_sum=float(weights.sum()),
        memory_policy="streamed fixed-mu eigensystems; no full-grid vector cache",
    )
