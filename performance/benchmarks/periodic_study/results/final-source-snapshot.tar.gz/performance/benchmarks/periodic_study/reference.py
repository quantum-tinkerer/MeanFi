"""Independent streamed shifted-grid reference calculations.

No production quadrature or selected-eigenvector contraction is used. Hamiltonians
are assembled explicitly from Fourier coefficients and full covariance matrices
are formed before entries are extracted. Grids must be empirically qualified with
a second, finer non-dyadic grid; one reference is never a certificate by itself.
"""

from __future__ import annotations
from pathlib import Path
import time
import numpy as np
from scipy.optimize import brentq
from scipy.special import expit


def grid_batches(shape, ndim, batch_size=128, shift=0.371):
    shape = (int(shape),) * ndim if np.isscalar(shape) else tuple(map(int, shape))
    if len(shape) != ndim or min(shape) < 1:
        raise ValueError("grid shape must have one positive integer per dimension")
    shifts = (float(shift),) * ndim if np.isscalar(shift) else tuple(map(float, shift))
    total = int(np.prod(shape))
    for start in range(0, total, batch_size):
        indices = np.stack(
            np.unravel_index(np.arange(start, min(start + batch_size, total)), shape),
            axis=-1,
        )
        points = 2 * np.pi * (indices + np.asarray(shifts)) / np.asarray(shape) - np.pi
        yield start, points


def make_hamiltonian(problem):
    coefficients = problem.full_h
    keys = np.array(list(coefficients), dtype=float)
    matrices = np.array([coefficients[tuple(map(int, key))] for key in keys], complex)

    def hamiltonian(points, mu=0.0):
        phases = np.exp(-1j * points @ keys.T)
        result = np.einsum("pk,kij->pij", phases, matrices, optimize=True)
        if mu:
            ii = np.arange(problem.matrix_size)
            result[:, ii, ii] -= mu * problem.q_diag
        return result

    return hamiltonian


def full_covariance_values(eigenvalues, eigenvectors, points, problem, mu=0.0):
    """An independent full-matrix contraction, then explicit Fourier extraction."""
    occupations = expit((mu - eigenvalues) / problem.temperature)
    covariance = (
        eigenvectors * occupations[:, None, :]
    ) @ eigenvectors.conj().transpose(0, 2, 1)
    values = np.empty((len(points), problem.coordinates.value_count), complex)
    for key, rows, cols, sl in problem.coordinates.iter_key_coordinates():
        phase = np.exp(1j * points @ np.asarray(key))
        values[:, sl] = covariance[:, rows, cols] * phase[:, None]
    charge = np.real(
        np.trace(
            covariance[:, : problem.physical_sites, : problem.physical_sites],
            axis1=1,
            axis2=2,
        )
    )
    hermiticity = float(
        np.max(np.abs(covariance - covariance.conj().transpose(0, 2, 1)))
    )
    return values, charge, hermiticity


def grid_reference(
    problem,
    *,
    nk,
    shift=0.371,
    batch_size=128,
    mu=None,
    output=None,
    root_mu_guess=None,
):
    """Reference at a supplied chemical potential or independently solved filling.

    Normal spectra are persisted beside JSON to validate charge at every candidate
    mu cheaply. BdG spectra depend on mu; use a separate --mu-from reference for an
    exact grid charge check at a candidate mu. Counts include reference root work.
    """
    if problem.temperature <= 0:
        raise ValueError("This finite-temperature reference requires T>0")
    shape = (int(nk),) * problem.ndim if np.isscalar(nk) else tuple(map(int, nk))
    total = int(np.prod(shape))
    hk = make_hamiltonian(problem)
    start = time.perf_counter()
    stats = dict(
        eigh_matrices=0,
        eigvalsh_matrices=0,
        eigh_s=0.0,
        eigvalsh_s=0.0,
        hamiltonian_s=0.0,
        density_s=0.0,
        charge_calls=0,
    )
    all_eigenvalues = None

    def diagonalize(points, chemical_potential, vectors):
        t = time.perf_counter()
        a = hk(points, chemical_potential)
        stats["hamiltonian_s"] += time.perf_counter() - t
        t = time.perf_counter()
        result = np.linalg.eigh(a) if vectors else np.linalg.eigvalsh(a)
        field = "eigh" if vectors else "eigvalsh"
        stats[field + "_s"] += time.perf_counter() - t
        stats[field + "_matrices"] += len(points)
        return result

    def bdg_charge(chemical_potential):
        stats["charge_calls"] += 1
        charge = 0.0
        for _, points in grid_batches(shape, problem.ndim, batch_size, shift):
            eigenvalues, eigenvectors = diagonalize(points, chemical_potential, True)
            occupation = expit(-eigenvalues / problem.temperature)
            electron_weights = np.sum(
                abs(eigenvectors[:, : problem.physical_sites, :]) ** 2, axis=1
            )
            charge += np.sum(occupation * electron_weights)
        return float(charge / total)

    supplied_mu = mu is not None
    root_start = time.perf_counter()
    if problem.kind == "normal":
        all_eigenvalues = np.empty((total, problem.matrix_size))
        for offset, points in grid_batches(shape, problem.ndim, batch_size, shift):
            all_eigenvalues[offset : offset + len(points)] = diagonalize(
                points, 0.0, False
            )

        def normal_charge(m):
            stats["charge_calls"] += 1
            return float(
                np.mean(
                    np.sum(expit((m - all_eigenvalues) / problem.temperature), axis=1)
                )
            )

        if mu is None:
            lo = float(all_eigenvalues.min() - 40 * problem.temperature - 1)
            hi = float(all_eigenvalues.max() + 40 * problem.temperature + 1)
            mu = float(
                brentq(lambda m: normal_charge(m) - problem.filling, lo, hi, xtol=1e-13)
            )
        charge_at_mu = normal_charge(mu)
    else:
        if mu is None:
            bound = (
                sum(
                    float(np.max(np.sum(abs(matrix), axis=1)))
                    for matrix in problem.full_h.values()
                )
                + 40 * problem.temperature
                + 1
            )
            lo, hi = -bound, bound
            if root_mu_guess is not None:
                guess = float(root_mu_guess)
                # A narrow bracket near a verified candidate can reduce reference
                # work while retaining Brent's bracketing guarantee.
                width = max(problem.temperature * 0.1, 1e-5)
                for _ in range(20):
                    a, b = guess - width, guess + width
                    fa, fb = (
                        bdg_charge(a) - problem.filling,
                        bdg_charge(b) - problem.filling,
                    )
                    if fa <= 0 <= fb:
                        lo, hi = a, b
                        break
                    width *= 2
            mu = float(
                brentq(lambda m: bdg_charge(m) - problem.filling, lo, hi, xtol=1e-13)
            )
        charge_at_mu = None
    root_wall = time.perf_counter() - root_start
    density = np.zeros(problem.coordinates.value_count, complex)
    charge = 0.0
    max_hermiticity = 0.0
    min_abs_eigenvalue = np.inf
    spectral_min = np.inf
    spectral_max = -np.inf
    for offset, points in grid_batches(shape, problem.ndim, batch_size, shift):
        shifted = 0.0 if problem.kind == "normal" else mu
        eigenvalues, eigenvectors = diagonalize(points, shifted, True)
        t = time.perf_counter()
        v, c, herr = full_covariance_values(
            eigenvalues,
            eigenvectors,
            points,
            problem,
            mu=mu if problem.kind == "normal" else 0.0,
        )
        density += v.sum(axis=0) / total
        charge += float(c.sum()) / total
        max_hermiticity = max(max_hermiticity, herr)
        physical_eigenvalues = (
            eigenvalues - mu if problem.kind == "normal" else eigenvalues
        )
        min_abs_eigenvalue = min(
            min_abs_eigenvalue, float(np.min(abs(physical_eigenvalues)))
        )
        spectral_min = min(spectral_min, float(physical_eigenvalues.min()))
        spectral_max = max(spectral_max, float(physical_eigenvalues.max()))
        stats["density_s"] += time.perf_counter() - t
    if output is not None and all_eigenvalues is not None:
        spectrum_path = Path(output).with_suffix(".npz")
        np.savez_compressed(spectrum_path, eigenvalues=all_eigenvalues)
    else:
        spectrum_path = None
    return dict(
        status="success",
        reference=True,
        problem=problem.summary(),
        nk=list(shape),
        shift=shift,
        n_points=total,
        mu=float(mu),
        filling=charge,
        target_filling=problem.filling,
        root_solved=not supplied_mu,
        density_real=density.real.tolist(),
        density_imag=density.imag.tolist(),
        wall_s=time.perf_counter() - start,
        root_wall_s=root_wall,
        timing=stats,
        maximum_covariance_hermiticity_error=max_hermiticity,
        sampled_minimum_abs_eigenvalue=min_abs_eigenvalue,
        spectral_range=[spectral_min, spectral_max],
        spectrum_file=None if spectrum_path is None else str(spectrum_path.resolve()),
        charge_eigenspectrum_crosscheck=None
        if charge_at_mu is None
        else abs(charge - charge_at_mu),
        reference_qualification="requires independent finer-grid agreement",
    )


def density_values(record):
    return np.asarray(record["density_real"]) + 1j * np.asarray(record["density_imag"])


def reference_charge(reference, mu):
    if reference.get("reference_backend") == "primitive" and reference.get(
        "spectrum_file"
    ):
        from primitive_reference import charge_from_reference

        return charge_from_reference(reference, mu)
    if reference["problem"]["kind"] == "normal" and reference.get("spectrum_file"):
        eigenvalues = np.load(reference["spectrum_file"])["eigenvalues"]
        return float(
            np.mean(
                np.sum(
                    expit((mu - eigenvalues) / reference["problem"]["temperature"]),
                    axis=1,
                )
            )
        )
    if abs(reference["mu"] - mu) < 1e-13:
        return float(reference["filling"])
    return None


def assess_result(result, references, tolerance=None):
    """Compare a candidate with qualified references, explicitly mark unknowns.

    Root-reference rho comparison measures the entire calculation (root+integral).
    An at-candidate-mu reference measures quadrature error alone. The distinction
    is retained rather than silently treating those quantities as identical.
    """
    tolerance = float(
        tolerance if tolerance is not None else result["config"]["tolerance"]
    )
    filling_target = result.get(
        "physical_filling_target", result.get("config", {}).get("filling_target")
    )
    filling_target = tolerance if filling_target is None else float(filling_target)
    if result.get("status") != "success":
        return dict(qualified=False, reason="calculation did not succeed")
    valid = [
        r for r in references if r.get("status") == "success" and r.get("reference")
    ]
    same = [
        r
        for r in valid
        if r["problem"]["name"] == result["problem"]["name"]
        and r["problem"]["temperature"] == result["problem"]["temperature"]
    ]
    same.sort(key=lambda r: r["n_points"])
    if not same:
        return dict(qualified=False, reason="no matching reference")
    primitive = [r for r in same if r.get("reference_backend") == "primitive"]
    if len(primitive) >= 2:
        same = primitive
    roots = [r for r in same if r.get("root_solved")]
    at_mu = [r for r in same if abs(r["mu"] - result["mu"]) < 1e-13]
    density_refs = roots if len(roots) >= 2 else at_mu
    result_values = density_values(result)
    assessment = dict(
        tolerance=tolerance,
        physical_filling_target=filling_target,
        qualified=False,
        reference_type="reference-root density"
        if density_refs is roots
        else "same-mu density",
    )
    if len(density_refs) >= 2:
        prev, best = density_refs[-2:]
        uncertainty = float(np.max(abs(density_values(best) - density_values(prev))))
        error = float(np.max(abs(result_values - density_values(best))))
        assessment.update(
            density_error=error,
            reference_density_change=uncertainty,
            density_reference_nk=best["nk"],
            mu_reference=best["mu"],
        )
    elif density_refs:
        best = density_refs[-1]
        assessment.update(
            density_error=float(np.max(abs(result_values - density_values(best)))),
            density_reference_nk=best["nk"],
            reason="only one density reference",
        )
    charge_refs = []
    for r in same:
        charge = reference_charge(r, result["mu"])
        if charge is not None:
            charge_refs.append((r, charge))
    if len(charge_refs) >= 2:
        (prev, previous_charge), (best, charge) = charge_refs[-2:]
        assessment.update(
            physical_charge_error=abs(charge - result["problem"]["filling"]),
            reference_charge_change=abs(charge - previous_charge),
            physical_charge_at_result_mu=charge,
            charge_reference_nk=best["nk"],
        )
    elif charge_refs:
        best, charge = charge_refs[-1]
        assessment.update(
            physical_charge_error=abs(charge - result["problem"]["filling"]),
            physical_charge_at_result_mu=charge,
            reason="only one charge reference at candidate mu",
        )
    elif result["problem"]["kind"] == "bdg" and len(roots) >= 2:
        previous, best = roots[-2:]
        constant = result["problem"]["physical_sites"] / (
            4 * result["problem"]["temperature"]
        )
        reference_change_bound = abs(
            best["filling"] - previous["filling"]
        ) + constant * abs(best["mu"] - previous["mu"])
        candidate_bound = abs(
            best["filling"] - result["problem"]["filling"]
        ) + constant * abs(result["mu"] - best["mu"])
        assessment.update(
            physical_charge_error=candidate_bound + reference_change_bound,
            physical_charge_error_bound=candidate_bound + reference_change_bound,
            reference_charge_change=reference_change_bound,
            charge_is_bound=True,
            charge_check="rigorous mu Lipschitz transfer plus empirical reference-grid-change bound",
            charge_reference_nk=best["nk"],
        )
    else:
        assessment["reason"] = "BdG needs reference charge evaluated at candidate mu"
    if (
        "reference_density_change" in assessment
        and "reference_charge_change" in assessment
    ):
        reference_qualified = (
            assessment["reference_density_change"] < tolerance / 10
            and assessment["reference_charge_change"] < filling_target / 10
        )
        assessment.update(
            reference_qualified=reference_qualified,
            empirical_density_pass=assessment["density_error"] < tolerance,
            empirical_charge_pass=assessment["physical_charge_error"] < filling_target,
        )
        assessment["qualified"] = bool(
            reference_qualified
            and assessment["empirical_density_pass"]
            and assessment["empirical_charge_pass"]
        )
        assessment["reason"] = (
            "passes with empirically converged references"
            if assessment["qualified"]
            else (
                "reference convergence unresolved"
                if not reference_qualified
                else "charge bound inconclusive; exact candidate-mu reference required"
                if assessment.get("charge_is_bound")
                and not assessment["empirical_charge_pass"]
                else "actual error exceeds target"
            )
        )
    return assessment
