"""Export descriptive fits and observed fixed-mu work/accuracy comparisons.

Prescribed global orders do not include order discovery or validation. A smallest
observed successful count is not a proven minimum or an end-to-end speedup.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def write_csv(path, rows):
    if not rows:
        return
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--convergence", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    data = json.loads(Path(args.convergence).read_text())
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    fits, observed, samples = [], [], []
    for case in data["cases"]:
        for family, curve in case.get("curves", {}).items():
            identity = dict(
                model=case["model"], temperature=case["temperature"], method=family
            )
            for metric in ("density", "charge"):
                fit = curve[metric + "_fit"]
                exponential = fit.get("exponential_in_resolution", {})
                algebraic = fit.get("algebraic_in_work", {})
                counts = fit.get("n_eigh", [])
                fits.append(
                    dict(
                        **identity,
                        metric=metric,
                        status=fit["status"],
                        fitted_points=fit.get("fitted_points"),
                        smallest_fitted_count=min(counts) if counts else None,
                        largest_fitted_count=max(counts) if counts else None,
                        error_decades=fit.get("error_decades"),
                        exponential_rate=exponential.get(
                            "decay_rate_per_effective_axis_point"
                        ),
                        exponential_r_squared=exponential.get("r_squared"),
                        algebraic_work_power=algebraic.get("work_power"),
                        algebraic_r_squared=algebraic.get("r_squared"),
                        reason=fit.get("reason"),
                    )
                )
            for point in curve["points"]:
                check = point["actual_errors"]
                samples.append(
                    dict(
                        **identity,
                        parameter=point["parameter"],
                        status=point["status"],
                        wall_s=point.get("wall_s"),
                        **{key: value for key, value in check.items()},
                        file=point["file"],
                    )
                )
            for tolerance in (1e-3, 1e-5, 1e-7):
                usable = []
                for point in curve["points"]:
                    check = point["actual_errors"]
                    if not check.get("usable"):
                        continue
                    # fit_floor >= 10 * the empirical reference uncertainty.
                    # Include its conservative margin in each physical check.
                    if all(
                        check[metric + "_fit_floor"] <= tolerance
                        and check[metric + "_error"] + check[metric + "_fit_floor"] / 10
                        <= tolerance
                        for metric in ("density", "charge")
                    ):
                        usable.append(point)
                row = dict(
                    **identity, density_target=tolerance, charge_target=tolerance
                )
                if usable:
                    point = min(usable, key=lambda p: p["actual_errors"]["n_eigh"])
                    check = point["actual_errors"]
                    row.update(
                        status="observed_with_reference_margin",
                        parameter=point["parameter"],
                        n_eigh=check["n_eigh"],
                        wall_s=point["wall_s"],
                        density_error=check["density_error"],
                        charge_error=check["charge_error"],
                        file=point["file"],
                    )
                else:
                    row["status"] = "no_qualified_observation_in_tested_range"
                observed.append(row)
    write_csv(output / "convergence-fits.csv", fits)
    write_csv(output / "fixed-mu-observed-work.csv", observed)
    write_csv(output / "convergence-samples.csv", samples)
    print(
        json.dumps(dict(fits=len(fits), observed=len(observed), samples=len(samples)))
    )


if __name__ == "__main__":
    main()
