"""Low-memory dense adaptive quadrature controls, with fresh density meshes.

Normal charge integration caches eigenvalues only. Its mesh is retained while mu
changes. BdG charge integration caches just node coordinates; each required
(k,mu) evaluation diagonalizes in bounded batches, contracts electron charge and
discards eigenvectors. The stateful controller retains current-mu leaf estimates.

After finding mu, integrate charge and selected density jointly on a fresh mesh,
caching integrand values instead of eigenvectors. The independent density mesh's
charge must satisfy the total physical filling tolerance. If it does not, repeat
with tighter root/charge tolerances, with a finite retry budget. Such consistency
checks are empirical safeguards and do not replace independent reference checks.
"""

from __future__ import annotations

import time

import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits

import meanfi
from meanfi.density.filling import mu_bracket, solve_mu
from stateful_quadrature import StatefulIntegrator
from variants import _tensor_gk, run_fixed_mu_variant


def run_lean(
    problem,
    tolerance,
    charge_tolerance,
    variant="gm-lean",
    *,
    max_refinements=2000,
    batch_size=256,
    derivative_scale=0.01,
    root_tolerance=None,
    mu_guess=0.0,
    max_charge_evaluations=200,
    consistency_retries=2,
    density_filling_tolerance=None,
    **kwargs,
):
    """Run a bounded-batch GM/GK comparison with compact adaptive caches.

    ``tolerance`` is the max selected-density error and overall physical filling
    target. The root residual defaults to tolerance/4; charge tolerance is supplied
    separately (normally tolerance/4). Fresh density-grid charge is an independent
    estimate; its physical residual must satisfy density_filling_tolerance,
    default tolerance. Root/charge tolerances tighten by four on each retry.

    No full-grid vector cache is allocated, but leaf payloads still grow with the
    number of adaptive nodes: normal charge payload has n eigenvalues per node;
    density payload has 1 + selected_entry_count values per node. For a request
    for every density entry this latter memory reduction is correspondingly less.
    """
    start = time.perf_counter()
    stats = dict(
        eigh_s=0.0,
        eigh_matrices=0,
        eigvalsh_s=0.0,
        eigvalsh_matrices=0,
        matrix_s=0.0,
        charge_s=0.0,
        density_s=0.0,
        charge_points=0,
        density_points=0,
        root_evaluations=0,
        charge_integrations=[],
        density_passes=[],
    )
    root_tolerance = tolerance / 4 if root_tolerance is None else root_tolerance
    density_filling_tolerance = (
        tolerance if density_filling_tolerance is None else density_filling_tolerance
    )
    record = {}
    try:
        if variant not in ("gm-lean", "gk21-lean"):
            raise ValueError("Lean variant must be gm-lean or gk21-lean")
        if problem.kind not in ("normal", "bdg") or problem.temperature <= 0:
            raise ValueError(
                "Lean quadrature requires normal/BdG at positive temperature"
            )
        if (
            min(
                tolerance,
                charge_tolerance,
                root_tolerance,
                density_filling_tolerance,
                derivative_scale,
            )
            <= 0
        ):
            raise ValueError("Tolerances and derivative_scale must be positive")
        if batch_size < 1 or consistency_retries < 0:
            raise ValueError("Invalid batch size or retry budget")
        bdg = problem.kind == "bdg"
        hamiltonian = problem.full_h
        hk = meanfi.tb_to_kfunc(hamiltonian)
        dim = problem.ndim
        if dim < 1:
            raise ValueError("Lean adaptive experiment requires a periodic direction")
        prefactor = (2 * np.pi) ** (-dim)
        size = problem.matrix_size

        def spectral_kernel(points):
            if bdg:
                return points.copy()
            values = np.empty((len(points), size))
            for lo in range(0, len(points), batch_size):
                tail = lo + batch_size
                t = time.perf_counter()
                matrix = hk(points[lo:tail])
                stats["matrix_s"] += time.perf_counter() - t
                t = time.perf_counter()
                values[lo:tail] = np.linalg.eigvalsh(matrix)
                stats["eigvalsh_s"] += time.perf_counter() - t
                stats["eigvalsh_matrices"] += len(matrix)
            return values

        def charge_values(points, payload, mu):
            if not bdg:
                t = time.perf_counter()
                occupation = expit((mu - payload) / problem.temperature)
                charge = occupation.sum(axis=1)
                derivative = (occupation * (1 - occupation)).sum(
                    axis=1
                ) / problem.temperature
                output = prefactor * np.stack(
                    (charge, derivative_scale * derivative), axis=1
                )
                stats["charge_s"] += time.perf_counter() - t
            else:
                output = np.empty((len(points), 1))
                for lo in range(0, len(points), batch_size):
                    tail = lo + batch_size
                    t = time.perf_counter()
                    matrix = hk(points[lo:tail])
                    ii = np.arange(size)
                    matrix[:, ii, ii] -= mu * problem.q_diag
                    stats["matrix_s"] += time.perf_counter() - t
                    t = time.perf_counter()
                    ee, vv = np.linalg.eigh(matrix)
                    stats["eigh_s"] += time.perf_counter() - t
                    stats["eigh_matrices"] += len(matrix)
                    t = time.perf_counter()
                    band_weight = np.sum(
                        np.abs(vv[:, : problem.physical_sites, :]) ** 2, axis=1
                    )
                    output[lo:tail, 0] = prefactor * np.sum(
                        band_weight * expit(-ee / problem.temperature), axis=1
                    )
                    stats["charge_s"] += time.perf_counter() - t
            stats["charge_points"] += len(points)
            return output

        with threadpool_limits(limits=1):
            integrator = StatefulIntegrator(
                [-np.pi] * dim,
                [np.pi] * dim,
                spectral_kernel,
                charge_values,
                rule="auto",
                batch_size=batch_size,
            )
            if variant.startswith("gk21"):
                _tensor_gk(integrator)
            candidate_mu = float(mu_guess)
            for attempt in range(consistency_retries + 1):
                charge_atol = charge_tolerance / (4**attempt)
                root_atol = root_tolerance / (4**attempt)

                def charge(mu):
                    t = time.perf_counter()
                    result = integrator.integrate(
                        mu, atol=charge_atol, rtol=0.0, max_subdivisions=max_refinements
                    )
                    stats["root_evaluations"] += 1
                    stats["charge_integrations"].append(
                        dict(
                            mu=float(mu),
                            wall_s=time.perf_counter() - t,
                            attempt=attempt,
                            kernel_evals=int(result.n_kernel_evals),
                            evaluator_evals=int(result.n_evaluator_evals),
                            leaf_nodes=int(result.n_leaf_nodes),
                            subdivisions=int(result.subdivisions),
                            status=result.status,
                            charge_error=float(abs(result.error[0])),
                        )
                    )
                    if result.status != "converged":
                        raise ValueError(
                            f"Lean charge quadrature returned {result.status}"
                        )
                    return (
                        float(result.estimate[0].real),
                        float(abs(result.error[0])),
                        None
                        if bdg
                        else float(result.estimate[1].real / derivative_scale),
                    )

                remaining = (
                    None
                    if max_charge_evaluations is None
                    else max_charge_evaluations - stats["root_evaluations"]
                )
                if remaining is not None and remaining <= 0:
                    raise ValueError(
                        "Lean quadrature exhausted total root evaluation budget"
                    )
                root = solve_mu(
                    evaluate_charge=charge,
                    initial_bracket=lambda: mu_bracket(
                        hamiltonian, problem.temperature
                    ),
                    filling=problem.filling,
                    mu_guess=candidate_mu,
                    filling_tol=root_atol,
                    mu_tol=1e-12,
                    max_charge_evaluations=remaining,
                    charge_error_tol=charge_atol,
                    use_derivative=not bdg,
                )
                candidate_mu = root.mu
                density = run_fixed_mu_variant(
                    problem,
                    candidate_mu,
                    tolerance,
                    charge_atol,
                    "gk21" if variant.startswith("gk21") else "gm",
                    max_refinements=max_refinements,
                    batch_size=batch_size,
                )
                for key, value in density["timing"].items():
                    if isinstance(value, (int, float)):
                        stats[key] = stats.get(key, 0) + value
                density_work = density["timing"].get("eigh_matrices", 0)
                stats["density_points"] += density_work
                stats["charge_points"] += density_work
                density_residual = (
                    None
                    if "filling" not in density
                    else abs(density["filling"] - problem.filling)
                )
                stats["density_passes"].append(
                    dict(
                        attempt=attempt,
                        mu=candidate_mu,
                        status=density["status"],
                        wall_s=density["wall_s"],
                        filling=density.get("filling"),
                        filling_residual=density_residual,
                        errors=density.get("errors"),
                        statistics=density.get("statistics"),
                    )
                )
                if density["status"] != "success":
                    raise ValueError(
                        f"Lean density quadrature failed: {density.get('error')}"
                    )
                if density_residual <= density_filling_tolerance:
                    record = dict(
                        status="success",
                        mu=candidate_mu,
                        filling=density["filling"],
                        root_filling=root.charge,
                        density_real=density["density_real"],
                        density_imag=density["density_imag"],
                        errors=dict(
                            density_matrix_integration=density["errors"][
                                "density_matrix_integration"
                            ],
                            charge_integration=density["errors"]["charge_integration"],
                            filling_residual=density_residual,
                            root_filling_residual=abs(root.charge - problem.filling),
                        ),
                        statistics=dict(
                            consistency_retries=attempt,
                            final_charge_leaf_nodes=stats["charge_integrations"][-1][
                                "leaf_nodes"
                            ],
                            final_density_leaf_nodes=density["statistics"][
                                "final_points"
                            ],
                            root_evaluations=stats["root_evaluations"],
                            charge_payload_values_per_node=dim if bdg else size,
                            density_payload_values_per_node=1
                            + problem.coordinates.value_count,
                            density_grid_filling_tolerance=density_filling_tolerance,
                        ),
                    )
                    break
            else:
                raise ValueError(
                    "Fresh density-grid charge remained inconsistent with requested filling after retries"
                )
    except Exception as exc:
        record = dict(status="error", error=repr(exc))
    record.update(
        wall_s=time.perf_counter() - start,
        timing=stats,
        variant=variant,
        density_tolerance=tolerance,
        charge_tolerance=charge_tolerance,
        root_tolerance=root_tolerance,
        derivative_scale=None if problem.kind == "bdg" else derivative_scale,
        memory_policy="charge spectra/coordinates only; fresh density mesh caches selected integrand values",
    )
    return record
