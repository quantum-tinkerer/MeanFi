"""One-process/one-job CLI for the MeanFi periodic integration study.

Examples (one thread; run timing jobs sequentially):
  python suite.py run --model square48 --method periodic --temperature .05 --tolerance 1e-5 --output run.json
  python suite.py reference --model square48 --temperature .05 --nk 65 --output ref65.json
  python suite.py assess --result run.json --references ref65.json ref129.json --output checked.json
  python suite.py fixed --model square48 --temperature .05 --mu-from ref129.json --method periodic --order 16 --output fixed.json
  python suite.py manifest --output manifest.json

Density tolerance is max absolute selected matrix entry. Filling tolerance is
absolute particles per supercell (not per site). Charge integration and root
residual each receive one quarter of the requested tolerance. Every run creates
JSON even on a Python exception. External timeout/kill is handled by orchestrator.
"""

from __future__ import annotations

import os
import argparse
from contextlib import contextmanager
from dataclasses import asdict
import cProfile
import json
from pathlib import Path
import resource
import signal
import time
import traceback

for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[variable] = "1"
os.environ["MKL_DYNAMIC"] = "FALSE"

# Set thread limits before importing numerical libraries and MeanFi.
import numpy as np  # noqa: E402
from threadpoolctl import threadpool_limits  # noqa: E402
from models import MODEL_NAMES, build_problem  # noqa: E402
from reference import grid_reference, assess_result  # noqa: E402
from variants import ADAPTIVE_VARIANTS, run_variant  # noqa: E402
import meanfi  # noqa: E402
from meanfi.density.density import evaluate_density_matrix_fixed_filling  # noqa: E402
from meanfi.density.integrate.bdg import solve_bdg_density_fixed_filling  # noqa: E402


METHODS = (
    "periodic",
    "periodic-unvalidated",
    "periodic-eigenvalue-priority",
    "periodic-anisotropic",
    "fermi",
    *ADAPTIVE_VARIANTS,
    "gm-lean",
    "gk21-lean",
    "gauss",
    "gauss-bounded",
    "clenshaw-curtis",
)
LAST_STATS = {}


def _json_default(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, complex):
        return dict(real=value.real, imag=value.imag)
    raise TypeError(f"Cannot serialize {type(value).__name__}")


@contextmanager
def instrument_periodic(stats):
    from meanfi.density.integrate.periodic import _PeriodicEvaluator

    old_eigh, old_eigvalsh = np.linalg.eigh, np.linalg.eigvalsh
    old_evaluate, old_eigensystem = (
        _PeriodicEvaluator.evaluate,
        _PeriodicEvaluator.eigensystem,
    )

    def wrap_eigh(original, name):
        def call(matrix, *args, **kwargs):
            start = time.perf_counter()
            try:
                return original(matrix, *args, **kwargs)
            finally:
                stats[name + "_s"] = (
                    stats.get(name + "_s", 0.0) + time.perf_counter() - start
                )
                stats[name + "_matrices"] = stats.get(name + "_matrices", 0) + int(
                    np.prod(np.shape(matrix)[:-2])
                )

        return call

    def evaluate(self, chunks, mu, **kwargs):
        start = time.perf_counter()
        stage = "density" if kwargs.get("density", False) else "charge"
        try:
            return old_evaluate(self, chunks, mu, **kwargs)
        finally:
            stats[stage + "_phase_s"] = (
                stats.get(stage + "_phase_s", 0.0) + time.perf_counter() - start
            )
            stats[stage + "_calls"] = stats.get(stage + "_calls", 0) + 1
            stats[stage + "_points"] = stats.get(stage + "_points", 0) + sum(
                len(c.points) for c in chunks
            )

    def eigensystem(self, *args, **kwargs):
        start = time.perf_counter()
        try:
            return old_eigensystem(self, *args, **kwargs)
        finally:
            stats["eigensystem_phase_s"] = (
                stats.get("eigensystem_phase_s", 0.0) + time.perf_counter() - start
            )

    np.linalg.eigh = wrap_eigh(old_eigh, "eigh")
    np.linalg.eigvalsh = wrap_eigh(old_eigvalsh, "eigvalsh")
    _PeriodicEvaluator.evaluate = evaluate
    _PeriodicEvaluator.eigensystem = eigensystem
    try:
        yield
    finally:
        np.linalg.eigh, np.linalg.eigvalsh = old_eigh, old_eigvalsh
        _PeriodicEvaluator.evaluate, _PeriodicEvaluator.eigensystem = (
            old_evaluate,
            old_eigensystem,
        )


@contextmanager
def eigenvalue_priority_cache():
    import meanfi.density.integrate.periodic as periodic
    from periodic_eigenvalue_priority import _PeriodicEvaluator

    original = periodic._PeriodicEvaluator
    periodic._PeriodicEvaluator = _PeriodicEvaluator
    try:
        yield
    finally:
        periodic._PeriodicEvaluator = original


def run_production(problem, args):
    global LAST_STATS
    tolerance = args.tolerance
    filling_target = tolerance if args.filling_target is None else args.filling_target
    charge_tol = filling_target / 4
    root_tol = filling_target / 4
    if args.method == "fermi":
        if problem.kind != "normal":
            raise ValueError("FermiSimplex is a normal-state T=0 comparator")
        method = meanfi.AdaptiveSimplex(
            density_matrix_tol=tolerance,
            charge_tol=charge_tol,
            max_refinements=args.max_refinements,
            num_threads=1,
        )
    else:
        method = meanfi.PeriodicQuadrature(
            nk=args.initial_order,
            max_nk=args.max_order,
            max_points=args.max_points,
            batch_size=args.batch_size,
            density_matrix_tol=tolerance,
            charge_tol=charge_tol,
            validate_shift=args.method != "periodic-unvalidated",
            max_cache_bytes=args.cache_mib * 1024 * 1024,
            matrix_function=meanfi.DirectDiagonalization(),
        )
    stats = {}
    LAST_STATS = stats
    with instrument_periodic(stats):
        start = time.perf_counter()
        if problem.kind == "bdg":
            result = solve_bdg_density_fixed_filling(
                problem.model,
                problem.mf,
                keys=list(problem.coordinates.keys),
                integration=method,
                filling_tol=root_tol,
                mu_tol=1e-12,
                max_charge_evaluations=200,
                mu_guess=args.mu_guess,
                density_coordinates=problem.coordinates,
            )
        else:
            _, result = evaluate_density_matrix_fixed_filling(
                problem.h,
                filling=problem.filling,
                kT=0.0 if args.method == "fermi" else problem.temperature,
                mu_guess=args.mu_guess,
                keys=list(problem.coordinates.keys),
                integration=method,
                tolerances=meanfi.ErrorTolerances(
                    1e-3, tolerance, root_tol, charge_tol
                ),
                mu_tol=1e-12,
                max_charge_evaluations=200,
                density_coordinates=problem.coordinates,
            )
        elapsed = time.perf_counter() - start
    values = result.density.values
    return dict(
        status="success",
        mu=float(result.mu),
        filling=float(result.filling),
        density_real=values.real.tolist(),
        density_imag=values.imag.tolist(),
        errors=asdict(result.errors),
        statistics=asdict(result.statistics),
        timing=stats,
        wall_s=elapsed,
        variant=args.method,
        root_tolerance=root_tol,
        charge_tolerance=charge_tol,
        density_tolerance=tolerance,
    )


def make_manifest(timeout=90):
    jobs = []
    seen = set()

    def add(stage, model, method, temperature=0.05, tolerance=1e-5, **extra):
        key = (model, method, temperature, tolerance, tuple(sorted(extra.items())))
        if key in seen:
            return
        seen.add(key)
        jobs.append(
            dict(
                stage=stage,
                model=model,
                method=method,
                temperature=temperature,
                tolerance=tolerance,
                timeout_s=timeout,
                **extra,
            )
        )

    optimized = ("periodic", "gm-derivative", "gk21-derivative", "gauss")
    for model in ("chain1", "square1", "pocket1", "alias1"):
        for method in optimized:
            add("controls", model, method)
    for model in (
        "chain48",
        "square48",
        "vanhove48",
        "anisotropic48",
        "gapped48",
        "cubic48",
        "bdg_chain48",
        "bdg_nodal48",
        "bdg_gapped48",
    ):
        methods = (
            ("periodic", "gm-charge-only", "gk21-charge-only", "gauss")
            if model.startswith("bdg_")
            else optimized
        )
        for method in methods:
            add("baseline", model, method)
    for model in ("square48", "anisotropic48", "bdg_nodal48"):
        methods = (
            ("gm", "gk21", "gm-fresh", "gk21-fresh")
            if model.startswith("bdg_")
            else (
                "gm",
                "gk21",
                "gm-charge-only",
                "gk21-charge-only",
                "gm-fresh",
                "gk21-fresh",
            )
        )
        for method in methods:
            add("optimizations", model, method)
    for model in ("chain48", "square48", "anisotropic48", "bdg_nodal48"):
        for temperature in (0.2, 0.01):
            methods = (
                ("periodic", "gm-charge-only", "gk21-charge-only")
                if model.startswith("bdg_")
                else optimized[:3]
            )
            for method in methods:
                add("temperature", model, method, temperature)
    for model in ("square48", "anisotropic48", "cubic48", "bdg_gapped48"):
        for tolerance in (1e-3, 1e-7):
            methods = (
                ("periodic", "gm-charge-only", "gk21-charge-only")
                if model.startswith("bdg_")
                else optimized[:3]
            )
            for method in methods:
                add("tolerance", model, method, tolerance=tolerance)
    for model in ("square1", "pocket1", "alias1"):
        for method in optimized:
            add("cold-controls", model, method, temperature=0.002)
    for model in ("chain48", "square48", "anisotropic48"):
        add(
            "zero-temperature-context",
            model,
            "fermi",
            temperature=0.0,
            tolerance=1e-4,
            max_refinements=100000,
        )
    # Keep the original execution order, including the two final BdG controls.
    for method in ("gm-derivative", "gk21-derivative"):
        add("optimizations", "bdg_nodal48", method)
    return dict(
        schema_version=1,
        contract=dict(
            density="max absolute selected complex entry",
            filling="absolute particles per supercell",
            root_residual="tolerance/4",
            charge_integration="tolerance/4",
            threads=1,
            timing="imports/model construction/reference generation excluded; all quadrature and mu work included",
            references="at least two independent shifted non-dyadic grids with change < tolerance/10",
        ),
        jobs=jobs,
        stages=list(dict.fromkeys(job["stage"] for job in jobs)),
        reference_suggestions=dict(
            chain48=[65, 129],
            square48=[65, 129],
            vanhove48=[65, 129],
            anisotropic48=[65, 129],
            gapped48=[33, 65],
            cubic48=[17, 33],
            bdg_chain48=[65, 129],
            bdg_nodal48=[33, 65],
            bdg_gapped48=[33, 65],
            chain1=[513, 1025],
            square1=[257, 513],
            pocket1=[257, 513],
            alias1=[1025, 2049],
        ),
        notes=[
            "Reference grid suggestions are starting points, not guaranteed sufficient.",
            "Run all benchmark jobs sequentially to avoid CPU contention.",
            "1D gm and gk21 use the same GK21 rule; 2D/3D compare distinct rules.",
            "Fermi T=0 rows are context, never same-physics finite-T competitors.",
            "Clean supercells can exploit band folding; disordered models test genuinely coupled sites.",
            "Full-gap/nodal names describe intended clean pairing; report sampled spectral gap separately.",
        ],
    )


def make_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=("run", "reference", "fixed", "assess", "manifest", "models")
    )
    parser.add_argument("--model", choices=MODEL_NAMES, default="square48")
    parser.add_argument("--temperature", "--temp", type=float, default=0.05)
    parser.add_argument("--tolerance", type=float, default=1e-5)
    parser.add_argument(
        "--filling-target",
        type=float,
        help="Independent absolute physical filling error target; defaults to --tolerance",
    )
    parser.add_argument("--method", default="periodic")
    parser.add_argument("--max-refinements", type=int, default=2000)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--initial-order", type=int, default=8)
    parser.add_argument("--max-order", type=int, default=512)
    parser.add_argument("--max-points", type=int, default=262144)
    parser.add_argument("--cache-mib", type=int, default=512)
    parser.add_argument("--derivative-scale", type=float, default=0.01)
    parser.add_argument("--nk", type=int, default=65)
    parser.add_argument(
        "--primitive",
        action="store_true",
        help="Use exact primitive-cell reference for clean models",
    )
    parser.add_argument("--shift", type=float, default=0.371)
    parser.add_argument("--order", type=int, default=16)
    parser.add_argument("--mu", type=float)
    parser.add_argument("--mu-from")
    parser.add_argument("--mu-guess", type=float, default=0.0)
    parser.add_argument("--root-mu-guess", type=float)
    parser.add_argument("--result")
    parser.add_argument("--references", nargs="*", default=[])
    parser.add_argument("--timeout", type=float, default=90.0)
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--output", required=True)
    return parser


def main():
    def timeout_signal(signum, frame):
        raise TimeoutError("External benchmark time or memory limit")

    signal.signal(signal.SIGTERM, timeout_signal)
    args = make_parser().parse_args()
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    filling_target = (
        args.tolerance if args.filling_target is None else args.filling_target
    )
    if not np.isfinite(filling_target) or filling_target <= 0:
        raise ValueError("filling_target must be positive and finite")
    if args.command == "manifest":
        record = make_manifest(args.timeout)
    elif args.command == "models":
        record = {
            name: build_problem(name, args.temperature).summary()
            for name in MODEL_NAMES
        }
    elif args.command == "assess":
        result = json.loads(Path(args.result).read_text())
        references = [json.loads(Path(path).read_text()) for path in args.references]
        record = assess_result(result, references, tolerance=args.tolerance)
    else:
        problem = build_problem(args.model, args.temperature)
        start = time.perf_counter()
        profile = cProfile.Profile() if args.profile else None
        try:
            with threadpool_limits(limits=1):
                if profile:
                    profile.enable()
                mu = args.mu
                if args.mu_from:
                    mu = float(json.loads(Path(args.mu_from).read_text())["mu"])
                if args.command == "reference":
                    if args.primitive:
                        from primitive_reference import primitive_reference

                        record = primitive_reference(
                            problem,
                            nk=args.nk,
                            shift=args.shift,
                            batch_size=max(args.batch_size, 8192),
                            mu=mu,
                            output=output,
                        )
                    else:
                        record = grid_reference(
                            problem,
                            nk=args.nk,
                            shift=args.shift,
                            batch_size=args.batch_size,
                            mu=mu,
                            output=output,
                            root_mu_guess=args.root_mu_guess,
                        )
                elif args.command == "fixed":
                    if mu is None:
                        mu = args.mu_guess
                    if args.method in ADAPTIVE_VARIANTS:
                        from variants import run_fixed_mu_variant

                        record = run_fixed_mu_variant(
                            problem,
                            mu,
                            args.tolerance,
                            filling_target / 4,
                            args.method,
                            max_refinements=args.max_refinements,
                            batch_size=args.batch_size,
                        )
                    else:
                        from gauss_bounded import fixed_mu_streamed

                        record = fixed_mu_streamed(
                            problem,
                            mu,
                            args.method,
                            args.order,
                            batch_size=args.batch_size,
                            shift=args.shift,
                        )
                elif args.method in ("periodic", "periodic-unvalidated", "fermi"):
                    record = run_production(problem, args)
                elif args.method == "periodic-eigenvalue-priority":
                    with eigenvalue_priority_cache():
                        record = run_production(problem, args)
                    record["memory_policy"] = (
                        "retain normal eigenvalues preferentially; evict vectors before spectra"
                    )
                elif args.method == "periodic-anisotropic":
                    from anisotropic import run_anisotropic

                    record = run_anisotropic(
                        problem,
                        args.tolerance,
                        filling_target / 4,
                        nk=args.initial_order,
                        max_nk=args.max_order,
                        max_points=args.max_points,
                        batch_size=args.batch_size,
                        max_cache_bytes=args.cache_mib * 1024 * 1024,
                        max_refinements=args.max_refinements,
                        max_charge_evaluations=200,
                        root_tolerance=filling_target / 4,
                        mu_guess=args.mu_guess,
                    )
                elif args.method == "gauss-bounded":
                    from gauss_bounded import run_gauss_bounded

                    record = run_gauss_bounded(
                        problem,
                        args.tolerance,
                        filling_target / 4,
                        max_cache_bytes=args.cache_mib * 1024 * 1024,
                        batch_size=args.batch_size,
                        max_order=args.max_order,
                        max_points=args.max_points,
                        initial_order=args.initial_order,
                        root_tolerance=filling_target / 4,
                        mu_guess=args.mu_guess,
                    )
                elif args.method in ("gm-lean", "gk21-lean"):
                    from adaptive_lean import run_lean

                    record = run_lean(
                        problem,
                        args.tolerance,
                        filling_target / 4,
                        args.method,
                        max_refinements=args.max_refinements,
                        batch_size=args.batch_size,
                        derivative_scale=args.derivative_scale,
                        root_tolerance=filling_target / 4,
                        mu_guess=args.mu_guess,
                        max_charge_evaluations=200,
                        density_filling_tolerance=filling_target,
                    )
                else:
                    record = run_variant(
                        problem,
                        args.tolerance,
                        filling_target / 4,
                        args.method,
                        max_refinements=args.max_refinements,
                        batch_size=args.batch_size,
                        derivative_scale=args.derivative_scale,
                        max_order=args.max_order,
                        max_points=args.max_points,
                        initial_order=args.initial_order,
                        root_tolerance=filling_target / 4,
                        mu_guess=args.mu_guess,
                    )
        except Exception as exc:
            traceback.print_exc()
            record = dict(
                status="error",
                error=repr(exc),
                wall_s=time.perf_counter() - start,
                timing=LAST_STATS,
            )
        finally:
            if profile:
                profile.disable()
                profile.dump_stats(str(output.with_suffix(".prof")))
        record.setdefault("problem", problem.summary())
        record["physical_filling_target"] = filling_target
        record["config"] = vars(args)
        record["peak_rss_mib"] = (
            resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
        )
        record["thread_limit"] = 1
        if args.references:
            references = [
                json.loads(Path(path).read_text()) for path in args.references
            ]
            record["assessment"] = assess_result(record, references, args.tolerance)
    output.write_text(json.dumps(record, indent=2, default=_json_default) + "\n")
    summary = {
        key: value
        for key, value in record.items()
        if key not in ("density_real", "density_imag", "timing", "jobs")
    }
    if "jobs" in record:
        summary["job_count"] = len(record["jobs"])
    print(json.dumps(summary, default=_json_default), flush=True)


if __name__ == "__main__":
    main()
