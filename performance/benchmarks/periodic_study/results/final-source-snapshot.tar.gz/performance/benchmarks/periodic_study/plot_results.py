"""Render standalone scientific figures from the study's audited JSON results."""

from __future__ import annotations

import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

COLORS = dict(
    periodic="#167b9d",
    gauss="#dd8430",
    gm="#9263aa",
    gk21="#448d53",
    anisotropic="#bd454f",
    **{"clenshaw-curtis": "#81705f"},
)


def family(row):
    method = row["method"]
    if method == "periodic-anisotropic":
        return "anisotropic"
    if method.startswith("periodic"):
        return "periodic"
    if method.startswith("gauss"):
        return "gauss"
    if method.startswith("gm"):
        return "gm"
    if method.startswith("gk21"):
        return "gk21"
    return method


def default_variant(row):
    if row.get("physical_filling_target", row.get("tolerance")) != row.get("tolerance"):
        return False
    method = row["method"]
    if method.startswith("periodic"):
        # Rank every tested setting under the same shifted-validation contract.
        # Starting-order and cache ablations remain distinct configurations.
        return method != "periodic-unvalidated"
    if method in (
        "gauss",
        "gauss-bounded",
        "periodic-anisotropic",
        "gm-lean",
        "gk21-lean",
    ):
        return True
    # A root strategy that is cheaper per evaluation can require more nodes.
    # Select the best qualified measured configuration across every tested path.
    return method.startswith(("gm", "gk21"))


def aggregate_configurations(options):
    """Use repetition medians, keeping different algorithms/settings distinct."""
    groups = defaultdict(list)
    for row in options:
        if row.get("wall_s") is not None and row["wall_s"] > 0:
            groups[row.get("configuration", row["method"])].append(row)
    result = []
    for configuration, rows in groups.items():
        passed = [row for row in rows if row.get("accuracy_status") == "pass"]
        used = passed or rows
        times = [row["wall_s"] for row in used]
        representative = dict(used[0])
        representative.update(
            wall_s=statistics.median(times),
            configuration=configuration,
            repeat_count=len(times),
            time_min=min(times),
            time_max=max(times),
        )
        result.append(representative)
    return result


def best_configuration(options):
    configurations = aggregate_configurations(options)
    passed = [row for row in configurations if row.get("accuracy_status") == "pass"]
    available = passed or configurations
    return min(available, key=lambda row: row["wall_s"]) if available else None


def variant_tag(method):
    return {
        "periodic": "P",
        "periodic-eigenvalue-priority": "P-eig",
        "periodic-anisotropic": "P-aniso",
        "gauss": "G",
        "gauss-bounded": "G-bnd",
        "gm-derivative": "GM-d",
        "gk21-derivative": "GK-d",
        "gm-charge-only": "GM-q",
        "gk21-charge-only": "GK-q",
        "gm-lean": "GM-lean",
        "gk21-lean": "GK-lean",
    }.get(method, method)


def configuration_tag(row, abbreviate=False):
    """Identify both algorithm and nondefault settings in selected points."""
    method = row["method"]
    configuration = row.get("configuration", method)
    if abbreviate and configuration.startswith(method):
        return variant_tag(method) + configuration[len(method) :]
    return configuration


def plot_family_sweep(ax, choices, coordinate, label):
    """Best qualified configuration median at each target; label policy changes."""
    grouped = defaultdict(list)
    for row in choices:
        grouped[row[coordinate]].append(row)
    selected = [
        (x, best_configuration(options)) for x, options in sorted(grouped.items())
    ]
    selected = [(x, row) for x, row in selected if row is not None]
    if not selected:
        return
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.scatter(
        [x for x, _ in selected],
        [row["wall_s"] for _, row in selected],
        color=COLORS[label],
        label=label,
        s=27,
    )
    for index, (x, row) in enumerate(selected):
        right_edge = x == (min(grouped) if coordinate == "tolerance" else max(grouped))
        vertical = {
            "periodic": -11,
            "gauss": -17,
            "gm": 12,
            "gk21": 5,
            "anisotropic": -11,
        }[label]
        ax.annotate(
            configuration_tag(row, abbreviate=True),
            (x, row["wall_s"]),
            xytext=(-4 if right_edge else 4, vertical),
            ha="right" if right_edge else "left",
            textcoords="offset points",
            fontsize=7,
            color=COLORS[label],
        )
        if row["repeat_count"] > 1:
            ax.errorbar(
                x,
                row["wall_s"],
                yerr=[
                    [row["wall_s"] - row["time_min"]],
                    [row["time_max"] - row["wall_s"]],
                ],
                color=COLORS[label],
                capsize=2,
                lw=0.8,
                fmt="none",
            )
        if index:
            previous_x, previous = selected[index - 1]
            if previous["configuration"] == row["configuration"]:
                ax.plot(
                    [previous_x, x],
                    [previous["wall_s"], row["wall_s"]],
                    color=COLORS[label],
                    lw=1,
                )


def save(fig, folder, name):
    fig.savefig(folder / (name + ".png"), dpi=170, bbox_inches="tight")
    fig.savefig(folder / (name + ".svg"), bbox_inches="tight")
    plt.close(fig)


def baseline(rows, folder):
    models = [
        "chain48",
        "square48",
        "vanhove48",
        "anisotropic48",
        "gapped48",
        "cubic48",
        "bdg_chain48",
        "bdg_nodal48",
        "bdg_gapped48",
    ]
    fig, axes = plt.subplots(3, 3, figsize=(16, 11.5))
    labels = ["periodic", "gauss", "gm", "gk21", "anisotropic"]
    for ax, model in zip(axes.flat, models):
        candidates = [
            r
            for r in rows
            if r["model"] == model
            and r["temperature"] == 0.05
            and r["tolerance"] == 1e-5
            and default_variant(r)
        ]
        for index, label in enumerate(labels):
            options = [r for r in candidates if family(r) == label]
            row = best_configuration(options)
            if row is None:
                continue
            wall = row["wall_s"]
            good = row.get("accuracy_status") == "pass"
            ax.barh(
                index,
                wall,
                color=COLORS[label],
                alpha=1 if good else 0.35,
                hatch=None if good else "//",
            )
            tag = f"{wall:.3g}s" if good else str(row.get("run_status", "unknown"))
            if row.get("run_status") == "success" and not good:
                tag += ": accuracy " + row.get("accuracy_status", "unknown")
            tag += (
                f"\n{configuration_tag(row, abbreviate=True)} (n={row['repeat_count']})"
            )
            if row["repeat_count"] > 1:
                ax.errorbar(
                    wall,
                    index,
                    xerr=[[wall - row["time_min"]], [row["time_max"] - wall]],
                    fmt="none",
                    color="black",
                    capsize=2,
                    lw=0.8,
                )
            ax.text(wall * 1.06, index, tag, va="center", fontsize=7)
        ax.set(
            yticks=range(len(labels)),
            yticklabels=labels,
            title=model,
            xscale="log",
            xlim=(0.003, 900),
            xlabel="Total solve time (s)",
        )
        ax.invert_yaxis()
        ax.grid(axis="x", alpha=0.2)
    fig.suptitle(
        "Fixed filling, kT=0.05, target 10⁻⁵\nFastest qualified configuration median per family; n = repetitions; hatching = failed/unqualified",
        fontsize=14,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    save(fig, folder, "baseline-runtimes")


def scaling(rows, folder):
    fig, axes = plt.subplots(2, 3, figsize=(16, 9))
    for ax, model in zip(axes[0], ["square48", "anisotropic48", "bdg_nodal48"]):
        for label in ["periodic", "gauss", "gm", "gk21", "anisotropic"]:
            choices = [
                r
                for r in rows
                if r["model"] == model
                and r["tolerance"] == 1e-5
                and r["temperature"] > 0
                and family(r) == label
                and default_variant(r)
                and r.get("accuracy_status") == "pass"
            ]
            plot_family_sweep(ax, choices, "temperature", label)
        ax.set(title=model, xlabel="kT (hopping units)", ylabel="Total solve time (s)")
        ax.margins(x=0.08, y=0.2)
        ax.grid(alpha=0.25)
    for ax, model in zip(axes[1], ["square48", "anisotropic48", "bdg_gapped48"]):
        for label in ["periodic", "gauss", "gm", "gk21", "anisotropic"]:
            choices = [
                r
                for r in rows
                if r["model"] == model
                and r["temperature"] == 0.05
                and family(r) == label
                and default_variant(r)
                and r.get("accuracy_status") == "pass"
            ]
            plot_family_sweep(ax, choices, "tolerance", label)
        ax.set(
            title=model,
            xlabel="Requested absolute target",
            ylabel="Total solve time (s)",
        )
        ax.invert_xaxis()
        ax.margins(x=0.08, y=0.2)
        ax.grid(alpha=0.25)
    axes[0, 0].legend(fontsize=8)
    fig.suptitle(
        "Temperature/tolerance sweeps: fastest qualified configuration median per family\nPoint labels identify variants and settings; lines connect only the same configuration",
        fontsize=13,
    )
    fig.text(
        0.5,
        0.01,
        "P: periodic; P-eig: eigenvalue-priority cache; P-aniso: anisotropic; G/G-bnd: Gaussian; d: relaxed derivative; q: charge-only",
        ha="center",
        fontsize=8,
    )
    fig.tight_layout(rect=(0, 0.035, 1, 0.92))
    save(fig, folder, "temperature-tolerance")


def overhead(rows, folder):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
    for label in ["periodic", "gauss", "gm", "gk21", "anisotropic"]:
        choices = [
            r
            for r in rows
            if family(r) == label
            and default_variant(r)
            and r.get("matrix_size", 0) >= 40
            and r.get("accuracy_status") == "pass"
            and r.get("lapack_overhead_ratio") is not None
        ]
        axes[0].scatter(
            [r["total_diagonalizations"] for r in choices],
            [r["lapack_overhead_ratio"] for r in choices],
            label=label,
            color=COLORS[label],
            alpha=0.7,
            s=24,
        )
        axes[1].scatter(
            [r["total_diagonalizations"] for r in choices],
            [r.get("measured_eigensolve_fraction", np.nan) for r in choices],
            label=label,
            color=COLORS[label],
            alpha=0.7,
            s=24,
        )
    axes[0].axhline(1, color="black", lw=1, linestyle="--")
    axes[0].set(
        xscale="log",
        yscale="log",
        xlabel="Actual diagonalizations (including repeats)",
        ylabel="Total time / representative fastest LAPACK cost",
    )
    axes[1].set(
        xscale="log",
        xlabel="Actual diagonalizations (including repeats)",
        ylabel="Measured fraction of time inside eigh/eigvalsh",
        ylim=(0, 1.05),
    )
    for ax in axes:
        ax.margins(x=0.08, y=0.2)
        ax.grid(alpha=0.25)
    axes[0].legend(fontsize=8)
    fig.suptitle(
        "Implementation efficiency for 48-site systems\nEigenvalues-only and full-eigensystem work are normalized separately"
    )
    fig.tight_layout(rect=(0, 0, 1, 0.9))
    save(fig, folder, "lapack-efficiency")


def convergence(data, folder):
    cases = [case for case in data.get("cases", []) if case.get("curves")]
    if not cases:
        return
    for metric in ["density", "charge"]:
        fig, axes = plt.subplots(
            len(cases), 2, figsize=(12, 3.2 * len(cases)), squeeze=False
        )
        for index, case in enumerate(cases):
            for label, curve in case["curves"].items():
                points = [
                    p["actual_errors"]
                    for p in curve["points"]
                    if p.get("actual_errors", {}).get("usable")
                ]
                if not points:
                    continue
                points.sort(key=lambda p: p["n_eigh"])
                err = [max(p[metric + "_error"], 1e-16) for p in points]
                axes[index, 0].semilogy(
                    [p["effective_resolution"] for p in points],
                    err,
                    ".-",
                    color=COLORS.get(label),
                    label=label,
                )
                axes[index, 1].loglog(
                    [p["n_eigh"] for p in points],
                    err,
                    ".-",
                    color=COLORS.get(label),
                    label=label,
                )
            ref = case["reference"]
            floor = max(1e-13, 10 * ref.get("reference_" + metric + "_uncertainty", 0))
            for ax in axes[index]:
                ax.axhspan(1e-16, floor, color="gray", alpha=0.14)
                ylabel = (
                    "Maximum density-entry error"
                    if metric == "density"
                    else "Absolute charge error (particles/cell)"
                )
                ax.set(
                    title=f"{case['model']}, kT={case['temperature']:g}", ylabel=ylabel
                )
                ax.set_ylim(bottom=1e-16)
                ax.margins(x=0.08, y=0.2)
                ax.grid(alpha=0.25)
            axes[index, 0].set_xlabel("Effective resolution: N_eigh^(1/d)")
            axes[index, 1].set_xlabel(
                "N: actual diagonalizations (discarded adaptive parents included)"
            )
        axes[0, 0].legend(ncol=3, fontsize=8)
        fig.suptitle(
            f"Fixed-μ {metric} convergence at a common independent reference μ\nLeft: exponential-in-resolution view. Right: algebraic-in-work view. Gray: excluded fit floor.",
            fontsize=13,
            y=1.001,
        )
        fig.tight_layout()
        save(fig, folder, "convergence-" + metric)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis", required=True)
    parser.add_argument("--convergence")
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    folder = Path(args.output_dir)
    folder.mkdir(parents=True, exist_ok=True)
    analysis = json.loads(Path(args.analysis).read_text())
    rows = analysis["rows"]
    baseline(rows, folder)
    scaling(rows, folder)
    overhead(rows, folder)
    if args.convergence:
        convergence(json.loads(Path(args.convergence).read_text()), folder)
    print(str(folder.resolve()))


if __name__ == "__main__":
    main()
