"""Independent primitive-cell references for exactly translation-invariant models.

A clean 48-site supercell is physically a folded one-site band (two Nambu degrees
of freedom for BdG). The benchmark still diagonalizes the full 48/96 matrix. Only
reference generation uses the exact smaller physical representation.

The checkerboard insulator uses its analytic (p,p+Q) two-sublattice covariance.
Both Fourier phases and pairing signs are checked against direct full-supercell
references on equivalent folded grids; do not use this for disordered models.
"""

from __future__ import annotations
from pathlib import Path
import time
import numpy as np
from scipy.optimize import brentq
from scipy.special import expit
from reference import grid_batches

SUPPORTED = ("vanhove48", "gapped48", "bdg_chain48", "bdg_nodal48", "bdg_gapped48")


def _parameters(problem):
    if problem.name not in SUPPORTED:
        raise ValueError(f"No exact primitive reduction for {problem.name}")
    shape = tuple(problem.metadata["shape"])
    hopping = np.asarray(
        problem.metadata.get("hopping", (1.0,) + (0.8,) * (problem.ndim - 1))
    )
    checker = problem.name == "gapped48"
    return shape, hopping, checker


def _dispersion(points, problem):
    _, hopping, checker = _parameters(problem)
    energy = -2 * np.sum(hopping[None, :] * np.cos(points), axis=1)
    if problem.kind == "bdg":
        pair = -0.4j * np.sin(points[:, 0])
        if problem.name == "bdg_gapped48":
            pair = pair + 0.4 * np.sin(points[:, 1])
    else:
        pair = np.zeros(len(points), complex)
    return energy, pair


def _charge_from_arrays(
    energy, pair_abs2, mu, temperature, kind, physical_sites, staggered=0.0
):
    if kind == "bdg":
        xi = energy - mu
        excitation = np.sqrt(xi * xi + pair_abs2)
        ratio = np.divide(
            np.tanh(excitation / (2 * temperature)),
            excitation,
            out=np.full_like(excitation, 1 / (2 * temperature)),
            where=excitation > 1e-14,
        )
        occupation = 0.5 - 0.5 * xi * ratio
    elif staggered:
        excitation = np.sqrt(energy * energy + staggered * staggered)
        occupation = 0.5 * (
            expit((mu - excitation) / temperature)
            + expit((mu + excitation) / temperature)
        )
    else:
        occupation = expit((mu - energy) / temperature)
    return float(physical_sites * np.mean(occupation))


def charge_from_reference(reference, mu):
    """Exact reference-grid charge at arbitrary mu; no large-matrix eigensolves."""
    data = np.load(reference["spectrum_file"])
    problem = reference["problem"]
    return _charge_from_arrays(
        data["energy"],
        data["pair_abs2"],
        mu,
        problem["temperature"],
        problem["kind"],
        problem["physical_sites"],
        staggered=float(problem["metadata"].get("staggered", 0.0)),
    )


def _coordinate_groups(problem):
    shape, _, checker = _parameters(problem)
    sites = np.asarray(list(np.ndindex(shape)))
    groups = {}
    for key, rows, cols, section in problem.coordinates.iter_key_coordinates():
        for offset, (row, col) in enumerate(zip(rows, cols, strict=True)):
            a, b = (
                int(row) // problem.physical_sites,
                int(col) // problem.physical_sites,
            )
            r, c = int(row) % problem.physical_sites, int(col) % problem.physical_sites
            displacement = tuple(
                (sites[c] - sites[r] + np.asarray(shape) * np.asarray(key)).tolist()
            )
            parity = int((-1) ** sum(sites[r])) if checker else 0
            groups.setdefault((a, b, displacement, parity), []).append(
                section.start + offset
            )
    return groups


def primitive_reference(
    problem, *, nk, shift=0.371, batch_size=8192, mu=None, output=None
):
    shape, hopping, checker = _parameters(problem)
    gridshape = (int(nk),) * problem.ndim if np.isscalar(nk) else tuple(map(int, nk))
    total = int(np.prod(gridshape))
    start = time.perf_counter()
    energy = np.empty(total)
    pair_abs2 = np.empty(total)
    for offset, points in grid_batches(gridshape, problem.ndim, batch_size, shift):
        ee, pp = _dispersion(points, problem)
        energy[offset : offset + len(points)] = ee
        pair_abs2[offset : offset + len(points)] = abs(pp) ** 2
    staggered = 1.5 if checker else 0.0
    supplied_mu = mu is not None
    charge_calls = 0

    def charge(candidate):
        nonlocal charge_calls
        charge_calls += 1
        return _charge_from_arrays(
            energy,
            pair_abs2,
            candidate,
            problem.temperature,
            problem.kind,
            problem.physical_sites,
            staggered,
        )

    root_start = time.perf_counter()
    if mu is None:
        bound = 2 * sum(hopping) + staggered + 40 * problem.temperature + 1
        mu = float(
            brentq(lambda m: charge(m) - problem.filling, -bound, bound, xtol=1e-13)
        )
    root_wall = time.perf_counter() - root_start
    filling = charge(mu)
    groups = _coordinate_groups(problem)
    integrals = {key: 0j for key in groups}
    minimum_excitation = np.inf
    for offset, points in grid_batches(gridshape, problem.ndim, batch_size, shift):
        ee = energy[offset : offset + len(points)]
        if problem.kind == "bdg":
            _, pair = _dispersion(points, problem)
            xi = ee - mu
            excitation = np.sqrt(xi * xi + abs(pair) ** 2)
            ratio = np.divide(
                np.tanh(excitation / (2 * problem.temperature)),
                excitation,
                out=np.full_like(excitation, 1 / (2 * problem.temperature)),
                where=excitation > 1e-14,
            )
            blocks = {
                (0, 0): 0.5 - 0.5 * xi * ratio,
                (1, 1): 0.5 + 0.5 * xi * ratio,
                (0, 1): -0.5 * pair * ratio,
                (1, 0): -0.5 * pair.conj() * ratio,
            }
            minimum_excitation = min(minimum_excitation, float(excitation.min()))
        elif checker:
            excitation = np.sqrt(ee * ee + staggered * staggered)
            plus = expit((mu - excitation) / problem.temperature)
            minus = expit((mu + excitation) / problem.temperature)
            average = (plus + minus) * 0.5
            factor = (plus - minus) / (2 * excitation)
            minimum_excitation = min(
                minimum_excitation, float(np.min(abs(excitation - abs(mu))))
            )
        else:
            blocks = {(0, 0): expit((mu - ee) / problem.temperature)}
            minimum_excitation = min(minimum_excitation, float(np.min(abs(ee - mu))))
        for key in groups:
            a, b, displacement, parity = key
            covariance = (
                (average + factor * (ee + staggered * parity))
                if checker
                else blocks[(a, b)]
            )
            integrals[key] += (
                np.sum(np.exp(1j * points @ np.asarray(displacement)) * covariance)
                / total
            )
    density = np.empty(problem.coordinates.value_count, complex)
    for key, indices in groups.items():
        density[indices] = integrals[key]
    if output is not None:
        spectrum_path = Path(output).with_suffix(".npz")
        np.savez_compressed(spectrum_path, energy=energy, pair_abs2=pair_abs2)
    else:
        spectrum_path = None
    return dict(
        status="success",
        reference=True,
        reference_backend="primitive",
        problem=problem.summary(),
        nk=list(gridshape),
        shift=shift,
        n_points=total,
        mu=float(mu),
        filling=filling,
        target_filling=problem.filling,
        root_solved=not supplied_mu,
        density_real=density.real.tolist(),
        density_imag=density.imag.tolist(),
        wall_s=time.perf_counter() - start,
        root_wall_s=root_wall,
        timing=dict(
            eigh_matrices=0,
            eigvalsh_matrices=0,
            primitive_charge_calls=charge_calls,
            primitive_points=total,
        ),
        primitive_matrix_size=2 if checker or problem.kind == "bdg" else 1,
        sampled_minimum_abs_eigenvalue=minimum_excitation,
        spectrum_file=None if spectrum_path is None else str(spectrum_path.resolve()),
        reference_qualification="requires independent finer-grid agreement; exact primitive reduction crosschecked against full supercell",
        density_coordinate_mapping="displacement = site(col)-site(row)+shape*R; phase exp(+i p displacement)",
    )


def folded_grid(supercell_shape, nk, shift=0.371):
    """Primitive tensor grid exactly equivalent to a shifted supercell grid."""
    gridshape = tuple(int(length) * int(nk) for length in supercell_shape)
    shifts = tuple(
        (float(shift) + int(nk) * (int(length) - 1) / 2) % 1
        for length in supercell_shape
    )
    return gridshape, shifts
