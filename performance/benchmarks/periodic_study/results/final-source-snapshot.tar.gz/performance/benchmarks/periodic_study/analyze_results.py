"""Assess benchmark accuracy and normalize costs by measured LAPACK baselines.

  python analyze_results.py --runs-dir runs --reference-summary references/reference-summary.json --lapack lapack.json --output-dir analysis

Overall study targets are max selected density-entry error <= eps and physical
filling error <= eps (particles/supercell). Solver root and charge integration
budgets are each eps/4. Both overall and stricter physical filling comparisons are
reported; they are not silently treated as the same contract.

References are requalified for EACH run's eps, even if the strictest requested
reference ladder failed. An inconclusive bound or unresolved reference is unknown,
not a measured accuracy failure. Only accuracy-qualified results enter rankings.
"""

from __future__ import annotations

import os
import argparse
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
import statistics

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[name] = "1"

# Set thread limits before importing numerical libraries and MeanFi.
import numpy as np  # noqa: E402
from models import build_problem  # noqa: E402
from reference import density_values  # noqa: E402
from run_references import charge_evaluator  # noqa: E402
from study_process import read_json, write_json  # noqa: E402


CSV_FIELDS = (
    "model",
    "kind",
    "ndim",
    "matrix_size",
    "temperature",
    "tolerance",
    "method",
    "configuration",
    "stage",
    "repeat",
    "run_status",
    "accuracy_status",
    "strict_filling_status",
    "reason",
    "wall_s",
    "density_error",
    "physical_charge_error",
    "physical_charge_error_bound",
    "reference_density_change",
    "reference_charge_change",
    "reference_qualified",
    "density_target",
    "physical_filling_target",
    "root_tolerance",
    "charge_tolerance",
    "solver_filling_residual",
    "density_grid_filling_residual",
    "reported_density_error",
    "reported_charge_error",
    "eigh_matrices",
    "eigvalsh_matrices",
    "total_diagonalizations",
    "eigh_s",
    "eigvalsh_s",
    "lapack_full_s_per_matrix",
    "lapack_values_s_per_matrix",
    "lapack_mixed_floor_s",
    "lapack_overhead_ratio",
    "lapack_full_equivalent_s",
    "full_equivalent_ratio",
    "measured_eigensolve_fraction",
    "non_eigensolve_s",
    "peak_rss_mib",
    "kernel_points",
    "charge_points",
    "density_points",
    "final_points",
    "refinements",
    "lapack_interpretation",
    "source_sha256",
    "file",
)
DEFAULT_SETTINGS = dict(
    initial_order=8,
    max_order=512,
    max_points=262144,
    batch_size=256,
    cache_mib=512,
    max_refinements=2000,
    derivative_scale=0.01,
    mu_guess=0.0,
    filling_target=None,
)
SETTING_LABELS = dict(
    initial_order="nk",
    max_order="max_n",
    max_points="max_points",
    batch_size="batch",
    cache_mib="cache_MiB",
    max_refinements="max_ref",
    derivative_scale="derivative_scale",
    mu_guess="mu_guess",
    filling_target="filling_target",
)


class ReferenceBundle:
    def __init__(self, entry):
        self.entry = entry
        self.previous, self.best = [
            read_json(path) for path in entry["reference_files"]
        ]
        if not self.previous or not self.best:
            raise ValueError("reference file missing")
        if (
            self.previous.get("status") != "success"
            or self.best.get("status") != "success"
        ):
            raise ValueError("reference calculation failed")
        self.density = density_values(self.best)
        self.density_change = float(
            np.max(abs(self.density - density_values(self.previous)))
        )
        self.q_previous = charge_evaluator(self.previous)
        self.q_best = charge_evaluator(self.best)
        self.charge_cache = {}

    def charge_at(self, mu):
        key = float(mu)
        if key not in self.charge_cache:
            self.charge_cache[key] = (self.q_previous(key), self.q_best(key))
        return self.charge_cache[key]

    def assess(self, record, tolerance, root_tolerance, filling_target=None):
        filling_target = tolerance if filling_target is None else filling_target
        result = dict(
            density_error=float(np.max(abs(density_values(record) - self.density))),
            reference_density_change=self.density_change,
            reference_files=self.entry["reference_files"],
            reference_mu=self.best["mu"],
            reference_qualified=False,
            accuracy_status="unknown",
            strict_filling_status="unknown",
        )
        previous_charge, best_charge = self.charge_at(record["mu"])
        target = record["problem"]["filling"]
        is_bound = False
        if previous_charge is not None and best_charge is not None:
            error = abs(best_charge - target)
            change = abs(best_charge - previous_charge)
            result.update(
                physical_charge_error=error,
                physical_charge_at_result_mu=best_charge,
                reference_charge_change=change,
                charge_check="exact independent reference-grid charge at candidate mu",
            )
        elif record["problem"]["kind"] == "bdg":
            is_bound = True
            constant = record["problem"]["physical_sites"] / (
                4 * record["problem"]["temperature"]
            )
            change = abs(
                self.best["filling"] - self.previous["filling"]
            ) + constant * abs(self.best["mu"] - self.previous["mu"])
            error = abs(self.best["filling"] - target) + constant * abs(
                record["mu"] - self.best["mu"]
            )
            result.update(
                physical_charge_error_bound=error,
                reference_charge_change=change,
                charge_check="global mu Lipschitz upper bound; not measured candidate charge",
            )
        else:
            result["reason"] = (
                "reference charge unavailable at candidate chemical potential"
            )
            return result
        reference_qualified = (
            self.density_change < tolerance / 10 and change < filling_target / 10
        )
        result["reference_qualified"] = reference_qualified
        rho = result["density_error"]
        rho_uncert = self.density_change
        if not reference_qualified:
            result["reason"] = "reference convergence unresolved for this tolerance"
            return result
        # Grid changes are empirical uncertainty indicators, not mathematical
        # bounds. Keeping a margin prevents borderline comparisons from being
        # reported as definite passes/failures under that empirical standard.
        if rho + rho_uncert <= tolerance and error + change <= filling_target:
            result.update(
                accuracy_status="pass",
                reason="passes declared density/filling targets with empirical reference margin",
            )
        elif rho - rho_uncert > tolerance or (
            not is_bound and error - change > filling_target
        ):
            result.update(
                accuracy_status="fail",
                reason="actual reference error exceeds overall target beyond reference variation",
            )
        else:
            result["reason"] = (
                "charge bound inconclusive"
                if is_bound and error + change > filling_target
                else "error is too close to target relative to reference variation"
            )
        if (
            rho + rho_uncert <= tolerance
            and error + change <= root_tolerance
            and change < root_tolerance / 10
        ):
            result["strict_filling_status"] = "pass"
        elif rho - rho_uncert > tolerance or (
            not is_bound and error - change > root_tolerance
        ):
            result["strict_filling_status"] = "fail"
        return result


def load_lapack(paths):
    baselines = {}
    for path in paths:
        data = json.loads(Path(path).read_text())
        if isinstance(data, dict):
            data = data.get("models", data.get("records", [data]))
        for record in data:
            if isinstance(record, dict) and record.get("model"):
                baselines[record["model"]] = record
    return baselines


def baseline_values(record):
    full = record.get("fastest_s")
    values = record.get("eigenvalues_only_s")
    if values is None and isinstance(record.get("eigenvalues_baseline"), dict):
        values = record["eigenvalues_baseline"].get("fastest_s")
    return full, values


def configuration_name(record, method):
    config = dict(record.get("config", {}))
    config.update(record.get("job", {}))
    changed = {
        key: config[key]
        for key, default in DEFAULT_SETTINGS.items()
        if key in config and config[key] != default
    }
    if changed.get("filling_target") == config.get("tolerance"):
        changed.pop("filling_target", None)
    label = method
    if changed:
        label += (
            " ("
            + ", ".join(
                f"{SETTING_LABELS[key]}={value}" for key, value in changed.items()
            )
            + ")"
        )
    return label, changed


def summarize_record(path, record, baseline, problem):
    config = record.get("config", {})
    job = record.get("job", {})
    method = job.get("method", config.get("method", record.get("variant", "unknown")))
    temperature = float(
        job.get("temperature", config.get("temperature", problem["temperature"]))
    )
    tolerance = float(
        job.get(
            "tolerance", config.get("tolerance", record.get("density_tolerance", 1e-5))
        )
    )
    filling_target = record.get(
        "physical_filling_target",
        job.get("filling_target", config.get("filling_target")),
    )
    filling_target = tolerance if filling_target is None else float(filling_target)
    root_tol = float(record.get("root_tolerance", filling_target / 4))
    charge_tol = float(record.get("charge_tolerance", filling_target / 4))
    configuration, settings = configuration_name(record, method)
    timing = record.get("timing", {})
    stats = record.get("statistics", {})
    errors = record.get("errors", {})
    n_full = timing.get("eigh_matrices")
    n_values = timing.get("eigvalsh_matrices", 0)
    if n_full is None and record.get("status") == "success" and method != "fermi":
        n_full = 0
    wall = record.get("wall_s")
    t_full = float(timing.get("eigh_s", 0))
    t_values = float(timing.get("eigvalsh_s", 0))
    full_baseline, value_baseline = baseline_values(baseline or {})
    denominator = None
    equivalent = None
    if n_full is not None and full_baseline is not None:
        equivalent = (n_full + n_values) * full_baseline
        if not n_values or value_baseline is not None:
            denominator = n_full * full_baseline + n_values * (value_baseline or 0)
    scalar = problem["matrix_size"] <= 2
    row = dict(
        model=problem["name"],
        kind=problem["kind"],
        ndim=problem["ndim"],
        matrix_size=problem["matrix_size"],
        temperature=temperature,
        tolerance=tolerance,
        method=method,
        configuration=configuration,
        settings=settings,
        stage=job.get("stage"),
        repeat=job.get("repeat"),
        run_status=record.get("status"),
        accuracy_status="unknown",
        strict_filling_status="unknown",
        wall_s=wall,
        density_target=tolerance,
        physical_filling_target=filling_target,
        root_tolerance=root_tol,
        charge_tolerance=charge_tol,
        solver_filling_residual=None
        if record.get("filling") is None
        else abs(record.get("root_filling", record["filling"]) - problem["filling"]),
        density_grid_filling_residual=None
        if record.get("filling") is None
        else abs(record["filling"] - problem["filling"]),
        reported_density_error=errors.get("density_matrix_integration"),
        reported_charge_error=errors.get("charge_integration"),
        eigh_matrices=n_full,
        eigvalsh_matrices=n_values,
        total_diagonalizations=None if n_full is None else n_full + n_values,
        eigh_s=t_full,
        eigvalsh_s=t_values,
        lapack_full_s_per_matrix=full_baseline,
        lapack_values_s_per_matrix=value_baseline,
        lapack_mixed_floor_s=denominator,
        lapack_overhead_ratio=None
        if not denominator or not wall
        else wall / denominator,
        lapack_full_equivalent_s=equivalent,
        full_equivalent_ratio=None if not equivalent or not wall else wall / equivalent,
        measured_eigensolve_fraction=None if not wall else (t_full + t_values) / wall,
        non_eigensolve_s=None if wall is None else max(0, wall - t_full - t_values),
        peak_rss_mib=record.get("monitored_peak_rss_mib", record.get("peak_rss_mib")),
        kernel_points=timing.get("kernel_points", stats.get("n_kernel_evals")),
        charge_points=timing.get("charge_points"),
        density_points=timing.get("density_points"),
        final_points=stats.get(
            "final_points",
            stats.get(
                "n_kpoints",
                stats.get("final_density_leaf_nodes", stats.get("n_cached_nodes")),
            ),
        ),
        refinements=stats.get("refinements", stats.get("subdivisions")),
        lapack_interpretation="scalar control: do not infer dense LAPACK efficiency"
        if scalar
        else "representative sampled LAPACK cost; not a rigorous lower bound or exact node replay",
        source_sha256=record.get("source_sha256"),
        file=str(Path(path).resolve()),
        timing=timing,
        statistics=stats,
        context_only=temperature == 0,
    )
    return row


def grouped_tables(rows):
    by_case = defaultdict(list)
    for row in rows:
        if row["temperature"] > 0:
            by_case[
                (
                    row["model"],
                    row["temperature"],
                    row["tolerance"],
                    row["physical_filling_target"],
                )
            ].append(row)
    groups = []
    for (model, temperature, tolerance, filling_target), members in sorted(
        by_case.items()
    ):
        by_configuration = defaultdict(list)
        for row in members:
            by_configuration[row["configuration"]].append(row)
        configurations = []
        for name, records in sorted(by_configuration.items()):
            passed = [row for row in records if row["accuracy_status"] == "pass"]
            strict = [row for row in records if row["strict_filling_status"] == "pass"]
            durations = [row["wall_s"] for row in passed if row["wall_s"] is not None]
            strict_durations = [
                row["wall_s"] for row in strict if row["wall_s"] is not None
            ]
            configurations.append(
                dict(
                    configuration=name,
                    method=records[0]["method"],
                    run_count=len(records),
                    accuracy_counts=dict(
                        Counter(r["accuracy_status"] for r in records)
                    ),
                    execution_counts=dict(Counter(r["run_status"] for r in records)),
                    qualified_run_count=len(passed),
                    strict_run_count=len(strict),
                    median_wall_s=statistics.median(durations) if durations else None,
                    minimum_wall_s=min(durations) if durations else None,
                    maximum_wall_s=max(durations) if durations else None,
                    strict_median_wall_s=statistics.median(strict_durations)
                    if strict_durations
                    else None,
                    all_runs_qualified=len(passed) == len(records),
                    files=[row["file"] for row in records],
                    source_hashes=sorted(
                        {r["source_sha256"] for r in records if r["source_sha256"]}
                    ),
                )
            )
        ranked = sorted(
            (c for c in configurations if c["median_wall_s"] is not None),
            key=lambda c: c["median_wall_s"],
        )
        strict_ranked = sorted(
            (c for c in configurations if c["strict_median_wall_s"] is not None),
            key=lambda c: c["strict_median_wall_s"],
        )
        winner = ranked[0] if ranked else None
        for rank, row in enumerate(ranked, 1):
            row["rank"] = rank
            row["time_relative_to_fastest"] = (
                row["median_wall_s"] / winner["median_wall_s"]
            )
        groups.append(
            dict(
                model=model,
                temperature=temperature,
                tolerance=tolerance,
                physical_filling_target=filling_target,
                winner=None if winner is None else winner["configuration"],
                winner_s=None if winner is None else winner["median_wall_s"],
                second_over_best=None
                if len(ranked) < 2
                else ranked[1]["median_wall_s"] / ranked[0]["median_wall_s"],
                strict_winner=None
                if not strict_ranked
                else strict_ranked[0]["configuration"],
                configurations=configurations,
                qualified_rankings=ranked,
                strict_rankings=strict_ranked,
            )
        )
    return groups


def _fmt(value, precision=3):
    return "—" if value is None else f"{value:.{precision}g}"


def write_markdown(path, rows, groups):
    counts = Counter(row["accuracy_status"] for row in rows)
    lines = [
        "Benchmark accuracy and timing tables",
        "",
        f"{len(rows)} runs: {counts.get('pass', 0)} qualified, {counts.get('fail', 0)} measured accuracy failures, {counts.get('unknown', 0)} unresolved or incomplete.",
        "",
        "Overall targets are max selected density-entry error ≤ ε and physical filling error ≤ ε per supercell. Root residual and charge-integration budgets are each ε/4; strict physical filling results are separate. Rankings include only empirically qualified runs. Reference changes are practical uncertainty indicators, not rigorous integration bounds.",
        "",
        "| Model | T | Density target | Filling target | Fastest qualified configuration | Seconds | Second / fastest | Strict filling winner |",
        "|---|---:|---:|---:|---|---:|---:|---|",
    ]
    for group in groups:
        lines.append(
            f"| {group['model']} | {_fmt(group['temperature'])} | {_fmt(group['tolerance'])} | {_fmt(group['physical_filling_target'])} | {group['winner'] or 'unresolved'} | {_fmt(group['winner_s'])} | {_fmt(group['second_over_best'])} | {group['strict_winner'] or 'unresolved'} |"
        )
    lines += [
        "",
        "All runs",
        "",
        "| Model | T | ε | Configuration | Execution / accuracy | Seconds | ρ error | Charge error | Diagonalizations | LAPACK ratio |",
        "|---|---:|---:|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        charge = row.get("physical_charge_error")
        charge_text = (
            _fmt(charge)
            if charge is not None
            else (
                "≤" + _fmt(row["physical_charge_error_bound"])
                if row.get("physical_charge_error_bound") is not None
                else "—"
            )
        )
        lines.append(
            f"| {row['model']} | {_fmt(row['temperature'])} | {_fmt(row['tolerance'])} | {row['configuration']} | {row['run_status']} / {row['accuracy_status']} | {_fmt(row['wall_s'])} | {_fmt(row.get('density_error'))} | {charge_text} | {_fmt(row['total_diagonalizations'], 6)} | {_fmt(row['lapack_overhead_ratio'])} |"
        )
    lines += [
        "",
        "LAPACK ratio = total runtime / (full-eigensystem count × fastest tested full LAPACK cost + eigenvalues-only count × fastest tested values-only LAPACK cost). Representative sampled baselines can vary with the actual nodes and μ values. Scalar controls are not evidence about dense-matrix implementation overhead.",
        "",
    ]
    Path(path).write_text("\n".join(lines))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs-dir", nargs="+", required=True)
    parser.add_argument("--reference-summary", required=True)
    parser.add_argument("--lapack", nargs="+", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    summary = json.loads(Path(args.reference_summary).read_text())
    entries = {
        (entry["model"], entry["temperature"]): entry for entry in summary["pairs"]
    }
    baselines = load_lapack(args.lapack)
    # Group by physical problem so at most one pair of spectra is resident.
    jobs = defaultdict(list)
    for folder in args.runs_dir:
        for path in sorted(Path(folder).glob("*.json")):
            record = read_json(path)
            if not record or "status" not in record or record.get("reference"):
                continue
            config = record.get("config", {})
            job = record.get("job", {})
            problem = record.get("problem", {})
            model = problem.get("name", job.get("model", config.get("model")))
            temperature = problem.get(
                "temperature", job.get("temperature", config.get("temperature"))
            )
            if model is None or temperature is None:
                continue
            jobs[(model, float(temperature))].append((path, record))
    rows = []
    for (model, temperature), records in sorted(jobs.items()):
        expected = build_problem(model, temperature).summary()
        entry = entries.get((model, temperature))
        bundle = None
        bundle_error = None
        if entry and len(entry.get("reference_files", [])) >= 2:
            try:
                bundle = ReferenceBundle(entry)
            except (ValueError, OSError, KeyError) as exc:
                bundle_error = str(exc)
        for path, record in records:
            problem = record.get("problem", expected)
            row = summarize_record(path, record, baselines.get(model), problem)
            if record.get("status") != "success":
                row["reason"] = "calculation did not complete successfully"
            elif temperature <= 0:
                row["reason"] = (
                    "T=0 context; finite-temperature references do not apply"
                )
            elif json.dumps(problem.get("metadata", {}), sort_keys=True) != json.dumps(
                expected["metadata"], sort_keys=True
            ):
                row["reason"] = (
                    "benchmark physical parameters differ from the current model"
                )
            elif bundle is None:
                row["reason"] = bundle_error or "no usable reference pair"
            elif json.dumps(
                bundle.best["problem"].get("metadata", {}), sort_keys=True
            ) != json.dumps(expected["metadata"], sort_keys=True):
                row["reason"] = (
                    "reference physical parameters differ from the current model"
                )
            else:
                row.update(
                    bundle.assess(
                        record,
                        row["tolerance"],
                        row["root_tolerance"],
                        row["physical_filling_target"],
                    )
                )
            rows.append(row)
        del bundle
    rows.sort(
        key=lambda row: (
            row["model"],
            row["temperature"],
            row["tolerance"],
            row["configuration"],
            str(row["repeat"]),
        )
    )
    groups = grouped_tables(rows)
    with (output / "comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    result = dict(
        schema_version=1,
        rows=rows,
        groups=groups,
        accuracy_counts=dict(Counter(r["accuracy_status"] for r in rows)),
        contract=dict(
            density="eps maximum selected complex entry",
            physical_filling="eps_q particles per supercell (defaults to eps)",
            solver_root="eps_q/4",
            solver_charge_integration="eps_q/4",
            strict_physical_filling="eps_q/4",
        ),
        reference_caveat="Empirically converged independent grids; uncertainty margins are not rigorous universal error bounds.",
        lapack_caveat="Representative sampled fastest tested LAPACK costs; not a universal performance lower bound.",
    )
    write_json(output / "comparison.json", result)
    write_json(output / "grouped-winners.json", dict(groups=groups))
    write_markdown(output / "tables.md", rows, groups)
    print(
        json.dumps(
            dict(
                runs=len(rows),
                accuracy_counts=result["accuracy_counts"],
                groups=len(groups),
                output=str(output.resolve()),
            )
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
