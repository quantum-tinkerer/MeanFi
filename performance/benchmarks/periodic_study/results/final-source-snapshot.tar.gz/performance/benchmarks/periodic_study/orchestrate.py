"""Run timed jobs strictly sequentially, preserving timeouts and memory limits."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time


def source_hash():
    digest = hashlib.sha256()
    for path in sorted(Path("meanfi").rglob("*.py")):
        digest.update(str(path).encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def run_job(job, folder, index, count):
    folder.mkdir(parents=True, exist_ok=True)
    name = f"{job['model']}--T{job['temperature']:g}--e{job['tolerance']:g}--{job['method']}"
    if (
        job.get("filling_target") is not None
        and job["filling_target"] != job["tolerance"]
    ):
        name += f"--q{job['filling_target']:g}"
    if job.get("repeat") is not None:
        name += f"--r{job['repeat']}"
    out = folder / (name + ".json")
    if out.exists():
        return
    log = out.with_suffix(".log")
    command = [
        sys.executable,
        str(Path(__file__).with_name("suite.py")),
        "run",
        "--model",
        job["model"],
        "--method",
        job["method"],
        "--temperature",
        str(job["temperature"]),
        "--tolerance",
        str(job["tolerance"]),
        "--output",
        str(out),
    ]
    for key in (
        "max_refinements",
        "max_order",
        "max_points",
        "batch_size",
        "cache_mib",
        "initial_order",
        "derivative_scale",
        "mu_guess",
        "filling_target",
    ):
        if key in job:
            command.extend(["--" + key.replace("_", "-"), str(job[key])])
    environment = os.environ.copy()
    environment.update(
        OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1"
    )

    def limits():
        ceiling = 8 * 1024**3
        resource.setrlimit(resource.RLIMIT_AS, (ceiling, ceiling))

    print(f"START {index}/{count} {name}", flush=True)
    start = time.monotonic()
    peak = 0
    status = None
    last_heartbeat = start
    digest = source_hash()
    with log.open("w") as stream:
        process = subprocess.Popen(
            command,
            stdout=stream,
            stderr=subprocess.STDOUT,
            env=environment,
            start_new_session=True,
            preexec_fn=limits,
        )
        while process.poll() is None:
            elapsed = time.monotonic() - start
            try:
                for line in (
                    Path(f"/proc/{process.pid}/status").read_text().splitlines()
                ):
                    if line.startswith("VmRSS:"):
                        peak = max(peak, int(line.split()[1]) * 1024)
            except FileNotFoundError:
                pass
            if elapsed > job.get("timeout_s", 120):
                status = "timeout"
            elif peak > 6 * 1024**3:
                status = "memory_limit"
            if status:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                break
            if time.monotonic() - last_heartbeat > 25:
                print(
                    f"RUNNING {name}: {elapsed:.0f}s, RSS {peak / 1024**2:.0f}MiB",
                    flush=True,
                )
                last_heartbeat = time.monotonic()
            time.sleep(0.1)
    elapsed = time.monotonic() - start
    if out.exists():
        result = json.loads(out.read_text())
    else:
        result = dict(
            status=status or "process_error",
            error=f"exit={process.returncode}",
            wall_s=elapsed,
            config=job,
        )
    if status:
        result["status"] = status
    result.update(
        job=job,
        process_wall_s=elapsed,
        monitored_peak_rss_mib=peak / 1024**2,
        source_sha256=digest,
        command=command,
    )
    out.write_text(json.dumps(result, indent=2) + "\n")
    timing = result.get("timing", {})
    print(
        f"DONE {name}: {result['status']}, {result.get('wall_s', elapsed):.4g}s, "
        f"eigh={timing.get('eigh_matrices', '?')}, eigvalsh={timing.get('eigvalsh_matrices', 0)}",
        flush=True,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--stages", nargs="*")
    args = parser.parse_args()
    data = json.loads(Path(args.manifest).read_text())
    jobs = data["jobs"] if isinstance(data, dict) else data
    if args.stages:
        jobs = [job for job in jobs if job.get("stage") in args.stages]
    for index, job in enumerate(jobs, 1):
        run_job(job, Path(args.output_dir), index, len(jobs))


if __name__ == "__main__":
    main()
