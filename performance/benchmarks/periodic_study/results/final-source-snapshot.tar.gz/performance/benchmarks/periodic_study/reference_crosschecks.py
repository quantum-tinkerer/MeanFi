"""Reproduce primitive/full-supercell reference equivalence checks.

Run only when the benchmark timing lane is idle, for example::

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \\
        .pixi/envs/mid/bin/python build/periodic-study/reference_crosschecks.py \\
        --output build/periodic-study/primitive-crosschecks.json

All five supported clean models are checked at two temperatures and two chemical
potentials away from particle-hole symmetry. Both representations integrate the
same folded grid, so differences measure implementation consistency rather than
quadrature convergence. No spectral cache files are written.
"""

# Set BLAS thread controls before importing numerical libraries.
# ruff: noqa: E402

from __future__ import annotations

import os

for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[variable] = "1"

import argparse
import json
from pathlib import Path
import time

import numpy as np
from threadpoolctl import threadpool_limits

from models import build_problem
from primitive_reference import SUPPORTED, folded_grid, primitive_reference
from reference import density_values, grid_reference


TEMPERATURES = (0.05, 0.01)
CHEMICAL_POTENTIALS = (-0.37, 0.19)
SUPER_CELL_NK = 3
SUPER_CELL_SHIFT = 0.371
DENSITY_ATOL = 2e-12
CHARGE_ATOL = 1e-10


def crosscheck(model, temperature, mu):
    """Compare explicit full covariance with the analytic primitive covariance."""
    problem = build_problem(model, temperature)
    shape = tuple(problem.metadata["shape"])
    primitive_shape, primitive_shift = folded_grid(
        shape, SUPER_CELL_NK, SUPER_CELL_SHIFT
    )
    start = time.perf_counter()
    full = grid_reference(
        problem,
        nk=SUPER_CELL_NK,
        shift=SUPER_CELL_SHIFT,
        batch_size=64,
        mu=mu,
    )
    reduced = primitive_reference(
        problem,
        nk=primitive_shape,
        shift=primitive_shift,
        batch_size=8192,
        mu=mu,
    )
    density_error = float(
        np.max(np.abs(density_values(full) - density_values(reduced)), initial=0.0)
    )
    charge_error = abs(float(full["filling"]) - float(reduced["filling"]))
    return {
        "model": model,
        "temperature": temperature,
        "mu": mu,
        "physical_sites": problem.physical_sites,
        "matrix_size": problem.matrix_size,
        "coordinate_count": problem.coordinates.value_count,
        "supercell_shape": list(shape),
        "supercell_nk": SUPER_CELL_NK,
        "supercell_shift": SUPER_CELL_SHIFT,
        "primitive_shape": list(primitive_shape),
        "primitive_shift": list(primitive_shift),
        "density_difference": density_error,
        "charge_difference": charge_error,
        "full_charge": float(full["filling"]),
        "primitive_charge": float(reduced["filling"]),
        "density_atol": DENSITY_ATOL,
        "charge_atol": CHARGE_ATOL,
        "passed": bool(density_error < DENSITY_ATOL and charge_error < CHARGE_ATOL),
        "wall_s": time.perf_counter() - start,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    results = []
    with threadpool_limits(limits=1):
        for model in SUPPORTED:
            for temperature in TEMPERATURES:
                for mu in CHEMICAL_POTENTIALS:
                    results.append(crosscheck(model, temperature, mu))
    output = {
        "status": "success" if all(row["passed"] for row in results) else "failed",
        "check_count": len(results),
        "threads": 1,
        "models": list(SUPPORTED),
        "temperatures": list(TEMPERATURES),
        "chemical_potentials": list(CHEMICAL_POTENTIALS),
        "maximum_density_difference": max(row["density_difference"] for row in results),
        "maximum_charge_difference": max(row["charge_difference"] for row in results),
        "interpretation": (
            "Equivalent folded-grid reference implementations agree; this does "
            "not qualify continuum quadrature convergence."
        ),
        "results": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({key: value for key, value in output.items() if key != "results"}))
    if output["status"] != "success":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
