# Reproducing the finite-temperature integration study

This folder contains benchmark code, model definitions, independent references, and analysis tools. The [final report](REPORT.md) and [compact recorded results](results/README.md) preserve the conclusions and measurements. Nothing in these scripts establishes that periodic quadrature is universally fastest; the study compares accuracy, work counts, runtime, and memory on explicit Hamiltonians.

Run commands from the MeanFi repository root, using its locked `mid` environment. The durable code is in `performance/benchmarks/periodic_study`; new generated data goes to `build/periodic-study`. The checked-in `results/` snapshot preserves this study's compact tables, plots, metadata and raw-record archives.

```sh
study_python=.pixi/envs/mid/bin/python
study_code=performance/benchmarks/periodic_study
study_data=build/periodic-study
```

Invoke these scripts by their file paths as shown below. They use sibling imports and are research scripts, not a supported `python -m` package API. `models.py` places the current checkout on the import path before importing MeanFi.

Run numerical jobs **sequentially**. Do not run tests, reference generation, another benchmark, or a second runner concurrently with a timing job. The scripts restrict OpenBLAS, OpenMP and MKL to one thread and apply `threadpool_limits(1)`. These are single-thread CPU measurements, not scaling studies.

## Physical problems and accuracy contract

`models.py` defines deterministic trial Hamiltonians. A timed calculation finds the chemical potential for fixed filling and integrates the selected real-space density entries needed by the model's SCF coordinates. Model construction, imports, references and a complete self-consistent SCF solve are outside the timing. All matrices use complex128 and the dense backend.

The main systems have 48 physical orbitals: disordered 1D/2D/3D supercells; an anisotropic quasi-1D metal; a clean square-lattice model near a van Hove energy; a checkerboard insulator; a p-wave chain; and nodal or chiral p-wave 2D BdG models. BdG matrices have size 96. Small one-band controls include a shifted low-density pocket and a `cos(16 k)` aliasing adversary. Temperatures are in hopping-energy units, `k_B T / t_x`, not kelvin.

The supplemental `wire48` model addresses a limitation of the long `chain48` supercell. Its 48 sites form an **open 6 × 8 transverse cross-section**, while the transport direction has a single-cell period. Onsite energies are independently sampled from `[-0.35, 0.35]`, transverse nearest-neighbor hoppings are `0.35` and `0.28`, and longitudinal site-dependent hoppings `t_i` lie in `[0.8, 1.2]`, using seed `9021048`. Thus `H(k) = H0 - 2 diag(t_i) cos(k)`: the transverse Hamiltonian and transport diagonal do not commute, giving a coupled multichannel model without artificial longitudinal band folding. Filling is `0.43 × 48`. It has no primitive-reference shortcut; references use the full 48 × 48 Hamiltonian.

`wire-manifest.json` supplies nine supplemental jobs at temperatures `0.2`, `0.05`, and `0.01`, comparing periodic, derivative-relaxed GK21, and bounded Gaussian integration at target `1e-5`. They use a 90-second timeout and allow up to 4096 global points per axis while retaining the ordinary per-grid point budget. Execute it with the same sequential orchestrator and qualify its references separately before including the results in comparisons.

For each requested target `eps`:

- Density target: maximum absolute error in a requested complex density entry ≤ `eps`.
- Overall physical filling target: absolute particle-count error per supercell ≤ `eps`.
- Solver root-residual budget: `eps/4`.
- Charge-integration budget: `eps/4`.

An optional `--filling-target eps_q` sets the physical filling error target independently of density `eps`. In that case charge integration and root residual each receive `eps_q/4`; lean methods also require the fresh density-grid filling to meet `eps_q`. Omitting the option preserves the original 133-job study exactly. `targets-manifest.json` contains six density-`1e-5` / filling-`1e-3` comparisons for square48 and cubic48. These runs have distinct `--q...` filenames and are grouped separately in analysis; the main equal-target plots exclude them.

The quarter budgets leave room inside the overall physical target. The analyzer additionally reports the stricter physical filling comparison against `eps/4`; this is distinct from checking the numerical root's own residual. All methods must compute the same selected entries. T=0 FermiSimplex runs are physical context, not same-temperature competitors.

## Method variants

`PeriodicQuadrature` is the production implementation. The remaining experimental comparators are confined to this benchmark folder.

| Name | Implementation or change |
|---|---|
| `periodic` | Production nested periodic grids, bounded cache/batches, and independent shifted-grid validation. |
| `periodic-unvalidated` | Same production method with shifted validation disabled, for diagnosing validation cost. |
| `periodic-eigenvalue-priority` | Same grid selection with a cache that prioritizes normal-state eigenvalues over vectors. |
| `periodic-anisotropic` | Experimental rectangular grids, directional coarse-grid indicators, independent shifted validation and directional alias probes. |
| `gm` | Bounded existing adaptive integration: GK21 in 1D, Genz–Malik in 2D/3D. |
| `gk21` | Tensor-product GK21 injected into the same stateful adaptive controller in 2D/3D. |
| `*-derivative` | Same charge and density budgets, but 100× looser integration accuracy for the derivative used by the root solver. The derivative's numerical value is restored before the Newton step. |
| `*-charge-only` | Remove the derivative criterion and use derivative-free root finding. The BdG implementation uses batched charge evaluation. |
| `*-fresh` | Start a fresh density integration mesh after finding μ. |
| `gm-lean`, `gk21-lean` | Compact charge spectra/coordinates, followed by a fresh joint density/charge mesh retaining only observable values; count all recomputation and consistency retries. |
| `gauss` | Increasing-order tensor Gauss–Legendre integration; all discarded, nonnested orders count as work. |
| `gauss-bounded` | Same Gaussian order sequence and stopping criteria, with a shared bounded cache across live orders. |
| `fermi` | AdaptiveSimplex/FermiSimplex at T=0 only. |

The original 133-job manifest uses derivative-relaxed GM/GK for normal-state baselines and charge-only GM/GK for BdG baselines. Original and derivative-based BdG paths remain explicit optimization controls. `suite.py manifest` reproduces the exact job order and metadata of that manifest when its timeout is 90 seconds.

All fixed-μ global rules use `gauss_bounded.fixed_mu_streamed`, which computes charge and selected density in one streamed eigensystem pass. It retains no full-grid vector cache. Clenshaw–Curtis `order` means intervals (`order + 1` nodes); periodic/Gaussian `order` means nodes per axis. Adaptive fixed-μ GM/GK integrates a joint charge/density observable and counts discarded adaptive parents.

## Main run, references, and analysis

Generate and execute the baseline matrix:

```sh
$study_python "$study_code/suite.py" manifest --timeout 90 --output "$study_data/manifest.json"
$study_python "$study_code/orchestrate.py" --manifest "$study_data/manifest.json" --output-dir "$study_data/runs"
```

`orchestrate.py` runs one child process at a time. It retains failed calculations, timeouts and memory-limit results, rather than treating their elapsed time as a successful method result. Existing output files are reused. Keep deliberately distinct configurations in separate files or use the manifest's repeat tags.

The complete recorded suite contains **244 jobs: 133 baseline jobs plus 111 supplemental jobs**. The source manifests are:

| Manifest | Jobs | Purpose |
|---|---:|---|
| `manifest.json` | 133 | Original methods, systems, temperatures, tolerances and controls. |
| `optimizations.json` | 27 | Directional grids, starting orders, cache policy and bounded Gaussian storage. |
| `lean-manifest.json` | 13 | Compact adaptive GM/GK storage and fresh joint density/charge checks. |
| `targets-manifest.json` | 6 | Independent density and physical filling targets. |
| `wire-manifest.json` | 9 | Coupled 48-orbital transport model at three temperatures. |
| `extended-manifest.json` | 3 | Longer cold nodal-BdG comparisons. |
| `repeat-manifest.json` | 38 | Two additional timings for each of 19 close, relatively short configurations. |
| `limits-control-manifest.json` | 7 | Larger point/order/refinement caps for cold scalar controls; ordinary time and memory caps remain. |
| `cold-adaptive-followup.json` | 2 | Cold nodal BdG derivative-relaxed GM/GK with the same 240-second limit as the extended global methods. |
| `wire-repeats.json` | 6 | Two additional warm-wire timings per method to check an unusually slow initial periodic diagonalization measurement. |

Eight bounded follow-up jobs were added after the original 236: two cold adaptive comparisons and six short wire repetitions. For the cold comparisons, the warm nodal BdG results showed that derivative-relaxed GK could outperform charge-only GK, so cold charge-only runs with a shorter time limit were insufficient to rank the best tested adaptive path.

Merge them in the recorded order and run all jobs sequentially. Existing baseline and supplemental result files are reused, so this also continues an interrupted study:

```sh
$study_python - "$study_code" "$study_data" <<'PYMERGE'
import json
from pathlib import Path
import sys

source, output = map(Path, sys.argv[1:])
names = [
    "manifest.json", "optimizations.json", "lean-manifest.json",
    "targets-manifest.json", "wire-manifest.json", "extended-manifest.json",
    "repeat-manifest.json", "limits-control-manifest.json",
    "cold-adaptive-followup.json", "wire-repeats.json",
]
parts = [json.loads((source / name).read_text()) for name in names]
jobs = [job for part in parts for job in part["jobs"]]
assert len(jobs) == 244
merged = dict(schema_version=1, manifests=names,
              contract=parts[0]["contract"], jobs=jobs)
output.mkdir(parents=True, exist_ok=True)
(output / "all-manifest.json").write_text(json.dumps(merged, indent=2) + "\n")
merged["jobs"] = jobs[len(parts[0]["jobs"]):]
assert len(merged["jobs"]) == 111
(output / "supplemental-manifest.json").write_text(json.dumps(merged, indent=2) + "\n")
PYMERGE
$study_python "$study_code/orchestrate.py" \
  --manifest "$study_data/all-manifest.json" --output-dir "$study_data/runs"
```

A repeat suffix that names a changed setting, such as `extended-points`, denotes a distinct configuration, not another statistical timing repetition. Actual timing repeats use the numeric suffixes `2` and `3`.

Measure full-eigensystem and eigenvalues-only LAPACK baselines after the main run:

```sh
$study_python "$study_code/lapack.py" \
  --models chain48 square48 vanhove48 anisotropic48 gapped48 cubic48 \
           bdg_chain48 bdg_nodal48 bdg_gapped48 wire48 chain1 square1 pocket1 alias1 \
  --count 64 --repeats 3 --output "$study_data/lapack.json"
```

Generate or reuse independent references:

```sh
$study_python "$study_code/run_references.py" \
  --manifest "$study_data/all-manifest.json" --runs-dir "$study_data/runs" \
  --references-dir "$study_data/references"
```

Reference generation is adaptive: it starts with suitable odd grids, tests density and charge changes, and proceeds to finer grids only when needed. It uses the strictest matching manifest tolerance divided by ten as a reference target. Charge agreement is tested at every currently available successful candidate μ, not only at the reference's own root. Run this command again after adding new configurations. `--models`, `--temperature`, `--timeout` and `--retry-failures` support targeted continuation. To tighten selected reference targets for convergence curves, add `--target-tolerance 1e-9` or another explicit target.

Two extra reference refinements were used in the recorded study. The cubic ladder normally ends at `nk=65`; add a full-supercell `nk=81` grid with the distinct shift `0.619` and a 300-second process limit, then rebuild its reference qualification. The cold nodal BdG reference was tightened to a requested target of `1e-10`, so its empirical reference-change threshold is `1e-11`:

```sh
$study_python - "$study_code" "$study_data" <<'PYREFERENCE'
from pathlib import Path
import sys

source, output = map(Path, sys.argv[1:])
sys.path.insert(0, str(source.resolve()))
from study_process import run_command

reference = output / "references/cubic48-T0.05-n81.json"
run_command(
    [sys.executable, str(source / "suite.py"), "reference",
     "--model", "cubic48", "--temperature", ".05", "--nk", "81",
     "--shift", ".619", "--output", str(reference)],
    reference, label="cubic48-finer-independent-reference", timeout_s=300,
    metadata={"reference_job": {"model": "cubic48", "temperature": .05,
                                 "nk": 81, "shift": .619}},
)
PYREFERENCE
$study_python "$study_code/run_references.py" \
  --manifest "$study_data/all-manifest.json" --runs-dir "$study_data/runs" \
  --references-dir "$study_data/references" --models cubic48
$study_python "$study_code/run_references.py" \
  --manifest "$study_data/all-manifest.json" --runs-dir "$study_data/runs" \
  --references-dir "$study_data/references" --models bdg_nodal48 \
  --temperature .01 --target-tolerance 1e-10
```

Normal disordered references independently assemble Fourier Hamiltonians, diagonalize them, form full covariance matrices, and then extract selected entries. They never call the production quadrature or its selected-eigenvector contraction. Vectors are streamed; normal eigenvalues are persisted so charge at another μ is cheap to verify.

Clean supercells also have independent exact primitive-cell reductions in `primitive_reference.py`. The 48/96 matrices are still used by every timed method; only reference generation uses the scalar or 2×2 physical representation. The Fourier displacement for a selected supercell entry is

```text
site(column) - site(row) + supercell_shape * R
```

and the inverse Fourier phase is `exp(+i p · displacement)`. The primitive reduction can be crosschecked against full-supercell calculations on exactly equivalent folded grids for all five supported clean models with `reference_crosschecks.py --output build/periodic-study/primitive-crosschecks.json`. This standalone validation is numerical work and must run outside the timing lane. The primitive-grid spectra permit inexpensive charge checks at arbitrary candidate μ, including BdG.

Two-grid agreement is an empirical convergence indicator, not a rigorous guarantee against every unresolved Fourier component. Aliasing controls, non-dyadic independent grids, and shifted validation address different failure modes; none justifies universal claims from one passing grid comparison. A sampled minimum gap is also not proof of a gap between sample points.

Assess all runs and generate tables:

```sh
$study_python "$study_code/analyze_results.py" \
  --runs-dir "$study_data/runs" \
  --reference-summary "$study_data/references/reference-summary.json" \
  --lapack "$study_data/lapack.json" --output-dir "$study_data/analysis"
```

Multiple run directories and LAPACK files may be passed. The analyzer emits `comparison.csv`, `comparison.json`, `grouped-winners.json`, and `tables.md`. It requalifies a reference pair separately for each run's tolerance: failure to resolve a `1e-7` target need not invalidate a `1e-3` result. Borderline error comparisons, missing references, and insufficient transfer bounds are labeled unknown. Only qualified calculations enter runtime rankings. Groups include both overall-target and strict-filling winners.

## Fixed-μ convergence curves

```sh
$study_python "$study_code/run_convergence.py" \
  --reference-summary "$study_data/references/reference-summary.json" \
  --output-dir "$study_data/convergence"
```

The default cases are square48 at T=0.2/0.05/0.01, anisotropic48 at 0.05, cubic48 at 0.05, nodal BdG at 0.01, gapped BdG at 0.05, the pocket control at 0.002, and the coupled 48-orbital wire at 0.05. Global orders are 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32, 40, 48 and 64, extending to 96/128 for cold 2D cases and capped at 32 in 3D. The coupled wire also uses orders 96, 128, 192, 256, 384 and 512. Only the cold pocket control (`pocket1`, T=0.002) additionally uses 192, 256, 384, 512, 768 and 1024, because its original 128-node maximum stopped before the resolved analytic regime. Adaptive tolerances range from `1e-2` to `1e-7`.

After the automatic study driver finishes, refine the cold pocket reference and rerun that case at its updated reference μ. This targeted postpass is required before interpreting the pocket convergence fits; existing files tagged with the previous μ remain available:

```sh
$study_python "$study_code/run_references.py" \
  --manifest "$study_data/all-manifest.json" --runs-dir "$study_data/runs" \
  --references-dir "$study_data/references" --models pocket1 \
  --temperature .002 --target-tolerance 1e-10
$study_python "$study_code/run_convergence.py" \
  --reference-summary "$study_data/references/reference-summary.json" \
  --output-dir "$study_data/convergence" --models pocket1 --temperature .002
$study_python "$study_code/plot_results.py" \
  --analysis "$study_data/analysis/comparison.json" \
  --convergence "$study_data/convergence/convergence-summary.json" \
  --output-dir "$study_data/figures"
```

Each curve uses the finest reference's μ, so the stored fine reference density is evaluated at exactly the comparison μ. The coarse reference's root difference is accounted for conservatively using the density Lipschitz transfer bound `abs(delta_mu)/(4 T)`. Charge is reevaluated directly from reference spectra at the common μ. An available reference pair can still support the high-error part of a curve even if it did not satisfy the tightest requested reference target; points near its uncertainty floor are excluded from fits.

The convergence runner uses 45-second and 6-GiB limits per job, retains timeouts, resumes files, and supports `--summarize-only`. Filter with `--models`, `--temperature` and `--families`. Global orders above a timed-out or memory-limited order are skipped. Adaptive failures remain individual observations.

Fits compare

```text
log(error) = constant - a * N_eigh**(1/d)    exponential in effective resolution
log(error) = constant - p * log(N_eigh)     algebraic in total eigensolve work
```

separately for physical charge error and maximum density-entry error. Fits require at least five distinct work counts above `max(10 × reference uncertainty, 1e-13)` spanning two error decades. Repeated adaptive tolerances selecting the same mesh count as one point. The script expands a tail fit backward when necessary and retains nonmonotonic error behavior. These finite-range fits do not prove an asymptotic rate or establish mathematical superiority; insufficient evidence is reported explicitly.

Export compact convergence data after the final reference refinement:

```sh
$study_python "$study_code/summarize_convergence.py" \
  --convergence "$study_data/convergence/convergence-summary.json" \
  --output-dir "$study_data/analysis"
```

This writes `convergence-fits.csv`, `convergence-samples.csv`, and `fixed-mu-observed-work.csv`. The last file reports the smallest **observed** work count meeting both physical targets with a reference-variation margin. Global-rule entries use prescribed resolutions and omit finding μ, discovering the order, and shifted validation. They are not demonstrated end-to-end speedups or proven minimum sample counts.

## Timing and memory interpretation

`timing.eigh_matrices` counts every full eigenvector solve. `timing.eigvalsh_matrices` counts eigenvalues-only solves. Discarded adaptive parents, validation grids, cache-eviction recomputation, previous Gaussian orders, and repeated BdG `(k, μ)` solves all count. Unique spatial k points alone are an invalid BdG denominator because changing μ generally changes its eigenvectors.

The primary efficiency ratio is

```text
wall time / (N_full × fastest tested full LAPACK time
             + N_values × fastest tested eigenvalues-only LAPACK time)
```

LAPACK input construction and copies are outside that denominator; total integration timing includes Hamiltonian assembly, occupations, density contractions, quadrature bookkeeping, root finding and cache management. A second full-solve-equivalent denominator is reported for comparison, but it must not replace the mixed denominator when charge uses cheaper eigenvalues-only solves.

Best-family figures consider every qualified tested configuration, including periodic starting-grid and cache settings, and label the selected method and settings. The unvalidated periodic ablation is excluded and anisotropic periodic refinement is a separate family. Configurations with repeated measurements use their median; connecting lines require the same configuration at both endpoints. Some starting-grid optimizations have only one measurement and run in less than 0.1 seconds, so their timing rankings remain sensitive to startup variability even when their reduced eigensolve counts are exact.

Baselines use representative matrix samples and repeated standard LAPACK drivers in the installed environment. They are not mathematical lower bounds or exact replay of every adaptive matrix. A ratio slightly below one can reflect sampling/timing differences. Tiny one-band controls test quadrature and aliasing, not dense LAPACK efficiency. Inclusive stage times can overlap eigensolver time and must not be added as if they were disjoint.

Peak RSS is recorded per subprocess, with an independent monitor in the runners. A cache byte limit excludes Python bookkeeping and temporary arrays; it is not a total-process memory limit. Solver/grid memory caps and external process limits are retained in output configuration metadata.

## File map

- `suite.py`: one calculation, reference, fixed-μ sample, manifest, or assessment.
- `models.py`: deterministic models and coordinate contracts.
- `variants.py`: adaptive GM/GK controls and original global-order comparator.
- `gauss_bounded.py`, `anisotropic.py`, `adaptive_lean.py`, `periodic_eigenvalue_priority.py`: isolated optimization experiments.
- `reference.py`, `primitive_reference.py`: independent references and physical error checks.
- `run_references.py`, `run_convergence.py`, `study_process.py`: resumable sequential jobs and convergence fits.
- `lapack.py`: measured full/values-only driver baselines.
- `analyze_results.py`: qualification, normalization, grouped tables and machine-readable results.

Generate raw JSON, logs, profiler files and spectrum NPZ files in `build/periodic-study`. The curated `results/` artifact preserves compact final evidence without the large spectrum arrays. Retain the manifest, source hashes, lockfile revision and hardware/environment details alongside any reported timing study.
