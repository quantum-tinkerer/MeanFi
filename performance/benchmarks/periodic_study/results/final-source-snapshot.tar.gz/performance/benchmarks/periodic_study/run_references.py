"""Qualify or extend independent reference grids for every finite-T manifest pair.

Run only after timed benchmark jobs finish. Reference generation and assessment
are intentionally sequential, resumable, and separate from measured method costs.

  python run_references.py --manifest manifest.json --runs-dir runs --references-dir references

A reference is empirically qualified only when two independent odd shifted grids
agree below the strictest matching target/10 in root-solved density and charge at
ALL successful benchmark chemical potentials currently available. Grid agreement
is an error indicator, not a universal proof against unresolved aliasing.
"""

from __future__ import annotations

import os
import argparse
import json
from pathlib import Path
import sys

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[name] = "1"

# Set thread limits before importing numerical libraries and MeanFi.
import numpy as np  # noqa: E402
from scipy.special import expit  # noqa: E402
from models import build_problem  # noqa: E402
from primitive_reference import SUPPORTED  # noqa: E402
from reference import density_values  # noqa: E402
from study_process import read_json, write_json, run_command  # noqa: E402


def matching(record, model, temperature):
    problem = record.get("problem", {})
    return problem.get("name") == model and problem.get("temperature") == temperature


def charge_evaluator(reference):
    """Load reference spectra once for all candidate mu checks."""
    path = reference.get("spectrum_file")
    if not path or not Path(path).exists():
        return (
            lambda mu: float(reference["filling"])
            if abs(mu - reference["mu"]) < 1e-13
            else None
        )
    data = np.load(path)
    temperature = reference["problem"]["temperature"]
    if reference.get("reference_backend") == "primitive":
        from primitive_reference import _charge_from_arrays

        energy = np.asarray(data["energy"])
        pair = np.asarray(data["pair_abs2"])
        problem = reference["problem"]
        return lambda mu: _charge_from_arrays(
            energy,
            pair,
            mu,
            temperature,
            problem["kind"],
            problem["physical_sites"],
            float(problem["metadata"].get("staggered", 0.0)),
        )
    values = np.asarray(data["eigenvalues"])
    return lambda mu: float(np.mean(np.sum(expit((mu - values) / temperature), axis=1)))


def qualify_pair(previous, best, candidate_mus, threshold):
    difference = float(np.max(abs(density_values(best) - density_values(previous))))
    all_mus = sorted(
        set([float(best["mu"]), float(previous["mu"]), *map(float, candidate_mus)])
    )
    q_previous, q_best = charge_evaluator(previous), charge_evaluator(best)
    charge_differences = []
    for mu in all_mus:
        a, b = q_previous(mu), q_best(mu)
        if a is None or b is None:
            return dict(
                qualified=False,
                density_change=difference,
                charge_change=None,
                reason="reference charge unavailable at candidate chemical potentials",
            )
        charge_differences.append(abs(a - b))
    maximum = max(charge_differences, default=0.0)
    qualified = difference < threshold and maximum < threshold
    return dict(
        qualified=qualified,
        density_change=difference,
        charge_change=maximum,
        candidate_mu_count=len(all_mus),
        candidate_mus=all_mus,
        reason="empirically converged independent references"
        if qualified
        else "reference grid differences exceed threshold",
    )


def reference_catalog(folder, problem):
    records = []
    expected = json.dumps(problem.summary()["metadata"], sort_keys=True)
    for path in sorted(Path(folder).glob("*.json")):
        record = read_json(path)
        if (
            not record
            or record.get("status") != "success"
            or not record.get("reference")
            or not record.get("root_solved")
        ):
            continue
        if not matching(record, problem.name, problem.temperature):
            continue
        # Prevent silent reuse after a benchmark's physical parameters change.
        if (
            json.dumps(record["problem"].get("metadata", {}), sort_keys=True)
            != expected
        ):
            continue
        if record.get("spectrum_file") and not Path(record["spectrum_file"]).exists():
            continue
        records.append((path, record))
    return records


def best_existing_pair(catalog, mus, threshold):
    candidates = []
    for backend in ("direct", "primitive"):
        group = [
            (p, r)
            for p, r in catalog
            if r.get("reference_backend", "direct") == backend
        ]
        group.sort(key=lambda item: item[1]["n_points"])
        # Two shifts on the same grid count only if node geometry differs; our
        # ladder uses different odd grid sizes and requires different counts.
        unique = []
        for item in group:
            if not unique or unique[-1][1]["n_points"] != item[1]["n_points"]:
                unique.append(item)
            elif item[0].stat().st_mtime > unique[-1][0].stat().st_mtime:
                unique[-1] = item
        if len(unique) < 2:
            continue
        previous, best = unique[-2:]
        check = qualify_pair(previous[1], best[1], mus, threshold)
        check.update(
            reference_files=[str(previous[0].resolve()), str(best[0].resolve())],
            reference_backend=backend,
            best_reference=str(best[0].resolve()),
            best_n_points=best[1]["n_points"],
        )
        candidates.append(check)
    qualified = [c for c in candidates if c["qualified"]]
    if qualified:
        return min(qualified, key=lambda c: c["best_n_points"])
    if candidates:
        return min(
            candidates,
            key=lambda c: max(c["density_change"], c["charge_change"] or float("inf")),
        )
    return dict(qualified=False, reason="fewer than two usable reference grids")


def reference_ladder(problem):
    if problem.name in SUPPORTED:
        return (
            [1025, 2049, 4097, 8193]
            if problem.ndim == 1
            else [257, 513, 1025, 2049, 4097]
        ), True
    if problem.physical_sites == 1:
        return (
            [513, 1025, 2049, 4097, 8193, 16385, 32769, 65537]
            if problem.ndim == 1
            else [257, 513, 1025, 2049, 4097]
        ), False
    if problem.ndim == 1:
        return [129, 257, 513, 1025, 2049, 4097], False
    if problem.ndim == 2:
        return [65, 129, 257, 513], False
    return [17, 33, 65], False


def merge_entries(existing, updates):
    combined = {(e["model"], e["temperature"]): e for e in existing}
    combined.update({(e["model"], e["temperature"]): e for e in updates})
    return list(combined.values())


def manifest_pairs(manifest):
    data = json.loads(Path(manifest).read_text())
    jobs = data["jobs"] if isinstance(data, dict) else data
    pairs = {}
    for job in jobs:
        if float(job["temperature"]) <= 0:
            continue
        key = (job["model"], float(job["temperature"]))
        pairs[key] = min(pairs.get(key, float("inf")), float(job["tolerance"]))
    return pairs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--runs-dir", required=True)
    parser.add_argument("--references-dir", required=True)
    parser.add_argument("--summary")
    parser.add_argument("--models", nargs="*")
    parser.add_argument("--temperature", type=float)
    parser.add_argument("--timeout", type=float, default=180)
    parser.add_argument(
        "--target-tolerance",
        type=float,
        help="Optionally tighten all reference targets, e.g. 1e-9 for convergence curves",
    )
    parser.add_argument("--retry-failures", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    folder = Path(args.references_dir)
    folder.mkdir(parents=True, exist_ok=True)
    summary_path = (
        Path(args.summary)
        if args.summary
        else folder
        / ("reference-plan.json" if args.dry_run else "reference-summary.json")
    )
    existing_entries = (read_json(summary_path) or {}).get("pairs", [])
    pairs = manifest_pairs(args.manifest)
    runs = [
        record
        for path in Path(args.runs_dir).glob("*.json")
        if (record := read_json(path))
        and record.get("status") == "success"
        and "mu" in record
    ]
    entries = []
    for (model, temperature), tolerance in pairs.items():
        if args.models and model not in args.models:
            continue
        if args.temperature is not None and temperature != args.temperature:
            continue
        problem = build_problem(model, temperature)
        if args.target_tolerance is not None:
            tolerance = min(tolerance, args.target_tolerance)
        threshold = tolerance / 10
        metadata = json.dumps(problem.summary()["metadata"], sort_keys=True)
        mus = [
            r["mu"]
            for r in runs
            if matching(r, model, temperature)
            and json.dumps(r["problem"].get("metadata", {}), sort_keys=True) == metadata
        ]
        ladder, primitive = reference_ladder(problem)
        attempts = []
        catalog = reference_catalog(folder, problem)
        check = best_existing_pair(catalog, mus, threshold)
        if args.dry_run:
            entries.append(
                dict(
                    model=model,
                    temperature=temperature,
                    tolerance=tolerance,
                    threshold=threshold,
                    existing=check,
                    ladder=ladder,
                    primitive=primitive,
                )
            )
            continue
        for nk in ladder:
            if check["qualified"]:
                break
            backend = "primitive" if primitive else "direct"
            if any(
                r.get("reference_backend", "direct") == backend
                and r["nk"] == [nk] * problem.ndim
                for _, r in catalog
            ):
                continue
            name = f"{model}-T{temperature:g}-{'primitive-' if primitive else ''}n{nk}"
            output = folder / (name + ".json")
            command = [
                sys.executable,
                str(Path(__file__).with_name("suite.py")),
                "reference",
                "--model",
                model,
                "--temperature",
                str(temperature),
                "--nk",
                str(nk),
                "--shift",
                ".371",
                "--output",
                str(output),
            ]
            if primitive:
                command.append("--primitive")
            result = run_command(
                command,
                output,
                label=name,
                timeout_s=args.timeout,
                retry_failures=args.retry_failures,
                metadata=dict(
                    reference_job=dict(
                        model=model, temperature=temperature, nk=nk, primitive=primitive
                    )
                ),
            )
            attempts.append(dict(file=str(output.resolve()), status=result["status"]))
            if result["status"] != "success":
                check["reason"] = f"reference {result['status']} at nk={nk}"
                break
            catalog = reference_catalog(folder, problem)
            check = best_existing_pair(catalog, mus, threshold)
        if not check["qualified"] and not attempts:
            check.setdefault("reason", "reference ladder exhausted")
        entry = dict(
            model=model,
            temperature=temperature,
            target_tolerance=tolerance,
            reference_threshold=threshold,
            successful_candidate_count=len(mus),
            attempts=attempts,
            **check,
        )
        if not entry["qualified"] and "exceed" in entry.get("reason", ""):
            entry["reason"] = "maximum reference grid reached; " + entry["reason"]
        entries.append(entry)
        write_json(
            summary_path,
            dict(
                schema_version=1,
                manifest=str(Path(args.manifest).resolve()),
                runs_dir=str(Path(args.runs_dir).resolve()),
                pairs=merge_entries(existing_entries, entries),
                caveat="Empirical grid convergence; not a rigorous bound against all unresolved Fourier aliasing.",
            ),
        )
        print(
            json.dumps(
                dict(
                    event="reference-qualified"
                    if entry["qualified"]
                    else "reference-unresolved",
                    **entry,
                )
            ),
            flush=True,
        )
    write_json(
        summary_path,
        dict(
            schema_version=1,
            manifest=str(Path(args.manifest).resolve()),
            runs_dir=str(Path(args.runs_dir).resolve()),
            pairs=merge_entries(existing_entries, entries),
            dry_run=args.dry_run,
            caveat="Empirical grid convergence; not a rigorous bound against all unresolved Fourier aliasing.",
        ),
    )


if __name__ == "__main__":
    main()
