"""Fixed-mu actual-error curves and descriptive convergence fits.

Run AFTER timed jobs and reference qualification, never concurrently with them.
Each global rule is independently evaluated at one order, so its eigencount is
n**d (CC uses n+1 nodes per axis). Adaptive GM/GK counts include discarded parents.
All curves use the same reference chemical potential and selected observables.

  python run_convergence.py --reference-summary references/reference-summary.json --output-dir convergence

Fits use x=N_eigh**(1/d) for exponential-in-resolution decay and log(N_eigh) for
algebraic-in-work decay. They are descriptive finite-range fits, not proofs of an
asymptotic convergence class. At least five distinct non-floor points spanning two
error decades are required; otherwise the script reports insufficient evidence.
"""

from __future__ import annotations

import os
import argparse
import hashlib
import json
from pathlib import Path
import sys

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[name] = "1"

# Set thread limits before importing numerical libraries and MeanFi.
import numpy as np  # noqa: E402
from reference import density_values  # noqa: E402
from run_references import charge_evaluator, merge_entries  # noqa: E402
from study_process import read_json, write_json, run_command  # noqa: E402

DEFAULT_CASES = (
    ("square48", 0.2),
    ("square48", 0.05),
    ("square48", 0.01),
    ("anisotropic48", 0.05),
    ("cubic48", 0.05),
    ("bdg_nodal48", 0.01),
    ("bdg_gapped48", 0.05),
    ("pocket1", 0.002),
    ("wire48", 0.05),
)
GLOBAL_FAMILIES = ("periodic", "gauss", "clenshaw-curtis")
ADAPTIVE_FAMILIES = ("gm", "gk21")


def reference_context(entry):
    if len(entry.get("reference_files", [])) < 2:
        raise ValueError("two independent reference files are required")
    files = entry["reference_files"]
    previous, best = [read_json(path) for path in files]
    if previous is None or best is None:
        raise ValueError("reference JSON missing")
    if previous.get("status") != "success" or best.get("status") != "success":
        raise ValueError("reference calculation failed")
    mu = float(best["mu"])
    temperature = best["problem"]["temperature"]
    density_change = float(np.max(abs(density_values(best) - density_values(previous))))
    # The coarse covariance is stored at its own root. This bound transfers it
    # to the common comparison mu before treating the difference as a reference
    # error indicator. It does not certify the underlying grid convergence.
    density_mu_transfer = abs(best["mu"] - previous["mu"]) / (4 * temperature)
    charge_prev = charge_evaluator(previous)(mu)
    charge_best = charge_evaluator(best)(mu)
    if charge_prev is None or charge_best is None:
        raise ValueError("reference charge unavailable at the common mu")
    charge_change = abs(charge_best - charge_prev)
    return dict(
        mu=mu,
        problem=best["problem"],
        reference_files=files,
        reference_qualified_to_target=bool(entry.get("qualified")),
        reference_requested_threshold=entry.get("reference_threshold"),
        density=density_values(best),
        filling=charge_best,
        reference_density_change=density_change,
        reference_density_mu_transfer_bound=density_mu_transfer,
        reference_density_uncertainty=density_change + density_mu_transfer,
        reference_charge_uncertainty=charge_change,
        reference_status="independent empirical grid convergence with conservative mu transfer",
    )


def actual_errors(record, context):
    if record.get("status") != "success":
        return dict(usable=False, reason=record.get("status", "failed"))
    delta_mu = abs(float(record["mu"]) - context["mu"])
    if delta_mu > 1e-13:
        return dict(
            usable=False, reason="cached run uses a different chemical potential"
        )
    rho_error = float(np.max(abs(density_values(record) - context["density"])))
    charge_error = abs(float(record["filling"]) - context["filling"])
    count = int(record.get("timing", {}).get("eigh_matrices", 0))
    if count <= 0:
        return dict(usable=False, reason="true eigensolve count unavailable")
    return dict(
        usable=True,
        density_error=rho_error,
        charge_error=charge_error,
        n_eigh=count,
        effective_resolution=count ** (1 / context["problem"]["ndim"]),
        density_fit_floor=max(1e-13, 10 * context["reference_density_uncertainty"]),
        charge_fit_floor=max(1e-13, 10 * context["reference_charge_uncertainty"]),
    )


def _linear_fit(x, y):
    coefficient = np.polyfit(x, y, 1)
    prediction = np.polyval(coefficient, x)
    residual = y - prediction
    sum_square = float(np.sum(residual**2))
    total = float(np.sum((y - y.mean()) ** 2))
    return dict(
        slope=float(coefficient[0]),
        intercept=float(coefficient[1]),
        log_error_rmse=float(np.sqrt(np.mean(residual**2))),
        r_squared=1 - sum_square / total if total > 0 else None,
    )


def fit_curve(rows, metric, ndim):
    by_count = {}
    for row in rows:
        check = row.get("actual_errors", {})
        if not check.get("usable"):
            continue
        error = check[metric + "_error"]
        floor = check[metric + "_fit_floor"]
        count = check["n_eigh"]
        if not np.isfinite(error) or error <= floor:
            continue
        # Same adaptive mesh may satisfy several requested tolerances. It is one
        # convergence point, not independent evidence repeated several times.
        if count not in by_count or error > by_count[count]:
            by_count[count] = error
    points = sorted(by_count.items())
    if len(points) < 5:
        return dict(
            status="insufficient_data",
            usable_points=len(points),
            reason="need at least five distinct counts above the reference/roundoff floor",
        )
    # Report a tail fit as well as all eligible points. Prefer the last five, but
    # expand backward if those span fewer than two error decades.
    tail = points[-5:]
    while (
        len(tail) < len(points)
        and max(e for _, e in tail) / min(e for _, e in tail) < 100
    ):
        tail = points[-(len(tail) + 1) :]
    span = max(e for _, e in tail) / min(e for _, e in tail)
    if span < 100:
        return dict(
            status="insufficient_dynamic_range",
            usable_points=len(points),
            error_decades=float(np.log10(span)),
            reason="non-floor data span fewer than two error decades",
        )
    counts = np.array([n for n, _ in tail], float)
    errors = np.array([e for _, e in tail])
    exponential = _linear_fit(counts ** (1 / ndim), np.log(errors))
    algebraic = _linear_fit(np.log(counts), np.log(errors))
    exponential["decay_rate_per_effective_axis_point"] = -exponential["slope"]
    algebraic["work_power"] = -algebraic["slope"]
    return dict(
        status="descriptive_fit",
        usable_points=len(points),
        fitted_points=len(tail),
        n_eigh=[int(n) for n in counts],
        errors=errors.tolist(),
        error_decades=float(np.log10(span)),
        exponential_in_resolution=exponential,
        algebraic_in_work=algebraic,
        interpretation="Finite-range empirical fit; does not establish an asymptotic rate or mathematical dominance.",
    )


def orders_for(context, max_order=None):
    dim = context["problem"]["ndim"]
    temperature = context["problem"]["temperature"]
    orders = [2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64]
    if dim == 3:
        orders = [n for n in orders if n <= 32]
    elif dim == 2 and temperature <= 0.01:
        orders.extend([96, 128])
    if context["problem"]["name"] == "wire48":
        orders.extend([96, 128, 192, 256, 384, 512])
    if context["problem"]["name"] == "pocket1" and temperature == 0.002:
        orders.extend([192, 256, 384, 512, 768, 1024])
    if max_order is not None:
        orders = [n for n in orders if n <= max_order]
    return orders


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-summary", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--models", nargs="*")
    parser.add_argument("--temperature", type=float)
    parser.add_argument(
        "--families", nargs="*", default=[*GLOBAL_FAMILIES, *ADAPTIVE_FAMILIES]
    )
    parser.add_argument("--timeout", type=float, default=45)
    parser.add_argument("--max-order", type=int)
    parser.add_argument("--max-refinements", type=int, default=2000)
    parser.add_argument(
        "--tolerances",
        nargs="*",
        type=float,
        default=[1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7],
    )
    parser.add_argument("--retry-failures", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--summarize-only", action="store_true")
    args = parser.parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    raw_dir = output_dir / "runs"
    raw_dir.mkdir(parents=True, exist_ok=True)
    summary_path = output_dir / (
        "convergence-plan.json" if args.dry_run else "convergence-summary.json"
    )
    existing_entries = (read_json(summary_path) or {}).get("cases", [])
    references = json.loads(Path(args.reference_summary).read_text())
    reference_map = {
        (entry["model"], entry["temperature"]): entry for entry in references["pairs"]
    }
    summary = []
    for model, temperature in DEFAULT_CASES:
        if args.models and model not in args.models:
            continue
        if args.temperature is not None and temperature != args.temperature:
            continue
        entry = reference_map.get((model, temperature))
        if entry is None:
            summary.append(
                dict(model=model, temperature=temperature, status="missing_reference")
            )
            continue
        try:
            context = reference_context(entry)
        except (ValueError, KeyError, OSError) as exc:
            summary.append(
                dict(
                    model=model,
                    temperature=temperature,
                    status="unresolved_reference",
                    reason=str(exc),
                )
            )
            continue
        mu_tag = hashlib.sha256(float(context["mu"]).hex().encode()).hexdigest()[:10]
        case = dict(
            model=model,
            temperature=temperature,
            status="ready",
            reference={
                key: value
                for key, value in context.items()
                if key not in ("density", "problem")
            },
            ndim=context["problem"]["ndim"],
            curves={},
        )
        for family in args.families:
            if family not in (*GLOBAL_FAMILIES, *ADAPTIVE_FAMILIES):
                raise ValueError(f"unknown family {family}")
            orders = (
                orders_for(context, args.max_order)
                if family in GLOBAL_FAMILIES
                else args.tolerances
            )
            rows = []
            for parameter in orders:
                setting = (
                    ("n" + str(parameter))
                    if family in GLOBAL_FAMILIES
                    else ("e" + f"{parameter:g}")
                )
                name = f"{model}--T{temperature:g}--{family}--{setting}--mu{mu_tag}"
                output = raw_dir / (name + ".json")
                command = [
                    sys.executable,
                    str(Path(__file__).with_name("suite.py")),
                    "fixed",
                    "--model",
                    model,
                    "--temperature",
                    str(temperature),
                    "--method",
                    family,
                    "--mu",
                    repr(context["mu"]),
                    "--output",
                    str(output),
                    "--max-refinements",
                    str(args.max_refinements),
                ]
                if family in GLOBAL_FAMILIES:
                    command += ["--order", str(parameter), "--shift", "0"]
                else:
                    command += ["--tolerance", str(parameter)]
                job = dict(
                    model=model,
                    temperature=temperature,
                    method=family,
                    parameter=parameter,
                    mu=context["mu"],
                    reference_files=context["reference_files"],
                )
                if args.dry_run:
                    rows.append(dict(job=job, command=command))
                    continue
                if args.summarize_only:
                    record = read_json(output)
                    if record is None:
                        continue
                else:
                    record = run_command(
                        command,
                        output,
                        label=name,
                        timeout_s=args.timeout,
                        retry_failures=args.retry_failures,
                        metadata=dict(convergence_job=job),
                    )
                check = actual_errors(record, context)
                record["actual_errors"] = check
                write_json(output, record)
                rows.append(
                    dict(
                        parameter=parameter,
                        status=record["status"],
                        file=str(output.resolve()),
                        wall_s=record.get("wall_s"),
                        actual_errors=check,
                        peak_rss_mib=record.get("monitored_peak_rss_mib"),
                    )
                )
                # Continue after an adaptive timeout: tighter tolerances can fail
                # differently, but avoid repeating a known over-budget global
                # order with an even larger dense allocation.
                if family in GLOBAL_FAMILIES and record["status"] in (
                    "timeout",
                    "memory_limit",
                ):
                    break
            case["curves"][family] = dict(
                points=rows,
                density_fit=fit_curve(rows, "density", case["ndim"])
                if not args.dry_run
                else None,
                charge_fit=fit_curve(rows, "charge", case["ndim"])
                if not args.dry_run
                else None,
            )
            print(
                json.dumps(
                    dict(
                        event="convergence-family-done",
                        model=model,
                        temperature=temperature,
                        family=family,
                        points=len(rows),
                    )
                ),
                flush=True,
            )
        summary.append(case)
        write_json(
            summary_path,
            dict(
                schema_version=1,
                cases=merge_entries(existing_entries, summary),
                dry_run=args.dry_run,
                fit_caveat="Finite-range fits are descriptive; no universal superiority or asymptotic proof.",
            ),
        )
    write_json(
        summary_path,
        dict(
            schema_version=1,
            cases=merge_entries(existing_entries, summary),
            dry_run=args.dry_run,
            fit_caveat="Finite-range fits are descriptive; no universal superiority or asymptotic proof.",
        ),
    )


if __name__ == "__main__":
    main()
