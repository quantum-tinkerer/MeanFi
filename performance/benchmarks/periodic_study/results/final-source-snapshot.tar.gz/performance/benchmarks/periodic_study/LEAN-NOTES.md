# Lean adaptive comparator semantics

`adaptive_lean.py` provides `gm-lean` and `gk21-lean`. The installed stateful
subdivision controller and GM/GK rules are unchanged. Only spectral storage and
the charge/density execution pipeline differ.

Normal charge quadrature diagonalizes each new adaptive point with `eigvalsh`,
caches eigenvalues only and retains the charge mesh across chemical potentials.
It uses the same experimental 100-times-relaxed derivative budget as the
`*-derivative` comparisons; the actual derivative passed to Newton is unscaled.

BdG charge quadrature caches node coordinates, rather than the raw full matrix.
Each required `(k, mu)` evaluation assembles and diagonalizes a bounded batch,
contracts the electron charge and discards eigenvectors. The controller still
retains the current-mu leaf integral estimates, so refinements do not recompute
unchanged leaves during one integration call. Brent root finding avoids Loewner
derivative construction and derivative-error refinement. A changed mu necessarily
requires new BdG eigensolves. Matrix reconstruction at repeated mu is included.

Both methods construct a fresh density mesh after finding mu. Charge and selected
densities share each density-phase eigensolve; the payload cache stores these
integrand values, not eigensystems. Thus the method abandons charge-to-density
vector reuse to make memory scale with the actual selected output size.

For the 48-site, 144-coordinate normal square model, theoretical raw charge
payload storage drops from `(48+48**2)*16 = 37,632` to `48*8 = 384` bytes per
node: a factor 98. The fresh density payload has `(144+1)*16 = 2,320` bytes per
node, about 16 times less than the original spectral payload. These are raw
payload comparisons, not claims about measured process peak memory. Leaf metadata,
integral/error estimates, evaluator output and temporary arrays also consume RAM.
Requesting every density matrix entry reduces the density-phase memory benefit.

The root uses residual tolerance `eps/4` and charge quadrature tolerance `eps/4`.
The independent density mesh must also satisfy the total physical filling target
`eps`. If its charge is inconsistent, the method retries the root and density
calculation with four-times-tighter charge/root tolerances, at most twice.
`root_filling` records the charge mesh's accepted result; `filling` records the
fresh density mesh's independent charge. These estimates need not agree exactly.
Every attempted charge and density pass is included in time/eigensolve counters.

The density mesh's charge is still a quadrature estimate. This consistency check
cannot guarantee actual charge accuracy or resolve every aliasing failure; every
successful timing row needs independent physical charge and density validation.

The new method changes several implementation choices together, so its runtime
should be described as a lean adaptive implementation, not as a pure quadrature
rule comparison. Fixed-mu shared-integrand curves continue to isolate sampling
behavior from root and storage policy.
