"""Experimental anisotropic periodic quadrature, independent of production code.

One rectangular grid supplies an embedded half-grid in every direction. Refine
only the direction with the largest normalized charge/density discrepancy.
Before accepting, check an independently shifted grid. A shift guard that detects
an alias missed by all directional indicators triggers one-axis shift probes to
choose where to refine. These are empirical indicators, not rigorous bounds.

All point and root work, including unsuccessful shifts, is timed and counted.
The eigenpair cache is byte bounded; temporary dense arrays are batch bounded.
Normal spectra survive changes of mu; BdG spectra do not. Matrix functions are
exact dense diagonalization only. The API consumes models.BenchmarkProblem.
"""

from __future__ import annotations

import math
import time

import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits

import meanfi
from meanfi.density.filling import mu_bracket, solve_mu
from meanfi.density.kpoint.matrix_functions.direct import (
    selected_density_values_from_eigensystem,
)


def _max_abs(array):
    return float(np.max(np.abs(array), initial=0.0))


class _Evaluator:
    def __init__(
        self,
        problem,
        *,
        batch_size,
        max_cache_bytes,
        max_nk,
        max_points,
        max_diagonalizations,
    ):
        self.problem = problem
        self.bdg = problem.kind == "bdg"
        self.hk = meanfi.tb_to_kfunc(problem.full_h)
        self.ndim, self.size = problem.ndim, problem.matrix_size
        self.batch_size, self.max_cache_bytes = batch_size, max_cache_bytes
        self.max_nk, self.max_points = max_nk, max_points
        self.max_diagonalizations = max_diagonalizations
        self.keys = np.asarray(problem.coordinates.keys)
        self.q = problem.q_diag
        self.cache = {}
        self.cache_mu = None
        self.cache_bytes = 0
        self.seen = set()
        self.stats = dict(
            eigh_matrices=0,
            eigvalsh_matrices=0,
            eigh_s=0.0,
            eigvalsh_s=0.0,
            matrix_s=0.0,
            charge_s=0.0,
            density_s=0.0,
            root_evaluations=0,
            charge_points=0,
            density_points=0,
            validation_points=0,
            directional_probe_points=0,
            grid_evaluations=0,
            max_cache_bytes_used=0,
            levels=[],
        )

    def _set_mu(self, mu):
        if self.bdg and mu != self.cache_mu:
            self.cache.clear()
            self.cache_bytes = 0
            self.cache_mu = mu

    def grid_batches(self, shape, shift=None):
        count = int(np.prod(shape))
        if count > self.max_points:
            raise ValueError(f"Grid {shape} exceeds max_points={self.max_points}")
        shape_array = np.asarray(shape, dtype=np.int64)
        for start in range(0, count, self.batch_size):
            flat = np.arange(start, min(start + self.batch_size, count))
            indices = np.stack(np.unravel_index(flat, shape), axis=1)
            points = (
                2 * np.pi * (indices + (0.0 if shift is None else shift)) / shape_array
                - np.pi
            )
            if shift is None:
                # Orders divide max_nk; integer coordinates name common nested
                # points exactly, without floating-point rounding decisions.
                names = indices * (self.max_nk // shape_array)
                names = [tuple(map(int, row)) for row in names]
                self.seen.update(names)
            else:
                names = None  # Independent checks are never retained in cache.
            yield names, points, indices

    def _cache_spectrum(self, key, values, vectors):
        entry = self.cache.get(key)
        if entry is None:
            if self.cache_bytes + values.nbytes > self.max_cache_bytes:
                return
            entry = [values.copy(), None]
            self.cache[key] = entry
            self.cache_bytes += values.nbytes
        if vectors is not None and entry[1] is None:
            if self.cache_bytes + vectors.nbytes <= self.max_cache_bytes:
                entry[1] = vectors.copy()
                self.cache_bytes += vectors.nbytes
        self.stats["max_cache_bytes_used"] = max(
            self.cache_bytes, self.stats["max_cache_bytes_used"]
        )

    def spectrum(self, names, points, mu, *, vectors):
        self._set_mu(mu)
        entries = (
            [None] * len(points)
            if names is None
            else [self.cache.get(key) for key in names]
        )
        missing = [
            i
            for i, entry in enumerate(entries)
            if entry is None or (vectors and entry[1] is None)
        ]
        values = np.empty((len(points), self.size))
        vv = np.empty((len(points), self.size, self.size), complex) if vectors else None
        for i, entry in enumerate(entries):
            if entry is not None:
                values[i] = entry[0]
                if vectors and entry[1] is not None:
                    vv[i] = entry[1]
        if not missing:
            return values, vv
        used = self.stats["eigh_matrices"] + self.stats["eigvalsh_matrices"]
        if (
            self.max_diagonalizations is not None
            and used + len(missing) > self.max_diagonalizations
        ):
            raise ValueError(
                f"Exceeded max_diagonalizations={self.max_diagonalizations}"
            )
        t = time.perf_counter()
        matrix = self.hk(points[missing])
        if self.bdg:
            ii = np.arange(self.size)
            matrix[:, ii, ii] -= mu * self.q
        self.stats["matrix_s"] += time.perf_counter() - t
        retain_vectors = (
            names is not None
            and self.cache_bytes + len(missing) * (self.size * 8 + self.size**2 * 16)
            <= self.max_cache_bytes
        )
        t = time.perf_counter()
        if vectors or retain_vectors:
            new_values, new_vectors = np.linalg.eigh(matrix)
            self.stats["eigh_s"] += time.perf_counter() - t
            self.stats["eigh_matrices"] += len(missing)
        else:
            new_values, new_vectors = np.linalg.eigvalsh(matrix), None
            self.stats["eigvalsh_s"] += time.perf_counter() - t
            self.stats["eigvalsh_matrices"] += len(missing)
        for j, i in enumerate(missing):
            values[i] = new_values[j]
            if vectors:
                vv[i] = new_vectors[j]
            if names is not None:
                self._cache_spectrum(
                    names[i],
                    new_values[j],
                    None if new_vectors is None else new_vectors[j],
                )
        return values, vv

    def evaluate(
        self, shape, mu, *, density=False, directional=False, shift=None, purpose="root"
    ):
        """Full grid and optional per-axis even-index subgrids at the same mu."""
        self.stats["grid_evaluations"] += 1
        if purpose == "root":
            self.stats["root_evaluations"] += 1
        count = int(np.prod(shape))
        if purpose == "validation":
            self.stats["validation_points"] += count
        elif purpose == "directional_probe":
            self.stats["directional_probe_points"] += count
        width = 2 + (self.problem.coordinates.value_count if density else 0)
        total = np.zeros(width, complex)
        coarse = np.zeros((self.ndim, width), complex) if directional else None
        coarse_count = np.zeros(self.ndim, dtype=int)
        for names, points, indices in self.grid_batches(shape, shift):
            ee, vv = self.spectrum(names, points, mu, vectors=density or self.bdg)
            t = time.perf_counter()
            occupation = (
                expit(-ee / self.problem.temperature)
                if self.bdg
                else expit((mu - ee) / self.problem.temperature)
            )
            if self.bdg:
                band_weight = np.sum(
                    np.abs(vv[:, : self.problem.physical_sites, :]) ** 2, axis=1
                )
                charge = np.sum(band_weight * occupation, axis=1)
                derivative = np.zeros_like(charge)
            else:
                charge = occupation.sum(axis=1)
                derivative = (occupation * (1 - occupation)).sum(
                    axis=1
                ) / self.problem.temperature
            value = np.empty((len(points), width), complex)
            value[:, 0], value[:, 1] = charge, derivative
            self.stats["charge_s"] += time.perf_counter() - t
            self.stats["charge_points"] += len(points)
            if density:
                t = time.perf_counter()
                phase = np.exp(1j * points @ self.keys.T)
                value[:, 2:] = selected_density_values_from_eigensystem(
                    vv, occupation, self.problem.coordinates, phases=phase
                )
                self.stats["density_s"] += time.perf_counter() - t
                self.stats["density_points"] += len(points)
            total += np.sum(value, axis=0)
            if directional:
                for axis in range(self.ndim):
                    selected = indices[:, axis] % 2 == 0
                    coarse[axis] += np.sum(value[selected], axis=0)
                    coarse_count[axis] += np.count_nonzero(selected)
        return total / count, None if coarse is None else coarse / coarse_count[:, None]


def run_anisotropic(
    problem,
    tolerance,
    charge_tolerance,
    *,
    nk=8,
    max_nk=512,
    max_points=262144,
    batch_size=256,
    max_cache_bytes=512 * 1024**2,
    max_refinements=30,
    max_charge_evaluations=100,
    max_diagonalizations=2000000,
    root_tolerance=None,
    mu_guess=0.0,
    validate_shift=True,
    **kwargs,
):
    """Experimental dense normal/BdG anisotropic periodic fixed-filling solve.

    ``nk`` can be scalar or an order per axis. Orders and ``max_nk`` must be powers
    of two; start with at least two nodes per axis. ``max_points`` caps every
    rectangular or validation grid, while ``max_diagonalizations`` optionally
    caps actual total work. ``max_cache_bytes`` excludes temporary arrays and
    Python dictionary overhead. All counters include failed refinements/probes.
    """
    start = time.perf_counter()
    root_tolerance = tolerance / 4 if root_tolerance is None else root_tolerance
    evaluator = None
    try:
        if problem.ndim < 1:
            raise ValueError(
                "Anisotropic experiment requires at least one periodic direction"
            )
        if problem.kind not in ("normal", "bdg") or problem.temperature <= 0:
            raise ValueError(
                "Anisotropic experiment requires normal/BdG at positive temperature"
            )
        if min(tolerance, charge_tolerance, root_tolerance) <= 0:
            raise ValueError("All tolerances must be positive")
        shape = (
            tuple([int(nk)] * problem.ndim) if np.ndim(nk) == 0 else tuple(map(int, nk))
        )
        if len(shape) != problem.ndim:
            raise ValueError("nk must contain one order per periodic direction")
        if any(n < 2 or n & (n - 1) for n in shape + (max_nk,)) or max(shape) > max_nk:
            raise ValueError(
                "nk and max_nk must be powers of two, with 2 <= nk <= max_nk"
            )
        if batch_size < 1 or max_cache_bytes < 0:
            raise ValueError("Invalid batch or cache budget")
        evaluator = _Evaluator(
            problem,
            batch_size=batch_size,
            max_cache_bytes=max_cache_bytes,
            max_nk=max_nk,
            max_points=max_points,
            max_diagonalizations=max_diagonalizations,
        )
        scales = np.r_[
            charge_tolerance,
            np.inf,
            np.full(problem.coordinates.value_count, tolerance),
        ]
        shift = np.mod(np.sqrt(np.arange(2, 2 + problem.ndim)), 1.0)
        # Avoid integer sqrt offsets in ndim >= 3.
        primes, candidate = [], 2
        while len(primes) < problem.ndim:
            if all(candidate % p for p in primes if p * p <= candidate):
                primes.append(candidate)
            candidate += 1
        shift = np.mod(np.sqrt(primes), 1.0)
        candidate_mu = float(mu_guess)
        with threadpool_limits(limits=1):
            for refinement in range(max_refinements + 1):
                remaining = (
                    None
                    if max_charge_evaluations is None
                    else max_charge_evaluations - evaluator.stats["root_evaluations"]
                )
                if remaining is not None and remaining <= 0:
                    raise ValueError("Exceeded total max_charge_evaluations")

                def charge(mu):
                    result, _ = evaluator.evaluate(shape, mu)
                    return (
                        float(result[0].real),
                        0.0,
                        None if evaluator.bdg else float(result[1].real),
                    )

                root = solve_mu(
                    evaluate_charge=charge,
                    initial_bracket=lambda: mu_bracket(
                        problem.full_h, problem.temperature
                    ),
                    filling=problem.filling,
                    mu_guess=candidate_mu,
                    filling_tol=root_tolerance,
                    mu_tol=1e-12,
                    max_charge_evaluations=remaining,
                    use_derivative=not evaluator.bdg,
                )
                candidate_mu = root.mu
                estimate, coarse = evaluator.evaluate(
                    shape,
                    candidate_mu,
                    density=True,
                    directional=True,
                    purpose="density",
                )
                directional_errors = np.abs(coarse - estimate)
                scores = np.max(directional_errors / scales, axis=1)
                error = np.sum(directional_errors, axis=0)
                converged = bool(np.all(error / scales <= 1))
                validation_error = None
                shift_scores = None
                if converged and validate_shift:
                    checked, _ = evaluator.evaluate(
                        shape,
                        candidate_mu,
                        density=True,
                        shift=shift,
                        purpose="validation",
                    )
                    validation_error = np.abs(estimate - checked)
                    error = np.maximum(error, validation_error)
                    converged = bool(np.all(error / scales <= 1))
                    if not converged:
                        # Coarse indicators missed something. Resolve the alias
                        # direction instead of blindly refining every axis.
                        if problem.ndim == 1:
                            scores[0] = np.max(validation_error / scales)
                        else:
                            shift_scores = np.empty(problem.ndim)
                            for axis in range(problem.ndim):
                                directional_shift = np.zeros(problem.ndim)
                                directional_shift[axis] = shift[axis]
                                checked_axis, _ = evaluator.evaluate(
                                    shape,
                                    candidate_mu,
                                    density=True,
                                    shift=directional_shift,
                                    purpose="directional_probe",
                                )
                                shift_scores[axis] = np.max(
                                    np.abs(estimate - checked_axis) / scales
                                )
                            scores = np.maximum(scores, shift_scores)
                level = dict(
                    shape=list(shape),
                    mu=candidate_mu,
                    filling=float(estimate[0].real),
                    charge_error=float(error[0]),
                    density_error=_max_abs(error[2:]),
                    directional_scores=scores.tolist(),
                    shift_scores=None
                    if shift_scores is None
                    else shift_scores.tolist(),
                    validation_charge_error=None
                    if validation_error is None
                    else float(validation_error[0]),
                    validation_density_error=None
                    if validation_error is None
                    else _max_abs(validation_error[2:]),
                    elapsed_s=time.perf_counter() - start,
                    cumulative_eigh=evaluator.stats["eigh_matrices"],
                    cumulative_eigvalsh=evaluator.stats["eigvalsh_matrices"],
                )
                evaluator.stats["levels"].append(level)
                if converged:
                    record = dict(
                        status="success",
                        variant="periodic-anisotropic",
                        mu=candidate_mu,
                        filling=float(estimate[0].real),
                        density_real=estimate[2:].real.tolist(),
                        density_imag=estimate[2:].imag.tolist(),
                        errors=dict(
                            density_matrix_integration=_max_abs(error[2:]),
                            charge_integration=float(error[0]),
                            filling_residual=abs(estimate[0].real - problem.filling),
                        ),
                        statistics=dict(
                            shape=list(shape),
                            final_points=int(np.prod(shape)),
                            refinements=refinement,
                            cache_bytes=evaluator.cache_bytes,
                            unique_unshifted_points=len(evaluator.seen),
                            n_diagonalizations=evaluator.stats["eigh_matrices"]
                            + evaluator.stats["eigvalsh_matrices"],
                            validation_points=evaluator.stats["validation_points"],
                            directional_probe_points=evaluator.stats[
                                "directional_probe_points"
                            ],
                        ),
                    )
                    break
                axis = int(np.argmax(scores))
                level["refined_axis"] = axis
                next_shape = list(shape)
                next_shape[axis] *= 2
                if next_shape[axis] > max_nk:
                    raise ValueError(
                        f"Required axis {axis} refinement exceeds max_nk={max_nk}"
                    )
                if math.prod(next_shape) > max_points:
                    raise ValueError(
                        f"Required grid {next_shape} exceeds max_points={max_points}"
                    )
                shape = tuple(next_shape)
            else:
                raise ValueError(f"Exceeded max_refinements={max_refinements}")
    except Exception as exc:
        record = dict(status="error", variant="periodic-anisotropic", error=repr(exc))
    record.update(
        wall_s=time.perf_counter() - start,
        timing={} if evaluator is None else evaluator.stats,
        density_tolerance=tolerance,
        charge_tolerance=charge_tolerance,
        root_tolerance=root_tolerance,
        error_estimate="sum of directional half-grid differences plus independent shift difference",
        validate_shift=validate_shift,
    )
    return record
