---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
    format_version: 0.13
    jupytext_version: 1.14.4
kernelspec:
  display_name: Python 3 (ipykernel)
  language: python
  name: python3
---
# Defaults and capabilities

This page summarizes how `MeanFi` chooses defaults today and which method combinations are supported.

## Default integration selection

When `integration=None`, the code currently chooses:

| Condition | Default |
| --- | --- |
| `kT = 0`, normal | `AdaptiveSimplex()` |
| `kT > 0`, dense, normal | `AdaptiveQuadrature(matrix_function=DirectDiagonalization())` |
| `kT > 0`, sparse, normal | `AdaptiveQuadrature(matrix_function=RationalFOE(rational_scheme="aaa"))` |
| `kT > 0`, dense, superconducting | `AdaptiveQuadrature(matrix_function=DirectDiagonalization())` |
| `kT > 0`, sparse, superconducting | `AdaptiveQuadrature(matrix_function=RationalFOE(rational_scheme="aaa"))` |
| `kT = 0`, superconducting | no default; explicit `UniformGrid(...)` required |

## Capability table

The main supported combinations are:

| Family | `kT = 0` normal | `kT = 0` BdG | `kT > 0` normal | `kT > 0` BdG |
| --- | --- | --- | --- | --- |
| `AdaptiveSimplex` | Yes | No | No | No |
| `UniformGrid` | Yes | Yes | Yes | Yes |
| `AdaptiveQuadrature` | No | No | Yes | Yes |
| `PeriodicQuadrature` | No | No | Yes | Yes |

`PeriodicQuadrature` is an explicit finite-temperature option with direct diagonalization. Its initial implementation does not support rational FOE.

`AdaptiveSimplex` uses the `FermiSimplex` backend for normal-state zero-temperature problems. MeanFi reuses the charge-refined spectral mesh, requests only the density components needed by the SCF parametrization, and evaluates them with `preview_depth=1`.

## Matrix-function defaults

At finite temperature:

- dense problems default to `DirectDiagonalization()`,
- sparse problems default to `RationalFOE(rational_scheme="aaa")`.

For `UniformGrid`, the same dense/sparse distinction is still relevant when the matrix-function backend is omitted. Explicit `PeriodicQuadrature` always selects direct diagonalization when its matrix-function backend is omitted, and densifies sparse input.

## Other current defaults

Some other public defaults that affect algorithm behavior are:

- `Model(..., kT=0.0)`
- `solver(..., scf=AndersonMixing(), scf_tol=None)`, where omitted
  `scf_tol` resolves to `1e-3`
- public density and SCF functions default to `tol=1e-3`
- the default tolerance policy maps `tol` to density and charge integration
  tolerances `tol / 5` and filling residual tolerance `tol / 10`
- integration methods initially leave `density_matrix_tol` and `charge_tol`
  unset; public calls resolve them through the tolerance policy, preserving any
  explicitly supplied integration tolerance
- public `filling_tol` overrides the filling tolerance from the policy; direct
  internal integration calls without a resolved filling tolerance use the
  density tolerance divided by the internal estimator factor `5.4`

These defaults live in the runtime code, so this page should be updated whenever those policies change.
