---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
    format_version: 0.13
    jupytext_version: 1.14.4
kernelspec:
  display_name: Python 3 (ipykernel)
  language: python
  name: python3
---
# Integration families

The Brillouin-zone integral and the single-$k$ density evaluation are two different choices in `MeanFi`.
This page focuses only on the **k-space integration family**.

```{toctree}
:hidden:
:maxdepth: 1

method_notes/adaptive_quadrature.md
method_notes/periodic_quadrature.md
method_notes/uniform_grid.md
method_notes/adaptive_simplex.md
```

## Integration choices

### `AdaptiveQuadrature`

This is the finite-temperature adaptive cubature path.
It chooses evaluation nodes in the Brillouin zone adaptively and is the default family for `kT > 0`.
For implementation details, see the
[stateful_quadrature package](https://github.com/Kostusas/stateful_quadrature).

### `UniformGrid`

This evaluates the problem on a fixed `nk` grid in each momentum direction.
It is simple, predictable, and useful for explicit coarse-grid workflows and for the zero-temperature BdG path.

### `PeriodicQuadrature`

This refines periodic grids at finite temperature, checks charge and density convergence, and validates tentative convergence on a shifted grid. It supports normal and superconducting systems with direct diagonalization. It is selected explicitly; `AdaptiveQuadrature` remains the default.

### `AdaptiveSimplex`

This is the dedicated zero-temperature adaptive simplicial backend.
It refines a simplicial partition of the Brillouin zone and is the default normal-state family for `kT = 0`.
The physics integration backend is
[FermiSimplex](https://gitlab.kwant-project.org/qt/lineartetrahedron),
which uses the generic mesh engine from
[adaptivesimplex](https://gitlab.kwant-project.org/qt/adaptivesimplex).

## What the family controls

The integration family determines:

- where in k-space the Hamiltonian is sampled,
- how errors are estimated, if at all,
- how work is reused as the fixed-filling solver tries new values of $\mu$.

It does **not** by itself determine how the density matrix is computed at one sampled $k$ point.
That is the job of the matrix-function backend.

## Main tradeoffs

| Family | Strength | Limitation |
| --- | --- | --- |
| `AdaptiveQuadrature` | Efficient finite-temperature adaptivity | Requires `kT > 0` |
| `UniformGrid` | Simple and explicit | No adaptive error control |
| `PeriodicQuadrature` | Rapid convergence for analytic periodic integrands | Global grid growth; empirical estimates; direct diagonalization only |
| `AdaptiveSimplex` | Native zero-temperature adaptive path | Normal-state only by default |

## Cost versus error scaling

The generic pattern is

:::{math}
\text{cost} \sim N_k \times C_k,
:::

where $N_k$ is the number of sampled momentum points or effective adaptive cells, and $C_k$ is the cost of one single-$k$ matrix-function evaluation.
The family-specific pages below make that more explicit as cost-versus-error relations of the form

:::{math}
\text{cost} \sim \varepsilon^{-\gamma} C_k
:::

when an algebraic convergence law is available.

- [Adaptive quadrature](./method_notes/adaptive_quadrature.md): adaptive cubature, typically with algebraic work-vs-tolerance scaling for smooth finite-temperature integrands
- [Periodic quadrature](./method_notes/periodic_quadrature.md): refined periodic grids with convergence checks and normal-state spectral reuse
- [Uniform grid](./method_notes/uniform_grid.md): fixed-grid sampling with work determined directly by the chosen grid size
- [Adaptive simplex](./method_notes/adaptive_simplex.md): adaptive simplicial refinement with problem-dependent algebraic work-vs-error behavior
