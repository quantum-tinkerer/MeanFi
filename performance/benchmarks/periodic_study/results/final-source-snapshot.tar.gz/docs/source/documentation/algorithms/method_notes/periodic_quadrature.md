# `PeriodicQuadrature`

`PeriodicQuadrature` integrates finite-temperature normal and superconducting density matrices on successively refined periodic grids. It is an explicit alternative to the current `AdaptiveQuadrature` default.

```python
import meanfi

integration = meanfi.PeriodicQuadrature(
    density_matrix_tol=1e-5,
    charge_tol=1e-6,
    batch_size=256,
)
```

## Sampling and convergence

The method doubles the number of equally weighted points in each reciprocal direction and compares charge and requested density entries on successive grids at the same chemical potential. Before accepting convergence, the default also checks an independently shifted grid. This helps detect features missed by both nested grids.

The density difference estimates integration error at the returned chemical potential; it does not include the density change caused by any remaining chemical-potential error. The fixed-filling residual has its own tolerance.

These differences are empirical error estimates, not rigorous upper bounds. Two grids can agree while both miss a narrow feature. The independent shift is an additional check, not a proof that every possible integrand has been resolved. Exhausting the grid or point budget raises a convergence error.

## Convergence and cost

For a periodic integrand analytic in a complex strip of width $a$, uniform periodic quadrature has an error bound proportional to $e^{-a n}$, where $n$ is the number of points per direction. Finite-range normal and BdG Hamiltonians have analytic finite-temperature density matrix functions. This does not establish that periodic quadrature is the fastest method for every system.

At low temperature the nearest complex singularities can approach the real Brillouin zone, reducing $a$. A grid has $n^d$ points in $d$ dimensions, so cost can grow rapidly in 2D and 3D. Adaptive methods can be useful for sharply localized or strongly anisotropic features. Increasing-order Gaussian quadrature also has exponential convergence for analytic integrands.

See [Trefethen and Weideman](https://people.maths.ox.ac.uk/trefethen/publication/PDF/2014_149.pdf) and [Cancès et al.](https://arxiv.org/abs/1805.07144) for the mathematical assumptions and error estimates.

## Reuse and memory

For normal systems, changing the chemical potential only changes occupations, so cached spectra can be reused across charge evaluations and nested grids. BdG chemical-potential shifts generally change eigenvectors, requiring new eigensystems.

`batch_size` bounds the number of points processed simultaneously. It does not specify a byte limit: temporary storage also depends on the matrix size and requested density entries. `max_cache_bytes` bounds retained eigensystem arrays in both normal and BdG calculations. Points and temporary arrays are outside that cache limit, so it is not a total process-memory limit. When a spectrum or its vectors cannot be retained, the required diagonalization is repeated.

The initial grid has `nk` points per direction, with default `nk=8`. Refinement doubles every direction together. `max_nk=512` caps the resolution per direction, and `max_points=262144` caps the number of points in **each grid**. A shifted validation grid has a separate set of samples at the same resolution. Total diagonalizations can therefore exceed `max_points`, particularly when repeated chemical potentials, discarded validation grids, or cache misses require additional work.

`max_charge_evaluations`, supplied to `density_matrix` or `solver`, limits root-solver charge evaluations across all refinement grids. Density and shifted-grid validation evaluations are integration work and do not consume this root-solver budget. Finite budgets are checked explicitly; an unconverged result is not returned as successful.

## Public use and supported backends

`PeriodicQuadrature` is exported from `meanfi`. Pass it as `integration=` to `meanfi.density_matrix_at_mu`, `meanfi.density_matrix`, or `meanfi.solver`. The normal density APIs support complete matrix blocks or the selected layouts exposed by their existing interfaces. The SCF solver supports both normal and superconducting `Model` instances. In BdG calculations the filling is the electron-block trace, not the trace of the full Nambu density matrix.

The initial implementation uses `DirectDiagonalization`. An omitted `matrix_function` selects direct diagonalization, including for sparse inputs, which are converted to dense matrices. Rational matrix-function backends and zero-temperature integration are outside this method's scope. The finite-temperature default remains `AdaptiveQuadrature`.

Periodic integration works with the existing finite-temperature SCF mixing methods. It does not provide the internal band-energy integral used for automatic `SCFResult.total_energy` and iteration-energy reporting; those fields remain `None`. `EnergyDIIS` retains its existing restriction to normal-state zero-temperature `AdaptiveSimplex` calculations. This does not remove the separate `meanfi.total_energy` observable for a density covering the required entries.
